import jsync.*;

class TestConveyer extends Conveyer { 
    public static void main(String[] args) { 
	System.out.println("Input some numbers:");
        TestConveyer conveyer = new TestConveyer();
	conveyer.start();
	if (conveyer.waitTermination()) { 
	    System.out.println("No prime numbers");
	} else { 
	    System.out.println("Press ENTER");
	}
    } 
    public TestConveyer() { 
        super(System.in, 1024);
    }
    public boolean process(byte[] buffer, int offset, int length) { 
        int number = 0;
	while (length > 0 && buffer[offset] >= '0' && buffer[offset] <= '9') { 
	    number = number * 10 + buffer[offset++] - '0';
	} 
	if (number > 2) {
	    if ((number & 1) == 0) { 
	      System.out.println("Divider 2");
	        return true;
	    }
	    int maxDivider = (int)Math.sqrt((double)number) + 1;
	    for (int divider = 3; divider < maxDivider; divider += 2) { 
	        if (number % divider == 0) { 
		    System.out.println("Divider " + divider);
		    return true;
		}
	    }
	}
	System.out.println("Prime number " + number);
	return false;
    }
}
  
