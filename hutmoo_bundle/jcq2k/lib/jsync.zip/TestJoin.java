import jsync.*;
import java.io.*;

class TestJoin { 
    public static final int bufferSize = 1024;

    public static void main(String[] args) throws Exception { 
        if (args.length < 1) { 
	    System.out.println("Parallel search");
	    System.out.println("This program will search specified substrings in JSYNC package");
	    System.out.println("Search substrings should be passed as program paramters");
	    return;
	}
	int n = args.length;
	InputStream[] input = new InputStream[n];
	for (int i = 0; i < n; i++) { 
	    String cmd = "findstr " + args[i] + " jsync\\*.java";
	    input[i] = Runtime.getRuntime().exec(cmd).getInputStream();
        } 
	JoinInputStream multiplexer = new JoinInputStream(input, bufferSize);
	byte[] buffer = new byte[bufferSize];
	int length;
	while ((length = multiplexer.read(buffer)) > 0) {
	    System.out.print(new String(buffer, 0, length));
	}
    }
}	


