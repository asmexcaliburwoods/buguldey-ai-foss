import jsync.*;

class Reader extends Thread { 
    int id;
    public void run() { 
	TestLock.lck.setShared();
 	if (id == 0) { 
	    TestLock.lck.setExclusive();
	}
        System.out.println("Reader " + id + " lock resource");
	try { 
	    Thread.sleep(10);
	} catch(InterruptedException ex) { 
	    ex.printStackTrace();
	}
        System.out.println("Reader " + id + " unlock resource");
	TestLock.lck.unsetShared();
 	if (id == 0) { 
	    TestLock.lck.unsetExclusive();
	}
    } 
    Reader(int id) { this.id = id; }
}


class Writer extends Thread { 
    int id;
    public void run() { 
	TestLock.lck.setExclusive();
	if ((id & 1) != 0) { 
	    TestLock.lck.setExclusive();
	} 
        System.out.println("Writer " + id + " lock resource");
	try { 
	    Thread.sleep(10);
	} catch(InterruptedException ex) { 
	    ex.printStackTrace();
	}
        System.out.println("Writer " + id + " unlock resource");
	TestLock.lck.unsetExclusive();
	if ((id & 1) != 0) { 
 	    TestLock.lck.unsetExclusive();
	} 
    }
    Writer(int id) { this.id = id; }
}


class TestLock { 
    public static Lock lck = new Lock();
    public static final int nReaders = 100;
    public static final int nWriters = 10;

    public static void main(String[] args) { 
        for (int i = 0; i < nWriters; i++) { 
	    (new Writer(i)).start();
	}
        for (int i = 0; i < nReaders; i++) { 
	    (new Reader(i)).start();
	}
    }
}



