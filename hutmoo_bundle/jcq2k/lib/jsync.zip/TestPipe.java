import jsync.*;

class TestPipe { 
    public static void main(String[] args) throws Exception{ 
        Process proc = Runtime.getRuntime().exec("java -version");
	Pipe.between(proc.getErrorStream(), System.out);
	proc.waitFor();
    }
}
