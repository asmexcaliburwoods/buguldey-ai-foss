import jsync.*;

class Task extends Thread { 
    int id;
    public void run() { 
        if (!TestPrimitives.event.waitEvent(1000)) { 
	    System.out.println("Timeout expired");
	}
	TestPrimitives.mutex.enter();
	System.out.println("Task " + id + " enter critical section");
	try { 
	    Thread.sleep(10);
	} catch(InterruptedException ex) { 
	    ex.printStackTrace();
	}
	System.out.println("Task " + id + " leave critical section");
	TestPrimitives.mutex.leave();
	TestPrimitives.semaphore.waitSemaphore();
	System.out.println("Task " + id + " pass semaphore");
	try { 
	    Thread.sleep(10);
	} catch(InterruptedException ex) { 
	    ex.printStackTrace();
	}
	System.out.println("Task " + id + " signal semaphore");
	TestPrimitives.semaphore.signal();
	TestPrimitives.barrier.reach();
    }
    Task(int id) { this.id = id; }
}

class TestPrimitives { 
    public static final int nThreads = 100;

    public static Semaphore semaphore = new Semaphore(5);
    public static Barrier barrier = new Barrier(nThreads+1);
    public static Event event = new Event();
    public static Mutex mutex = new Mutex();

    public static void main(String[] args) throws Exception { 
        for (int i = 0; i < nThreads; i++) { 
	    (new Task(i)).start();
	} 
	event.signal();
	barrier.reach();
	event.reset();
	barrier.reset(1);
	(new Task(nThreads)).start();
    }
}
							       
	
