import jsync.*;

class TestQueue { 
    public static final int nRecords = 100;
    public static final int nThreads = 10;
    public static Queue queue = new Queue();
    
    public static void main(String[] args) { 
	Consumer[] consumers = new Consumer[nThreads];
	Producer[] producers = new Producer[nThreads];
	for (int i = 0; i < nThreads; i++) { 
	    consumers[i] = new Consumer(i);
	    producers[i] = new Producer(i);
	}
	Concurrent consume = new Concurrent(consumers);
	Concurrent produce = new Concurrent(producers);
	consume.start();
	produce.start();
	Object[] results = consume.waitAll();
	for (int i = 0; i < nThreads; i++) { 
	    Assert.that(((Integer)results[i]).intValue() == i);
	}
    }
}	

class Producer implements Activity { 
    int   id;
    Producer(int id) { this.id = id; }
    public Object run() { 
	for (int i = 0; i < TestQueue.nRecords; i++) { 
	    String s = "record " + id + "." + i;
     	    System.out.println("put record " + s);
	    TestQueue.queue.put(s);
	}
	return null;
    }
}

class Consumer implements Activity { 
    int   id;
    Consumer(int id) { this.id = id; }
    public Object run() { 
	for (int i = 0; i < TestQueue.nRecords; i++) { 
	    String s = (String)TestQueue.queue.get();
	    System.out.println("thread " + id + " get record " + s);
	}
	return new Integer(id);
    }
}

