package net.egp.sphere;

import net.egp.sphere.i18n.Names;
import net.egp.sphere.infra.SubjectContext;
import net.egp.supraverse.infra.SupraverseLink;

public class Sphere {
	private SupraverseLink supralink;
	public Sphere(SupraverseLink supralink){
		this.supralink=supralink;
	}
	private Names names=new Names();
	public String getNameAsString_reserved(SubjectContext sctx){
		return names.translateSphereName_reserved(sctx).asString();
	}
}
