package net.egp.sphere.console.swing;

import javax.swing.JComponent;

import net.egp.sphere.infra.SphereLink;

public class SphereSwingConsole {
	private JComponent mainView;
	private SphereLink sphereLink;
	public SphereSwingConsole(SphereLink sphereLink){
		this.sphereLink=sphereLink;
	}
	public JComponent getMainView(){
		return mainView;
	}
}
