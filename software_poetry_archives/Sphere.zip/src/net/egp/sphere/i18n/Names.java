package net.egp.sphere.i18n;

import net.egp.sphere.i18n.russian.RussianNoun;
import net.egp.sphere.infra.Name;
import net.egp.sphere.infra.SubjectContext;

public class Names {
	public Name translateSphereName_reserved(SubjectContext sctx){
		return new RussianNoun("Сфера");
	}
}
