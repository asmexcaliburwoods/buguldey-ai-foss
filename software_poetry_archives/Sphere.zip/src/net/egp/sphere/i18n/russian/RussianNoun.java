package net.egp.sphere.i18n.russian;

import net.egp.sphere.infra.Name;

public class RussianNoun implements Name{
	private String s;
	public RussianNoun(String s){
		if(s==null)throw new NullPointerException();
		this.s=s;
	}
	@Override
	public String asString() {
		return s;
	}

}
