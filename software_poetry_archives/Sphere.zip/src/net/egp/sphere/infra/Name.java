package net.egp.sphere.infra;

public interface Name {
	String asString();
}
