package net.egp.sphere.infra;

public interface SphereLink {

}
