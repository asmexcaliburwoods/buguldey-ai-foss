package net.egp.sphere.infra;

public interface Subject {

}
