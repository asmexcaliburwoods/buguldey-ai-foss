package net.egp.sphere.infra;

public interface SubjectContext {
	Subject getSubject();
}
