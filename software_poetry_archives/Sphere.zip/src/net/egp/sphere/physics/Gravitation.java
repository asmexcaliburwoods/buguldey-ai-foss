package net.egp.sphere.physics;

public class Gravitation {
	//(StableObject stableObject)
}
