package net.egp.sphere.physics;

public class TimeSpaceSpirit {

}
