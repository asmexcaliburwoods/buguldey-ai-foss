package net.egp.supraverse;

public class Supraverse {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// GTD Auto-generated method stub

	}

}
