package net.egp.supraverse.console.swing;

public class SupraverseSwingConsole {

}
