package net.egp.supraverse.infra;

public interface SupraverseLink {

}
