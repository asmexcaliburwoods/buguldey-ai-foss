#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <climits>
#include <float.h>
#include <cmath>

#ifdef __GNUC__
#define showbase ""
#endif

using namespace std;

typedef double real;

const int POINTS_COUNT = 100;

// this is the function calculating parameterised algorithm's value 
// on its given input value x and its given parameter a
real pa(long a, real x)
{
  real xp=x;
  real s = 0;
  long f = a;
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  			 s+= real(f & 0xf)*xp; f >>= 4; //1
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  xp *= x;   s+= real(f & 0xf)*xp; f >>= 4; //2
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  xp *= x;   s+= real(f & 0xf)*xp; f >>= 4; //3
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  xp *= x;   s+= real(f & 0xf)*xp; f >>= 4; //4
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  xp *= x;	 s+= real(f & 0xf)*xp; f >>= 4; //5
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  xp *= x;	 s+= real(f & 0xf)*xp; f >>= 4; //6
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  xp *= x;	 s+= real(f & 0xf)*xp; f >>= 4; //7
  //cout << hex << showbase << "f="<<f<<", 0xf="<<(f & 0xf)<<endl;
  xp *= x;	 s+= real(f & 0xf)*xp; //8
  //cout << hex << showbase << "a="<<a<<dec<<", x="<<x<<", pa(a, x)="<<s<<endl;
  return s;
}

// this is the unknown algorithm
real ua(real x)
{
	/*
  real x2=x*x;
  real x3=x*x2;
  real x4=x*x3;
  real x5=x*x4;
  real x6=x*x5;
  real x7=x*x6;
  real x8=x*x7;
  real r = x+2*x2+3*x3+4*x4+5*x5+6*x6+7*x7+8*x8;
  //0x87654321
  */
  //cout << dec << "x="<<x<<", ua(x)="<<r<<endl;
  real r = sin(sin(x));
  r=r*r;
  r=r*r;
  return pa(0x68709812, x);// r*x;
}

// utility to generate random realing-point value [0..1]
inline real getRandomFloat()
{
  return (real(rand()) / real(RAND_MAX));
}

inline real rnd()
{
  return getRandomFloat();
}

real getFitness_FIXED(long a, const real CUBE_SIZE)
{
  real x;
  real uar;
  real par;
  real s = 0;
  real up;
  //const real PI = acos(real(-1));
  const real STEP = CUBE_SIZE / POINTS_COUNT;
  
  for (int i = 0; i < POINTS_COUNT; ++i)
  {
    x = STEP * real(i); //rnd();
    uar = ua(x);
    par = pa(a, x);
	up = (uar-par)/(x+1e-300);
	//cout 
	//	<< "x="<<x<<", a="<<hex<<showbase<<a<<", ua(x)="<<dec<<uar<<", pa(x)="<<par<<", diff="
	//	<< up << " ";
	//cin >> par;
    s += up*up;
  }
	
  real f = sqrt(s); //atan(sqrt(s))*(2/PI);
  //if (f < 0) f = 0;
  //if (f > 1) f = 1;
  return -f;
}

real getFitness_RANDOMIZED(long a, const real CUBE_SIZE)
{
  real x;
  real uar;
  real par;
  real s = 0;
  real up;
  //const real PI = acos(real(-1));
  //const real F1 = 1 / POINTS_COUNT;

  for (int i = 0; i < POINTS_COUNT; ++i)
  {
    x = CUBE_SIZE * rnd();
    uar = ua(x);
    par = pa(a, x);
	up = uar-par;
	//cout 
	//	<< "x="<<x<<", a="<<hex<<showbase<<a<<", ua(x)="<<dec<<uar<<", pa(x)="<<par<<", diff="
	//	<< up << " ";
	//cin >> par;
    s += up*up;
  }
	
  real f = sqrt(s); //atan(sqrt(s))*(2/PI);
  //if (f < 0) f = 0;
  //if (f > 1) f = 1;
  return -f;
}

//greater fitness values correspond to better algorithms
//returns [0..1]
inline real getFitness(long a)
{
	return getFitness_FIXED(a, 1001);
	//return getFitness_RANDOMIZED(a, 1);
}

// a genetic algorithm to optimize the output of BlackBox
void OptimizeBlackBox
    (
    size_t populationSize,
    size_t numGenerations,
    real  crossoverRate,
    real  mutationRate,
    bool   elitismEnabled,
    bool   fitnessScalingEnabled,
    ostream & display
    )
{
    // display header
    display << endl
            << "ua - integer coefficient polynoms" << endl
            << "---------------------------------" << endl 
            << endl
            << setprecision(7);

    #ifndef __GNUC__
    display.setf(ios::boolalpha);
    #endif

    // adjust any invalid parameters
    if (populationSize < 10)
        populationSize = 10;

/*    if (numGenerations < 1)
        numGenerations = 1;*/

    if (crossoverRate < 0.0F)
        crossoverRate = 0.0F;
    else
        if (crossoverRate > 1.0F)
            crossoverRate = 1.0;

    if (mutationRate < 0.0F)
        mutationRate = 0.0F;
    else
        if (mutationRate > 1.0F)
            mutationRate = 1.0;

    // display parameters for this run
    display << " population size: " << populationSize << endl
            << "# of generations: " << numGenerations << endl
            << "  crossover rate: " << crossoverRate * 100.0F << "%" << endl
            << "   mutation rate: " << mutationRate * 100.0F << "%" << endl
            << " scaling enabled: " << fitnessScalingEnabled   << endl
            << " elitism enabled: " << elitismEnabled << endl << endl;

    // allocate population and fitness buffers
    long * population = new long[populationSize];
    long * children   = new long[populationSize];
    
    real * fitness   = new real[populationSize];
    
    // various variables
    long  valueMostFit, mask;
    real fitnessHighest, fitnessLowest;
    const real FITNESS_MAX = real(DBL_MAX);
    const real FITNESS_MIN = real(-DBL_MAX);
    real totalFitness, fitnessAverage;
    size_t i, generationCounter, selection, father, mother, start;
    
    // create initial population with random values
    for (i = 0; i < populationSize; ++i)
		population[i] = long(rand());
	//population[99] = 0x10001L;
	//population[69] = 0x1000L;
	//population[6] = 0x1001L;

    // start with generation zero
    generationCounter = 0;
    
    while (true) // loop breaks in the middle
    {
        // initialize for fitness testing
        fitnessLowest  = FITNESS_MAX; //LONG_MAX;
        fitnessHighest = FITNESS_MIN; //-1L;
        totalFitness   = 0.0F;
        
        // fitness testing
        for (i = 0; i < populationSize; ++i)
        {
            // call fitness function and store result
            fitness[i] = getFitness(population[i]);
            
            // keep track of best fitness
            if (fitness[i] > fitnessHighest)
            {
                fitnessHighest = fitness[i];
                valueMostFit = population[i];
            }
            
            // keep track of least fitness
            if (fitness[i] < fitnessLowest)
                fitnessLowest = fitness[i];
            
            // total fitness
            totalFitness += real(fitness[i]);
        }

        /*
        // make sure we have at least some fitness values
        if (totalFitness == 0.0F)
        {
            display << "** population has total fitness -- optimzation terminated." << endl;
            break;
        }
        */
        
        // compute average fitness
        fitnessAverage = totalFitness / real(populationSize);

        // display stats for this generation
//        display << setw(5) << generationCounter << " ";
        display << setw(5) << generationCounter;
        display.setf(ios::internal);
        display << " best: " << hex << showbase << setfill('0')
                << setw(10) << valueMostFit << setfill(' ');
        display.unsetf(ios::internal);
        display << ", fitness = " << dec << setw(7) << fitnessHighest
                << ", avg fitness = " << fitnessAverage
                << endl;
       
        // jump out if we've found the solution
        if (fitnessHighest == 0.0F)
        {
            display << "** algorithm found!" << endl;
            break;
        }
        
		// if enabled, scale fitness values
        if (fitnessScalingEnabled)
        {
            // ensures that the least fitness is one
            //++fitnessLowest;
            
            // recalculate total fitness to reflect scaled values
            totalFitness = 0.0F;
            
            for (i = 0; i < populationSize; ++i)
            {
                fitness[i]   -= fitnessLowest;     // reduce by smallest fitness
                fitness[i]   *= fitness[i];        // square result of above
                totalFitness += real(fitness[i]);  // add into total fitness
            }
        }
        
        // exit if this is final generation
        if (numGenerations != 0 && generationCounter == numGenerations )
        {
            display << "** generation limit reached" << endl;
            break;
        }
        
        // if elitist selection, replace first item with best
        if (elitismEnabled)
        {
            children[0] = valueMostFit;
            start = 1;
        }
        else
            start = 0;
        
        // create new population
        for (i = start; i < populationSize; ++i)
        {
            // roulette-select parent
            selection = (size_t)(getRandomFloat() * totalFitness);
            father    = 0;
            
            while (selection > fitness[father])
            {
                selection -= fitness[father];
                ++father;
            }
            
            // crossover reproduction
            if (getRandomFloat() <= crossoverRate)
            {
                // roulette-select second parent
                selection = (size_t)(getRandomFloat() * totalFitness);
                mother = 0;
                
                while (selection > fitness[mother])
                {
                    selection -= fitness[mother];
                    ++mother;
                }
                
                // mask of bits to be copied from first parent
                mask = 0xFFFFFFFFL << (int)(getRandomFloat() * 32.0F);
                
                // new string from two parents
                children[i] = (population[father] & mask) | (population[mother] & (~mask));
            }
            else
            {
                // one parent, no crossover reproduction
                children[i] = population[father];
            }
            
            // mutation
            if (getRandomFloat() < mutationRate)
            {
                // select bit to be changed
                mask = (long)(getRandomFloat() * 16.0F) << (long)(getRandomFloat() * 32.0F);
                //cout << "m";
                // flip
				children[i] ^= mask;
            }
        }
        
        // exchange old population with new one
        long * temp = children;
        children    = population;
        population  = temp;

        // increment generation
        ++generationCounter;
    }
        
    // delete population and fitness arrays
    delete [] population;
    delete [] children;
    delete [] fitness;
}
    
int main(int argc, char* argv[])
{
    // initialize psuedo-random number generator
    srand((unsigned)time(NULL));

//	int ii;
//	cout << getFitness(0x87654321L);
//	cout << getFitness(0x12345678L);
//	cin >> ii; 

    // main function    
    OptimizeBlackBox(100,0,0.99F,0.5F,true,true,cout);
	cout << "(press ^D)"; char * a = new char[255]; cin >> a; return 0;
}
































































