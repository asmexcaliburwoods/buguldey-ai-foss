#!/bin/sh
./Coco Coco.atg -namespace Coco
