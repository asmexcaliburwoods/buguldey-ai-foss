#ifndef CHECKS_H_
#define CHECKS_H_

void abortIfNull(void* ptr);

#endif /* CHECKS_H_ */
