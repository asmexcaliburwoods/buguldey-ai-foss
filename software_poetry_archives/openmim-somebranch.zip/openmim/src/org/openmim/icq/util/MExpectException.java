package org.openmim.icq.util;

import org.openmim.mn.MessagingNetworkException;

public class MExpectException extends MessagingNetworkException
{
	private static final long serialVersionUID = -5633092118572941380L;

public MExpectException(String s, int cat, int endUserReasonCode)
  {
    super(s, cat, endUserReasonCode);
  }
}