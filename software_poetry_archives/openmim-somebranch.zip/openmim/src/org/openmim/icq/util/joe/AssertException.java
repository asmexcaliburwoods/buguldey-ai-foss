package org.openmim.icq.util.joe;

public class AssertException extends RuntimeException
{
  private static String MUG_REPORT_MSG = "Please send a bug report to the software development team.";

  public AssertException(String s)
{
	super((s == null ? "" : "\r\n" + s) + "\r\n" + MUG_REPORT_MSG);
}
}
