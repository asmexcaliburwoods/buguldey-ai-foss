package org.openmim.icq.util.joe;

public class ExpectException extends Exception
{

	private static final long serialVersionUID = -1600289531992366231L;

public ExpectException(String s)
  {
		super(s);
  }  
}
