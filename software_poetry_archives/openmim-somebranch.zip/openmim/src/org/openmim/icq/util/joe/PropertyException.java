package org.openmim.icq.util.joe;

/**
 * Insert the type's description here.
 * Creation date: (06.06.00 16:41:40)
 * @author: 
 */
public class PropertyException extends Exception
{
/**
 * PropertyIsRequiredException constructor comment.
 * @param s java.lang.String
 */
public PropertyException(String message)
{
	super(message);
}
}
