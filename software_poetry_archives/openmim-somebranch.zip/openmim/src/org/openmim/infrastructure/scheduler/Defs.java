package org.openmim.infrastructure.scheduler;

class Defs {
    static final boolean DEBUG = false;
}