package org.openmim.infrastructure.scheduler;

import java.util.*;

public class SortedList<K,V> extends TreeMap<K,List<V>> {
	private static final long serialVersionUID = 2929937242317429371L;

	public List<V> put(K key, List<V> value) {
        Object o = get(key);
        List<V> values;
        if (o != null)
            values = (List<V>)o;
        else {
            values = new LinkedList<V>();
            super.put(key, values);
        }
        values.addAll(value);
        return value;
    }

    public Object removeFirst(Object key) {
        //Object key = firstKey();
        if (key == null) return null;

        List<V> o = get(key);
        if (o == null) {
            remove(key);
            return null;
        }

        List<V> values = o;

        if (values.size() == 0) {
            remove(key);
            return null;
        }

        V ret = values.remove(0);
        if (values.size() == 0) remove(key);
        return ret;
    }

    public Object remove(Object key, Object value) {
        if (key == null) throw new NullPointerException();

        List<V> o = get(key);
        if (o == null) {
            remove(key);
            return null;
        }

        List<V> values = o;

        if (values.size() == 0) {
            remove(key);
            return null;
        }

        if (values.remove(value)) {
            if (values.size() == 0) remove(key);
            return value;
        } else return null;
    }
}