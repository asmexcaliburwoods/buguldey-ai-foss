package org.openmim.irc.driver;

// Decompiled by Jad v1.5.6g. Copyright 1997-99 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: fieldsfirst splitstr
// Source File Name:   Loadable.java
public interface Loadable
{

public abstract boolean isBeingLoaded();
public abstract void setBeingLoaded(boolean flag);
}
