package org.openmim.mn2.model;

public class ChannelContactBean extends AbstractContactBean{
    public boolean isChannel() {
        return true;
    }
}
