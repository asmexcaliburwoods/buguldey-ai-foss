package org.openmim.mn2.model;

public class ConcreteContactBean extends AbstractContactBean{
    public boolean isChannel() {
        return false;
    }
}
