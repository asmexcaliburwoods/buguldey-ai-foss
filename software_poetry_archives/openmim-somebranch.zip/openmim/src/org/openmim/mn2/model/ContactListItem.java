package org.openmim.mn2.model;

public interface ContactListItem {
    String getDisplayName();
    void setDisplayName(String displayName);
}
