package squirrel_util;

// Decompiled by Jad v1.5.6g. Copyright 1997-99 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: fieldsfirst splitstr
// Source File Name:   AssertException.java

public class ExpectException extends Exception
{

	private static final long serialVersionUID = 8948264871725344537L;

public ExpectException(String s)
{
  super(s);
}
}
