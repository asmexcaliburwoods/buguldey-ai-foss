package org.openmim;

public class Defines
{
  public final static boolean ENABLE_FAKE_PLUGIN = false;
  
  public final static boolean ENABLE_RECONNECTOR_TESTER = false;
  
  public final static boolean DEBUG = true;
  public final static boolean DEBUG_FULL_DUMPS = true;
  public final static boolean DEBUG_DUMPSTACKS_EVERYWHERE = false;
}
