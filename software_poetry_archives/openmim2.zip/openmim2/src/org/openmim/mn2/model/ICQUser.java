package org.openmim.mn2.model;

public interface ICQUser extends User {
}
