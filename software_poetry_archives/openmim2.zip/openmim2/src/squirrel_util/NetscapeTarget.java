package squirrel_util;

// Decompiled by Jad v1.5.6g. Copyright 1997-99 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: fieldsfirst splitstr
// Source File Name:   NetscapeTarget.java

public class NetscapeTarget
{
  public static final String SuperUser = "SuperUser";
  public static final String UniversalFileRead = "UniversalFileRead";
  public static final String UniversalFileWrite = "UniversalFileWrite";
  public static final String UniversalFileDelete = "UniversalFileDelete";
  public static final String UniversalFileAccess = "UniversalFileAccess";
  public static final String UniversalListen = "UniversalListen";
  public static final String UniversalAccept = "UniversalAccept";
  public static final String UniversalConnect = "UniversalConnect";
  public static final String UniversalMulticast = "UniversalMulticast";
  public static final String TerminalEmulator = "TerminalEmulator";
  public static final String UniversalPrintJobAccess = "UniversalPrintJobAccess";
  public static final String UniversalSystemClipboardAccess = "UniversalSystemClipboardAccess";
  public static final String UniversalTopLevelWindow = "UniversalTopLevelWindow";
  public static final String UniversalPropertyWrite = "UniversalPropertyWrite";
  public static final String UniversalPropertyRead = "UniversalPropertyRead";
  public static final String UniversalBrowserRead = "UniversalBrowserRead";
  public static final String UniversalBrowserWrite = "UniversalBrowserWrite";
  public static final String UniversalSendMail = "UniversalSendMail";
  public static final String UniversalExecAccess = "UniversalExecAccessUniversalExecAccess";
  public static final String UniversalExitAccess = "UniversalExitAccessUniversalExitAccess";
  public static final String UniversalLinkAccess = "UniversalLinkAccess";

public NetscapeTarget()
{
}
}
