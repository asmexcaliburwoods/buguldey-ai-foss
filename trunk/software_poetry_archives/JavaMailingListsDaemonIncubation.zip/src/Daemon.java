
package com.jls;

import java.util.*;
import com.jls.entities.*;
       
public class Daemon
{
  JLSContext ctx;

  public Daemon(JLSContext ctx)
  {
    this.ctx = ctx;
  }

  public void mainLoop()
  {
    while (true) do
    {
      MailList list;

      for (Enumeration e = ctx.getLists().elements(); e.hasMoreElements(); )
      {
        list = e.nextElement();
        list.processMail(ctx);
      }
    }
  }           
}