
package com.jls;

import java.util.*;
import com.jls.entities.*;
       
public class JLSContext
{
  Properties props;
  Hashtable lists;

  public JLSContext(Properties props, Hashtable lists)
  {
    this.props = props;
    this.lists = lists;
  }

  public Properties getProps()
  {
    return props;
  }

  public Hashtable getLists()
  {
    return lists;
  }
}