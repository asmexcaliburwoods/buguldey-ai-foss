
package com.jls;

import java.util.*;
import java.io.*;

public class JListServer
{
  final static String propertiesDirName = "./properties/";
  final static String listsDirName = propertiesDirName + "lists/"
  final static String propertiesFileName = propertiesDirName
  					 + "JListServer.properties";

  public static void main(String[] argv)
  {
    System.out.println("JListServer v1.0.0  Copyright 1999 Duplo Software");
    System.out.println("");

    System.out.print("Loading properties...");
    Properties props = new Properties(
		    	 new BufferedInputStream(
        		   new FileInputStream( propertiesFileName )));
    System.out.println(" ok");

    System.out.print("Loading list definitions...");
    Hashtable lists = new HashTable();
    loadLists(lists);
    System.out.println(" ok");

    JLSContext ctx = new JLSContext(props, lists);

    System.out.println("Starting daemon");     
    Daemon daemon = new Daemon(ctx);
    daemon.mainLoop();

    System.out.println("");
    System.out.println("JListServer halted");
  } 


  void loadLists(Hashtable lists)
  {
    File listDir = new File(listsDirName);
    String[] listNames = listDir.list();

    String listName;
    Properties listProps;

    for (int i=0; i < listNames.length; i++)
    {
      listName = listNames[i];
      listProps = new Properties(
		    new BufferedInputStream(
        	      new FileInputStream(
                        listsDirName + listName)));
      lists.put(listName, new MailList(listName, listProps));
    }
  }
}