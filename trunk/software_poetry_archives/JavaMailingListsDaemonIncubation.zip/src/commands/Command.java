
package com.jls.commands;

import javax.mail.internet.*;
import com.jls.*;

public interface Command
{
  //returns command output to be sent back to user
  public abstract String doCommand(User user, MailList list, String[] args, JLSContext ctx); 
}
