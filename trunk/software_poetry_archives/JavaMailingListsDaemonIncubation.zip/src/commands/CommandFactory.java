
package com.jls.commands;

import javax.mail.internet.*;
import com.jls.*;

public class CommandFactory
{
  public static Command getCommand(String line)
  {
    str -> tokenize by " ";
    unsubscribe -> new UnsubscribeCommand etc.
  }

  //returns command output to be sent back to user
  public abstract String doCommand(String[] argc); 

  //user who performed the command
  public User getUser()
  {
    return user;
  }

  //mail list that is controlled by command
  public MailList getMailList()
  {
    return list;
  }
}