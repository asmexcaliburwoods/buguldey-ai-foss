
package com.jls.commands;

import javax.mail.*;
import javax.mail.internet.*;
import com.jls.*;

public class CommandMessage extends CommandSet
{
  Message msg;

  public CommandMessage(User user, MailList list, Message msg)
  {
    super(user, list);

    this.msg = msg;
  }

  public boolean hasCommand();

  public Command nextCommand();
}