
package com.jls.commands;

import javax.mail.internet.*;
import com.jls.*;

public class CommandSet
{
  protected User user;
  protected MailList list;               

  protected CommandSet(User user, MailList list)
  {
    this.user = user;
    this.list = list;
  }

  //user who performed commands
  public User getUser()
  {
    return user;
  }

  //mail list that is controlled by commands
  public MailList getMailList()
  {
    return list;
  }

  public abstract boolean hasCommand();

  public abstract Command nextCommand();
}