
package com.jls.commands;

import javax.mail.internet.*;
import com.jls.*;
import java.util.*;

public class ConfirmedCommand extends Command
{
  static Random rnd = new Random();

  long password;

  protected ConfirmedCommand()
  {
  }

  void createPassword()
  {
    password = rnd.nextLong();
  }
  
  protected void sendConfirmationMessage(InternetAddress addr, MailList list, JLSContext ctx)
  {
    InternetAddress ia = new InternetAddress(addr);
    User u = new User(ia, list);

    createPassword();
    ConfirmationMessage cm = new ConfirmationMessage(u, password);

    Object[] subscribeRequest = new Object[] { u, new Long(password) };

    list.getSubscribeRequestedUserList().addElement(subscribeRequest);
    ctx.getSMTPServer().sendMessage(cm);
    return "Confirmation message is sent to "+u.getAddress()+".\r\n"+
           "If you will not receive such message, please contact\r\n"+
           list.getOwnerAddress()+".\r\n";
  }

  public static boolean isConfirmationMessage(
  				Message msg, User user, long password)
  { ...
  }
}