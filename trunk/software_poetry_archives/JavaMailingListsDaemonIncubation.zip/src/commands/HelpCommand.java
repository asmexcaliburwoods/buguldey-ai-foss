
package com.jls.commands;

import com.jls.*;

public class HelpCommand extends Command
{
  public HelpCommand()
  {
  }

  //returns command output to be sent back to user
  public String doCommand(User user, MailList list,
  			  String[] argc, JLSContext ctx)
  {
    return "Here will be help text.";
  }
}