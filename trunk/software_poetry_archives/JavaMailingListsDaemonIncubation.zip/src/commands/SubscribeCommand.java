
package com.jls.commands;

import javax.mail.internet.*;
import com.jls.*;

public class SubscribeCommand extends ConfirmedCommand
{
  public SubscribeCommand()
  {
  }

  //returns command output to be sent back to user
  public String doCommand(User user, MailList list,
  			  String[] argc, JLSContext ctx)
  {
    String addr = argc[0];
    for (int i = 1; i < argc.length; i++) addr += " " + argc[i];
    if (addr.trim().length() = 0) 
    {
      doSubscribe();
      return "You are successfully subscribed to a list.";
    }
    else
      return sendConfirmationMessage(new InternetAddress(addr), list, ctx);
  }

  public void doSubscribe()
  { ...
  }
}