
package com.jls.entities;

import javax.mail.internet.*;

public class Human
{
  InternetAddress addr;

  public Human(InternetAddress addr)
  {
    this.addr = addr;
  }

  public InternetAddress getAddress()
  {
    return addr;
  }
}