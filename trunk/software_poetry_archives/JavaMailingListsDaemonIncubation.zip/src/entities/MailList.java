
package com.jls.entities;

import com.jls.*;
import com.jls.commands.*;
import com.jls.transport.*;

public class MailList 
{
  String listName;
  Hashtable listProps;

  CommandSetProvider csp;
  UserMessageProvider ump;
  OwnerMessageProvider omp;

  UserList users;
  OwnerList owners;

  public MailList(String listName, Hashtable listProps, Properties props)
  {
    this.listName = listName;
    this.listProps = listProps;

    csp = new CommandMessageProvider(listName, props);
    omp = new OwnerMessageProvider(listName, props);
    ump = new UserMessageProvider(listName, props);

    users = new UserList(listProps.getProperty("users"));
    owners = new OwnerList(listProps.getProperty("owners"));
  }
  
  public CommandSetProvider getCommandSetProvider()
  { 
    return csp;
  }

  public UserMessageProvider getUserMessageProvider()
  { 
    return ump;
  }

  public OwnerMessageProvider getOwnerMessageProvider()
  { 
    return omp;
  }

  public UserList getUserList()
  { 
    return users;
  }

  public OwnerList getOwnerList()
  {
    return owners;
  }

  public void processMail(JLSContext ctx)
  {
    while (csp.hasCommandSet()) processCommands(csp.nextCommandSet(), ctx);
    while (ump.hasMessage()) processUserMessage(ump.nextMessage(), ctx);
    while (omp.hasMessage()) processOwnerMessage(omp.nextMessage(), ctx);
  }

  void processCommands(CommandSet cs, JLSDaemonContext ctx)
  {
    User user = cs.getUser();
    while (cs.hasCommand()) processCommand(user, cs.nextCommand(), ctx);
  }

  void processUserMessage(Message msg, JLSContext ctx)
  {
  ...
  }

  void processOwnerMessage(Message msg, JLSContext ctx)
  {
  ...
  }
}