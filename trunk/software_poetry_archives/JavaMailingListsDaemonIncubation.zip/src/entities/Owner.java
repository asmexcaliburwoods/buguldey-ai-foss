
package com.jls.entities;

import javax.mail.internet.*;

public class Owner extends Human
{
  public Owner(InternetAddress addr)
  {
    super(addr);
  }
}