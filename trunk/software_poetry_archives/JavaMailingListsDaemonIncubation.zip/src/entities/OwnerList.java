
package com.jls.entities;

public class OwnerList 
{
}