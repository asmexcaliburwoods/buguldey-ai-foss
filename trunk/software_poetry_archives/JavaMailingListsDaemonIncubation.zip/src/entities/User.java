
package com.jls.entities;

import javax.mail.internet.*;
import com.jls.commands.*;

public class User extends Human
{
  public User(InternetAddress addr)
  {
    super(addr);
  }
}