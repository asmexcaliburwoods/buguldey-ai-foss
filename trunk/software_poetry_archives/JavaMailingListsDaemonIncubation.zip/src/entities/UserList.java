
package com.jls.entities;

public class UserList 
{
}