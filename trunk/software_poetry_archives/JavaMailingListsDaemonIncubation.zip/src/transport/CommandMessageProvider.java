
package com.jls.transport;

import com.jls.*;
import com.jls.commands.*;
import javax.mail.*;

public class CommandMessageProvider extends CommandSetProvider
{
  MessageProvider msgprov;

  public CommandMessageProvider(MailList list)
  {
    super(list);

    msgprov = new MessageProvider(list.getName()+"-request", ctx);
  }

  public boolean hasCommandSet()
  {
    if (msgprov.hasMessage() && 
  }

  public CommandSet nextCommandSet()
  { ...
  }
}
