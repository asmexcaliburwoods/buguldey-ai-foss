
package com.jls.transport;

import com.jls.*;
import com.jls.commands.*;
import javax.mail.*;

public class CommandSetProvider
{
  protected MailList list;

  public CommandSetProvider(MailList list)
  {
    this.list = list;
  }

  public abstract boolean hasCommandSet()

  public abstract CommandSet nextCommandSet();
}
