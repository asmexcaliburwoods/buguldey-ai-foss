
package com.jls.transport;

import com.jls.*;
import com.jls.commands.*;
import java.util.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class MessageProvider
{
  Session session;
  String password;

  protected MessageProvider(String username, String password, JLSContext ctx)
  {
    Properties props = ctx.getProps();
    props.setProperty("mail.pop3.user", username);
    session = Session.getInstance(props, null);
    this.password = password;
    Store store = session.getStore();
  }

  public boolean hasMessage()
  {
    try
    {
    Folder folder = store.getDefaultFolder();
    if (folder == null)
    {
      System.out.println("msgprovider: no default folder");
      return false;
    }
    
    folder = folder.getFolder("INBOX");
    if (folder == null)
    {
      System.out.println("msgprovider: no such folder: INBOX");
      return false;
    }

    folder.open(Folder.READ_WRITE);
    int totalMessages = folder.getMessageCount();

    if (totalMessages == 0)
    {
      return false; //System.out.println("Empty folder");
      folder.close(false);
    }
    ..................................
    }
  }

  public Message nextMessage();

  void connect()
  {
    store.connect(null, null, null, password);
  }

  void close()
  {
    store.close();
  }
}
