
package com.jls.transport;

import com.jls.*;
import com.jls.commands.*;
import javax.mail.*;

public class OwnerMessageProvider extends DataMessageProvider
{
  public UserMessageProvider(MailList list)
  {
    super(list);
  }

  public boolean hasMessage()
  { ...
  }

  public abstract Message nextMessage()
  { ...
  }
}
