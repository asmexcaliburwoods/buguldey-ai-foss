package forpeople.events;

import forpeople.machinebrain.KeyboardDevicesMachineBrainImpl;

public class KeyboardsReadEventGenerator {

	public static void installAllKeyboardDevices(
			KeyboardDevicesMachineBrainImpl keyboardDevicesMachineBrainImpl) {
		// TODO Auto-generated method stub
		
	}

}
