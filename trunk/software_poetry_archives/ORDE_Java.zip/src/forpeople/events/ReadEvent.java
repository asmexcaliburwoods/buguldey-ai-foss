package forpeople.events;

public interface ReadEvent {
	void debugToStdOut();
}
