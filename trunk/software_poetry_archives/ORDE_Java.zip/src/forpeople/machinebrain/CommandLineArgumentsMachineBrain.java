package forpeople.machinebrain;

public interface CommandLineArgumentsMachineBrain extends MachineBrain {

}
