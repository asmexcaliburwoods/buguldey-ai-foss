package forpeople.machinebrain;

import forpeople.events.ReadEvent;

public class CommandLineArgumentsMachineBrainImpl 
	extends
		EmbryoMachineBrainImpl
	implements
		CommandLineArgumentsMachineBrain {

	@Override
	public void eval(ReadEvent dataReference) {
		super.eval(dataReference);
	}

}
