package forpeople.machinebrain;

public interface InputStreamMachineBrain extends MachineBrain {

}
