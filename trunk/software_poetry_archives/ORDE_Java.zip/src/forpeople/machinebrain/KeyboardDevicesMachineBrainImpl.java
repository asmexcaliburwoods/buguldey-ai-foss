package forpeople.machinebrain;

public class KeyboardDevicesMachineBrainImpl extends EmbryoMachineBrainImpl
		implements MachineBrain {

}
