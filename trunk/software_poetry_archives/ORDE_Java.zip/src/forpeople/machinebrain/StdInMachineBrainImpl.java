package forpeople.machinebrain;

public class StdInMachineBrainImpl 
	extends EmbryoMachineBrainImpl 
	implements InputStreamMachineBrain {

}
