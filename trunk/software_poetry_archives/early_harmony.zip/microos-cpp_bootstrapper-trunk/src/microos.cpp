#ifndef _GNU_SOURCE
#	define _GNU_SOURCE
#endif
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <malloc.h>

// Author: E.G.Philippov

using namespace std;

bool have_located_hurd;

void locate_hurd(){
	have_located_hurd=false;
	//if folder named hurd exists, then hurd is found
	struct stat buf;
	int retcode=stat("./hurd", &buf);
	//On success, zero is returned. On error, -1 is returned, and errno is set appropriately.
	if(retcode){
		perror("GNU Hurd was not located, it is expected in a folder named ./hurd . Underlying OS says");
		char* cwd=get_current_dir_name();
		if(cwd){fprintf(stderr, "Here, . is %s\n", cwd);free(cwd);}
	}else{
		have_located_hurd=true;
	}
}

bool located_hurd(){return have_located_hurd;}

/**
 * Returns an integer that will be returned from main(). 1 is reserved for 'hurd was not located'.
 */
int run_hurd_and_port_it_if_needed_and_run_tweaker_after_authentication_and_dialogue(){
	puts("run_hurd_and_port_it_if_needed_and_run_tweaker_after_authentication_and_dialogue: not implemented.\n");
	return 2;//not implemented
}

int main() {
/*
	- I will run "microos" from the Linux command line.
	- On startup, it will try to locate Debian Hurd (locally) and will try to run it, and port it if needed.
	- Invariant: Maintain acceptance of our foundational principles (see the file docs/principles).
 */
	locate_hurd();
	if(located_hurd())
		return run_hurd_and_port_it_if_needed_and_run_tweaker_after_authentication_and_dialogue();
	else
		return 1;
}
