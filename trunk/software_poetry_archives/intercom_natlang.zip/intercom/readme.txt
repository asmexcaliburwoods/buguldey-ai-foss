


uses jcocor/cocor/multithreaded.

uses case insensitive natlang-like syntax, with case-sensitive exact "strings".

strings and phrases can contain \r\n.

all phrases, commands, requests, questions and replies use 
natlang-like syntax, but it is strict (phrases must use strict format to be 
recognized).  In an event of invalid format, an 'invalid natlang format.' reply 
must be returned, and some kind of error recovery performed -- such that a human 
could intercom_municate with computer object safely. Whitespace structure 
outside "strings" should be ignored: the 
parsing side will recognize the presence of whitespace, but will ignore the 
internal structure of whitespace. // and nested /* */ comments, and natlang 
'comment: commentbody.' and nested natlang 'comment start. commentbody. 
comment end.' comments are allowed anywhere in natlang input, and are treated 
as a whitespace.  In "strings", no comments or whitespaces are recognized; 
they are accepted as all other characters.

natlang clauses must end with either one or more characters from the set ".!?".

intercom interface must be able to be used in effective communication 
between two machine objects, and also between a human and a machine object.

objects must ignore unrecognized phrases, and must tell about their ignorance
to the phrase emitter.

in "strings", the symbol \ is allowed as a line continuation symbol. \" (and other 
C-like \ escapes) can be used there.

protocol must allow binary data pieces prefixed with binary data piece length.
when the stream is shown to a human, an option must be: write hexdump or not.  
if hexdump is not written, then only binary data piece length is reported to 
a human.  Hexdumps and the text outside the pure binary portion of phrase with
binary data piece must satisfy the above natlang restrictions.

when certain side of intercommunication urgently expects some phrase 
from other side, it must say so: `waiting for such-and-such kind of reply.', 
or emit some other spell, so that this 'other side' will know.  Expecting 
side must not be silent in such an urgent situation.

`strings' and 'strings' (can be used interchangeably) are reserved for 
case-insensitive natlang names, symbols, and clauses. Some C-like backslash 
escapes can be used there.  In `strings', single quote and double quote symbols 
can be used without backslash prefix.  In 'strings', single quotes must be 
prefixed with backslash, and double quotes can occur without backslash prefix.
In `strings', 'strings', and "strings" backslash-prefixed characters are 
recognized and unescaped.  Line-continuation characters lose any special 
meaning in `strings' and 'strings'; they are only recognized in "strings".

<more>
intercom should be able to wrap any existing object (written in any programming 
language, including not object-oriented ones) with its interface, 
with no changes in any existing objects.

intercom specification files for this object should use syntax like:

intercommunication of object `IRC server connection' using 
java class "squirrel.ircweblogger.irc.IrcServer".

  start banner: `IRC server connection object. version 2.0. such-and-such bugs 
are not fixed. comment: any additional info could be here. say `help' to get 
help.'

  comment start. start banner sequence must be one or more valid natlang clauses.  
it is displayed when other intercom object says 'intercom version 1 start, last 
modified by squirrel.' (which can be skipped in certain cases such as 
with-human communication; human could have a preference settings for this).
last-modified-by subclause is required and can be used to specify a version 
namespace, and is analysed by parsing intercom. comment end.
  
  comment: method definition body sequence must be one or more valid 
natlang clauses.

To `join channel', use `join channel <channelName:"#channel-name">.' for "this.join(String channelName)".
To `join channel', use `join channel <channelName:"&channel-name">.' for "this.join(String channelName)".
To `join channel using key', use `join channel <channelName:"#channel-name"> using key 
       <key:"passwd123">.' for "this.join(String channelName, String key)".
To `join channel', use 'connect to a channel <channelName:"#channel-name">.' 
for "this.join(String channelName)", synonyms: 
`enter channel <channelName:"#channel-name">.'.


  comment start. natlang definitions for thrown exceptions, successful void 
method returns, for return values, and for tostring conversions must also be 
specified here. you may specify as many synonyms as you want, provided that 
they are unambiguous. comment end.

/*
  sdshdgf 
  /* asgfdkdgjh 
  */
*/

//sdhgfsdjhfg

end of object 'IRC server'.
</more>

<e.g.>
  req to ircweblogger object: `use irc server \"irc.dal.net\" port 
  6668. connect
  .'.

  reply from ircweblogger object: `ok; irc server setting accepted. 
  cannot connect.  which database to use?'.

  req to ircweblogger object: `use database driver "org.HsqldbDriver" at host 
  "localhost:4000", database type: "hsql". connect. use channel "#xyz". 
  join "#xyz".'.
  
  reply from ircweblogger object: `ok; database setting accepted. 
  ok; connected to irc server.  unrecognized clause ignored: "use channel \
  \"#xyz\".  unrecognized clause ignored: "join \"#xyz\".  

  Possible valid requests:
  
    How to join?
    How to join channel?
    How to join server?
    How to join channel using key?
    
  '.
  
  req to ircweblogger object: `how to join channel?'.
  
  reply from ircweblogger object: `
  
  ---------------------------------------------------
  
  To join channel, say 
  
    join channel "#channel-name".
  
  Synonyms: 
  
    connect to a channel "#channel-name".
    enter channel "#channel-name".
  
  Examples:
      
    join channel "#channel-name".
    join channel "&channel-name".
    connect to a channel "#channel-name".
    enter channel "#channel-name".
    
  ---------------------------------------------------
  
  To join channel using key, say 
  
    join channel "#channel-name" using key "passwd123".
    
  Examples:
      
    join channel "#channel-name" using key "passwd123".
  '.
  
  req to ircweblogger object: `join channel "#xyz".'

  reply from ircweblogger object: 'cannot join channel \"#xyz\": error: 
  \"disconnected from irc server\".  disconnected from irc server.'
</e.g.>

desire: implement this such that this interface will be compilable into
binary code with no natlang communication; binary code such that native mathod 
calls will be used instead of text communication. But -- optimized apps should 
leave intercom interfaces for the outside apps calling them; such that if we 
want a pair of intercom_municating objects X & Y to be optimized, then they 
will use binary native calls to intercom_municate.  But still -- optimized pair
should have a way to disable/enable debugging output of intercom natlang 
discourse.  Optimized pairs should also have a runtime way to disable optimized 
intercommunication, and to use a natlang intercommunication only: this will 
enable filters/intermediators/syntax tree transformers.

desire: make another application -- intermediator -- syntax tree transformer.  
Will take one syntax tree on input (one or more sentences), and produce 
modified syntax tree on output.

desire: intercom could be able to operate and communicate on object instances
using their natlang symbolic names.