/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

import java.util.*;
import java.net.*;

/**
 * Main class for LJ interaction
 * @author Petr Panteleyev
 */
public final class LJAccount {
    private LJConnection m_conn;
    private LJProtocol m_proto;
    private LJFriendList friends;
    private LJGroupList groups;
    private String m_userFullName;
    private String m_userLoginName;
    private ArrayList<String> userpicKeys;
    private ArrayList<URL> userpicUrls;
    private ArrayList<LJMood> m_moods;
    private ArrayList<String> m_sharedJournals;
    private ArrayList<LJTag> m_userTags;
    
    /** Creates a new instance of LJAccount */
    public LJAccount() {
        m_conn = new LJConnection();
        m_proto = new LJProtocol(m_conn);
        friends = new LJFriendList();
        groups = new LJGroupList();
        userpicKeys = new ArrayList<String>();
        userpicUrls = new ArrayList<URL>();
        m_moods = new ArrayList<LJMood>();
        m_sharedJournals = new ArrayList<String>();
        m_userTags = new ArrayList<LJTag>();
    }
        
    /**
     * Logins to the LiveJournal account.
     * This method caches the following information:
     * <ul><li>User groups<li>Shared Journals<li>Moods<li>Userpic URLs</ul>
     * Userpics themselves are not cached by LJAccount. The client must load 
     * usepics using provided URLs.
     * @param uName Account name
     * @param passwd Password to the account
     * @param encrypted Whether <code>passwd</code> is MD5 encrypted or not
     * @param maxMoodID Last mood ID cached by the calling client
     * @return LiveJournal response data that can be parsed by the calling client 
     * @throws LJException In case of error
     */
    public LJRawResult login(String uName, String passwd, boolean encrypted, int maxMoodID) throws LJException {
        m_userFullName = uName;
        
        String hPasswd;
        
        if (!encrypted) {
            hPasswd = LJHelpers.MD5Encode(passwd);
        } else {
            hPasswd = passwd;
        }
        
        LJRawResult hash = getProtocol().login(uName, hPasswd, maxMoodID);
        
        m_userLoginName = uName;
        
        // Get full name
        String value = hash.get("name");
        if (value != null) {
            m_userFullName = value;
        } else {
            m_userFullName = uName;
        }
        
        // Groups
        this.groups.load(hash);
        loadSharedJournals(hash, uName);
        loadMoods(hash);
        loadUserpicURLs(hash);
        
        return hash;
    }
    
    private void loadSharedJournals(LJRawResult hash, String uName) {
        m_sharedJournals.clear();
        m_sharedJournals.add(uName);
        
        int count = hash.getCount("access_count");
        for (int i = 1; i <= count; i++) {
            String value = hash.get("access_" + Integer.toString(i));
            if (value != null) {
                m_sharedJournals.add(value);
            }
        }
    }
    
    private void loadMoods(LJRawResult data) {
        int count = data.getCount("mood_count");        
        m_moods.ensureCapacity(count);
        
        for (int i = 1; i <= count; i++) {
            String prefix = "mood_" + Integer.toString(i) + "_";
            String value = data.get(prefix + "id");
            if (value != null) {
                int id = Integer.parseInt(value);
                value = data.get(prefix + "name");
                if (value != null) {
                    m_moods.add(new LJMood(id, value));
                }
            }
        }

        Collections.sort(m_moods);
    }
    
    private void loadUserpicURLs(LJRawResult data) throws LJException {
        userpicKeys.clear();
        userpicUrls.clear();
        
        String value;
        
        /* Get default picture */
        value = data.get("defaultpicurl");
        if (value != null) {
            try {
                userpicUrls.add(new URL(value));
                userpicKeys.add("(default)");
            }
            catch (Exception e) {                
            }
        }
        
        int count = data.getCount("pickwurl_count");
        userpicKeys.ensureCapacity(count);
        userpicUrls.ensureCapacity(count);
        
        for (int i = 1; i <= count; i++) {
            String sInd = Integer.toString(i);
            String key = data.get("pickw_" + sInd);
            String urlstr = data.get("pickwurl_" + sInd);
            if ((key != null) && (urlstr != null)) {
                try {
                    userpicUrls.add(new URL(urlstr));
                    userpicKeys.add(key);
                }
                catch (MalformedURLException e) {                            
                }
            }
        }
    }
    
    /**
     * Returns account name logged in
     * @return Account name
     */
    public String getLoginName() { return m_userLoginName; }
    
    /**
     * Returns full name of the user logged in.
     * This name is provided by the LiveJournal as a response to login request
     * @return Full name of the user
     */
    public String getFullName() { return m_userFullName; }
    
    /** @deprecated Use {@link #getFriendList()} instead */
    public LJFriendList getFriends() { return this.friends; }
    
    public LJFriendList getFriendList() { return this.friends; }
    public ArrayList<LJFriend> getFriendArray() { return this.friends.getFriendArray(); }
    public LJGroupList getGroups() { return this.groups; }
    public LJProtocol getProtocol() { return m_proto; }
    public ArrayList<LJMood> getMoods() { return m_moods; }
    
    public ArrayList<String> getUserpicKeys() { return this.userpicKeys; }
    public ArrayList<URL> getUserpicUrls() { return this.userpicUrls; }
    
    /* Helpers */
    public LJFriend getFriendByIndex(int index) { return this.friends.getFriendArray().get(index); }
    public LJFriend getFriend(String name) { return this.friends.getFriend(name); }
 
    public LJRawResult getFriends(boolean includeFriendOf, LJProgressCallback ph) throws LJException {
        return getProtocol().getFriends(includeFriendOf, ph);
    }
    
    
    public void deleteFriend(LJFriend friend) throws LJException {
        getProtocol().deleteFriend(friend.getUserName());
        this.friends.removeFriend(friend); 
    }
    
    public int addFriend(LJFriend friend) throws LJNotLoggedInException, LJException { 
        int count = getProtocol().addFriend(friend);
        if (count != 0)
            this.friends.addFriend(friend); 
        return count;
    }
    
    public LJRawResult updateFriend(LJFriend f) throws LJException {
        return getProtocol().updateFriend(f);
    }
    
    public void loadLastEntry(LJEvent event)  throws LJException { getProtocol().loadLastEntry(event);  }    
    public void setGroups(ArrayList<LJGroup> grps) { getGroups().setGroups(grps); }
    public void saveGroups(ArrayList<LJGroup> groups, ArrayList<LJGroup> toDelete, ArrayList<LJFriend> friends) throws LJException {
        getProtocol().saveGroups(groups, toDelete, friends);
    }
    
    public ArrayList<String> getSharedJournals() { return m_sharedJournals; }
    
    public void postEvent(LJEvent event) throws LJException { getProtocol().postEvent(event); }
    public void deleteEvent(LJEvent event) throws LJException { getProtocol().deleteEvent(event); }    
    
    public boolean consoleCommand(String cmd, ArrayList<String> res) throws LJException { 
        return getProtocol().consoleCommand(cmd, res);
    }
    
    public ArrayList<LJEvent> loadHistory(int trunc, int howMany, Date beforeDate, String useJournal) throws LJException {
        return getProtocol().loadHistory(trunc, howMany, beforeDate, useJournal);
    }
    
    public LJEvent loadEvent(int id, String useJournal) throws LJException { return getProtocol().loadEvent(id, useJournal); }

    public ArrayList<LJTag> getUserTags() { return m_userTags; }
    public ArrayList<LJTag> loadUserTags(LJProgressCallback ph) throws LJException { 
        getProtocol().loadUserTags(m_userTags, ph);
        return m_userTags;
    }
    
    /**
     * Adds tags specified by a comma separated string to the tags list. Server is not updated.
     * @param tagList String containing comma separated list of tags to be added
     */
    public void addLocalTags(String tagList) {
        String[] names = tagList.split(",");
                
        for (String name : names) {
            name = name.trim();
            // Check if this tag exists already
            boolean found = false;
            for (LJTag t : m_userTags) {
                if (t.getName().equals(name)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                m_userTags.add(new LJTag(name));                
            }
        }
        
        Collections.sort(m_userTags);        
    }
}