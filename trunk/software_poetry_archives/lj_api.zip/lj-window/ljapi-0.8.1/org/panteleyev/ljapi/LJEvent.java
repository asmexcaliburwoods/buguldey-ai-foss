/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

import org.w3c.dom.*;
import java.util.*;
import java.text.*;

/**
 * This class represents events posted on LiveJournal server
 * @author Petr Panteleyev
 */
public class LJEvent {
    public static final int ACCESS_PUBLIC       = 0;
    public static final int ACCESS_PRIVATE      = 1;
    public static final int ACCESS_FRIENDS      = 2;
    public static final int ACCESS_GROUPS       = 3;
    
    private int accessLevel;
    private int groupMask;
    private String subj;
    private String body;
    private String userpic;
    private boolean backdate;
    private int m_screeningType;
    private int m_itemID;
    private String taglist;
    private Date date;
    private boolean noEmail;
    private boolean noComments;
    private boolean noAutoFormat;
    private int moodID;
    private String moodText;
    private String music;
    private String location;
    private String journal;
    private String m_poster;
    
    private static String[] screeningTypeString = {"", "N", "R", "F", "A"};
    
    public LJEvent() {
        accessLevel = ACCESS_PUBLIC;
        m_itemID = -1;
        groupMask = 0;
        subj = "";
        body = "";
        userpic = null;
        backdate = false;
        m_screeningType = 0;
        taglist = "";
        moodID = -1;
        date = new Date();
        journal = "";
        m_poster = null;
    }
    
    public String getSubject() { return this.subj; }
    public void setSubject(String subj) { this.subj = subj; }
    
    public String getBody() { return this.body; }
    public void setBody(String body) { this.body = body; }
    
    public int getAccessLevel() { return this.accessLevel; }
    public int getGroupMask() { return this.groupMask; }

    public void setAccessLevel(int level) {        
        this.accessLevel = level;
        if (level == ACCESS_FRIENDS) {
            this.groupMask = 1;
        }
    }
    
    public void setGroupMask(int mask) {
        this.accessLevel = ACCESS_GROUPS;
        this.groupMask = mask & 0xFFFE;
    }
    
    public void setMood(int id, String text) {
        this.moodID = id;
        this.moodText = text;              
    }
    
    public int getMoodID() { return this.moodID; }
    public void setMoodID(int id) { this.moodID = id; }
    
    public String getMoodText() { return this.moodText; }
    public void setMoodText(String text) { this.moodText = text; }
    
    public String getUserpic() { return this.userpic; }
    public void setUserpic(String upic) { this.userpic = upic; }
    
    public boolean getBackdate() { return this.backdate; }
    public void setBackdate(boolean b) { this.backdate = b; }
    public Date getDate() { return this.date; }
    public void setDate(Date date) { this.date = date; }
    
    public boolean getNoEmail() { return this.noEmail; }
    public void setNoEmail(boolean b) { this.noEmail = b; }
    
    public boolean getNoComments() { return this.noComments; }
    public void setNoComments(boolean b) { this.noComments = b; }
    
    public boolean getNoAutoFormat() { return this.noAutoFormat; }
    public void setNoAutoFormat(boolean b) { this.noAutoFormat = b; }
    
    public String getMusic() { return this.music; }
    public void setMusic(String music) { this.music = music; }

    public String getLocation() { return this.location; }
    public void setLocation(String location) { this.location = location; }
    
    public void setScreeningType(int type) { 
        if ((type >= 0) && (type < screeningTypeString.length)) {
            m_screeningType = type;
        }
    }
    
    public int getScreeningType() { return m_screeningType; }
    
    public String getScreeningTypeString() { return this.screeningTypeString[m_screeningType]; }
    public void setScreeningTypeString(String s) {
        m_screeningType = 0;
        
        for (int i = 1; i < screeningTypeString.length; i++) {
            if (screeningTypeString[i].equals(s)) {
                m_screeningType = i;
                break;
            }
        }
    }
    
    public void setTagList(String taglist) { this.taglist = taglist; }
    public String getTagList() { return this.taglist; }
    
    public String getJournal() { return this.journal; }
    public void setJournal(String journal) { this.journal = journal; }
    
    public int getID() { return m_itemID; }
    public void setID(int id) { m_itemID = id; }
    
    public String getPoster() { return m_poster; }
    public void setPoster(String poster) { m_poster = poster; }
    
    public void parseResponse(LJRawResult data, String prefix) throws LJException {
        String value;
        
        value = data.get(prefix + "itemid");
        if (value != null) {
            m_itemID = Integer.parseInt(value);            
        }
        
        value = data.get(prefix + "subject");
        if (value != null) {
            try {
                setSubject(java.net.URLDecoder.decode(value, "UTF-8"));
            }
            catch (Exception e) {
                throw new LJProgrammingException(e.getMessage());
            }
        }
        
        value = data.get(prefix + "event");
        if (value != null) {
            try {
                setBody(java.net.URLDecoder.decode(value, "UTF-8"));
            }
            catch (Exception e) {
                throw new LJProgrammingException(e.getMessage());
            }
        }
        
        /* Poster */
        value = data.get(prefix + "poster");
        setPoster(value);
        
        /* Date */
        value = data.get(prefix + "eventtime");
        if (value != null) {
            try {
                this.date = LJHelpers.dateFormat.parse(value);
            }
            catch (Exception e) {
                throw new LJProgrammingException(e.getMessage());
            }
        }
        
        /* Security  */
        value = data.get(prefix + "security");
        if (value == null) {
            this.accessLevel = ACCESS_PUBLIC;
        } else {
            if (value.equals("private")) {
                this.accessLevel = ACCESS_PRIVATE;
            } else {
                if (value.equals("usemask")) {
                    String v1 = data.get(prefix + "allowmask");
                    if (v1 != null) {
                        this.groupMask = Integer.parseInt(v1);
                        if ((this.groupMask & 1) == 1) {
                            this.accessLevel = ACCESS_FRIENDS;
                        } else {
                            this.accessLevel = ACCESS_GROUPS;
                        }
                    }                            
                }
            }
        }
        
        /* Get properties (who the hell designed this protocol???) */
        int propCount = data.getCount("prop_count");
        for (int i = 1; i <= propCount; i++) {
            String pref = "prop_" + Integer.toString(i) + "_";
            value = data.get(pref + "itemid");
            if ((value != null) && (Integer.parseInt(value) == m_itemID)) {
                String propValue = data.get(pref + "value");
                value = data.get(pref + "name");
                if (value != null) {
                    if (value.equals("taglist")) {
                        setTagList(propValue);
                    }
                    if (value.equals("current_music")) {
                        setMusic(propValue);
                    }
                    if (value.equals("current_location")) {
                        setLocation(propValue);
                    }
                    if (value.equals("current_mood")) {
                        setMood(-1, propValue);
                    }
                    if (value.equals("current_moodid")) {
                        setMood(Integer.parseInt(propValue), "");
                    }
                    if (value.equals("opt_backdated")) {
                        setBackdate(propValue.equals("1"));
                    }
                    if (value.equals("opt_preformatted")) {
                        setNoAutoFormat(propValue.equals("1"));
                    }
                    if (value.equals("opt_noemail")) {
                        setNoEmail(propValue.equals("1"));
                    }
                    if (value.equals("opt_nocomments")) {
                        setNoComments(propValue.equals("1"));
                    }
                    if (value.equals("opt_screening")) {
                        setScreeningTypeString(propValue);
                    }
                    if (value.equals("picture_keyword")) {
                        setUserpic(propValue);
                    }
                }
            }
        }
    }
    
    private void addElement(Document doc, Element root, String name, String value) {
        Element e = doc.createElement(name);
        e.setAttribute("value", value);
        root.appendChild(e);
    }
    
    /**
     * Saves event to XML document.
     * @param doc Document that must be created by the caller
     */
    public void toXML(org.w3c.dom.Document doc) {
        Text textNode = null;
        Element e = null;
        
        Element root = doc.createElement("post");
        
        doc.appendChild(root);

        addElement(doc, root, "id", Integer.toString(getID()));
        addElement(doc, root, "journal", getJournal());
        addElement(doc, root, "poster", getPoster());
        addElement(doc, root, "subject", getSubject());
        addElement(doc, root, "body", getBody());
        if (getDate() != null) {
            addElement(doc, root, "date", LJHelpers.dateFormat.format(getDate()));
        }
        addElement(doc, root, "backdate", Boolean.toString(getBackdate()));
        addElement(doc, root, "noemail", Boolean.toString(getNoEmail()));
        addElement(doc, root, "noautoformat", Boolean.toString(getNoAutoFormat()));
        addElement(doc, root, "tags", getTagList());
        addElement(doc, root, "userpic", getUserpic());
        addElement(doc, root, "location", getLocation());
        addElement(doc, root, "music", getMusic());
        addElement(doc, root, "groupmask", Integer.toString(getGroupMask()));
        addElement(doc, root, "moodid", Integer.toString(getMoodID()));
        addElement(doc, root, "moodtext", getMoodText());
        addElement(doc, root, "accesslevel", Integer.toString(getAccessLevel()));
        addElement(doc, root, "screen", Integer.toString(getScreeningType()));        
    }
    
    /**
     * Loads event from XML document.
     * @param doc Document that must be created by the caller
     */
    public void fromXML(org.w3c.dom.Document doc) {
        Element root = doc.getDocumentElement();
        NodeList children = root.getChildNodes();
        
        for (int i = 0; i < children.getLength(); i++) {
            Node node = children.item(i);
            if (node instanceof Element) {
                Element e = (Element)node;
                String name = e.getTagName();
                String value = e.getAttribute("value");
                
                if (name.equals("id")) {
                    setID(Integer.parseInt(value));
                    continue;
                }
                
                if (name.equals("journal")) {
                    setJournal(value);
                    continue;
                }

                if (name.equals("poster")) {
                    setPoster(value);
                    continue;
                }
                
                if (name.equals("subject")) {
                    setSubject(value);
                    continue;
                }
                
                if (name.equals("body")) {
                    setBody(value);
                    continue;
                }
                
                if (name.equals("backdate")) {
                    setBackdate(Boolean.parseBoolean(value));
                    continue;
                }
                
                if (name.equals("noemail")) {
                    setNoEmail(Boolean.parseBoolean(value));
                    continue;
                }
                
                if (name.equals("noautoformat")) {
                    setNoAutoFormat(Boolean.parseBoolean(value));
                    continue;
                }
                
                if (name.equals("tags")) {
                    setTagList(value);
                    continue;
                }
                
                if (name.equals("userpic")) {
                    if (value.length() == 0) {
                        value = null;
                    }
                    setUserpic(value);
                    continue;
                }
                
                if (name.equals("location")) {
                    setLocation(value);
                    continue;
                }
                
                if (name.equals("music")) {
                    setMusic(value);
                    continue;
                }
                
                if (name.equals("moodid")) {
                    setMoodID(Integer.parseInt(value));
                    continue;
                }
                
                if (name.equals("moodtext")) {
                    setMoodText(value);
                    continue;
                }
                
                if (name.equals("screen")) {
                    setScreeningType(Integer.parseInt(value));
                    continue;
                }
                
                if (name.equals("accesslevel")) {
                    accessLevel = Integer.parseInt(value);
                    continue;
                }

                if (name.equals("groupmask")) {
                    groupMask = Integer.parseInt(value);
                    continue;
                }
                
                try {
                    if (name.equals("date")) {
                        setDate(LJHelpers.dateFormat.parse(value));
                        continue;
                    }
                }
                catch (ParseException ex) {
                    setDate(new Date());
                }
            }
        }
    }    
}
