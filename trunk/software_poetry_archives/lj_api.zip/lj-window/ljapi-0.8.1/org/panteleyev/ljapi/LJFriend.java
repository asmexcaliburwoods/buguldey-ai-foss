/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

/**
 * This class represents LiveJournal friend and friend of
 * @author Petr Panteleyev
 */
public class LJFriend {
    public final static int RELATION_MUTUAL            = 1;
    public final static int RELATION_FRIEND_OF         = 2;
    public final static int RELATION_FRIEND     = 3;
    
    public final static int TYPE_COMMUNITY             = 1;
    public final static int TYPE_SYNDICATED            = 2;
    
    public final static int STATUS_NORMAL       = 0;
    public final static int STATUS_DELETED      = 1;
    public final static int STATUS_SUSPENDED    = 2;
    public final static int STATUS_PURGED       = 3;
    
    private String userName;
    private String fullName;
    private int relation;
    private boolean community;
    private int groupMask;
    private int changedGroupMask;
    private int type;
    private int status;
    private int bg;
    private int fg;
    private String birthday;
    
    private boolean edit;
    
    /**
     * Creates a new instance of LJFriend
     */
    public LJFriend(String userName) {
        this.relation = RELATION_FRIEND;
        this.userName = userName;
        this.birthday = "";
        this.edit = false;
    }
   
    /**
     * Sets full name of the friend
     * @param fullName Full name of the friend
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    /**
     * Parses response from LiveJournal server
     * Only data related to friend are parsed, everything else is just ignored.
     * @param data Hash received from server
     * @param prefix Prefix for this particular friend. All friend related data
     * start from &quot;friend_n_&quot; prefix. Calling code must supply this prefix,
     * for example <i>friend_10_</i>.
     */
    public void parseResponse(LJRawResult data, String prefix) {
        if ((data == null) || (prefix == null))
            return;

        String value;
        
        value = data.get(prefix + "name");
        if (value != null) {
            setFullName(value);
        }
        
        value = data.get(prefix + "birthday");
        if (value != null) {
            setBirthday(value);
        }

        value = data.get(prefix + "fg");
        if (value != null) {
            setFg(LJHelpers.HTMLtoRGB(value));
        }

        value = data.get(prefix + "bg");
        if (value != null) {
            setBg(LJHelpers.HTMLtoRGB(value));
        }
        
        value = data.get(prefix + "type");
        if (value != null) {
            if (value.equals("community")) {
                setCommunity();
            }
            if (value.equals("syndicated")) {
                setSyndicated();
            }
        }
        
        setStatus(STATUS_NORMAL);
        value = data.get(prefix + "status");
        if (value != null) {
            if (value.equals("deleted")) {
                setStatus(STATUS_DELETED);
            } else {
                if (value.equals("suspended")) {
                    setStatus(STATUS_SUSPENDED);
                } else {
                    if (value.equals("purged")) {
                        setStatus(STATUS_PURGED);
                    }
                }
            }
        }

        value = data.get(prefix + "groupmask");
        if (value != null) {
            setGroupMask(Integer.parseInt(value));
        }
        
    }
    
    /**
     * Returns user (account) name of the friend provided by LiveJournal server
     * @return User name
     */
    public String getUserName() { return this.userName; }
    
    /**
     * Returns full name of the friend provided by LiveJournal server
     * @return Full name
     */
    public String getFullName() { return this.fullName; }
    
    /**
     * Makes this friend a mutual friend
     */
    public void setMutual() { this.relation = RELATION_MUTUAL; }
    
    /**
     * Makes this friend a &quot;friend of&quot;
     */
    public void setFriendOf() { this.relation = RELATION_FRIEND_OF; }

    /**
     * Checks if the friend is a friend
     * @return <code>true</code> if the friend is a friend
     */
    public boolean isFriend() { return this.relation == RELATION_FRIEND; }
    
    /**
     * Checks if the friend is a mutual friend
     * @return <code>true</code> if the friend is a mutual friend
     */
    public boolean isMutual() { return this.relation == RELATION_MUTUAL; }
    
    /**
     * Checks if the friend is a 'friend of'
     * @return <code>true</code> if the friend is a 'friend of'
     */
    public boolean isFriendOf() { return this.relation == RELATION_FRIEND_OF; }
    
    public void setCommunity() { this.type = TYPE_COMMUNITY; }
    public boolean isCommunity() { return this.type == TYPE_COMMUNITY; }
    
    public void setSyndicated() { this.type = TYPE_SYNDICATED; }
    public boolean isSyndicated() { return this.type == TYPE_SYNDICATED; }
    
    public void setGroupMask(int groupMask) { 
        if (!edit) {
            this.groupMask = groupMask; 
        }
        this.changedGroupMask = groupMask; 
    }
    
    public int getGroupMask() {
        return (edit)? this.changedGroupMask : this.groupMask; 
    }
    
    public int getRelation() { return this.relation; }
    public void setRelation(int relation) { this.relation = relation; }
    
    public int getType() { return this.type; }
    public void setType(int type) { this.type = type; }
    
    public int getStatus() { return this.status; }
    public void setStatus(int status) { this.status = status; }
    
    public void setBg(int bg) { this.bg = bg; }
    public int getBg() { return this.bg; }
    
    public void setFg(int fg) { this.fg = fg; }
    public int getFg() { return this.fg; }
    
    public void setBirthday(String bd) { this.birthday = bd; }
    public String getBirthday() { return this.birthday; }
  
    /**
     * Turns the edit mode on
     * Edit mode is usually used by the application to edit the groups for the
     * friend. In the Edit mode all changes to the group mask are not applied
     * to actual field but to temporary buffer.
     */
    public void edit() { this.edit = true; }
    
    /**
     * Returns the status of the Edit mode
     * @return Edit mode status
     */
    public boolean getEdit() { return this.edit; }
    
    /**
     * Applies changes to the actual fields and turns the Edit mode off
     */
    public void applyChanges() {
        this.groupMask = this.changedGroupMask;
        this.edit = false;
    }
    
    /**
     * Cancels changes made to the friend and turns the Edit mode off
     */
    public void cancelChanges() {
        this.changedGroupMask = this.groupMask;
        this.edit = false;
    }
    
    /**
     * Adds the friend to the specified group
     * @param group Group to add the friend to
     */
    public void addToGroup(LJGroup group) {
        setGroupMask(getGroupMask() | (1 << group.getNumber()));
    }
    
    /**
     * Removes the friend from the specified group
     * @param group Group to remove the friend from
     */
    public void removeFromGroup(LJGroup group) {
        setGroupMask(getGroupMask() & ~(1 << group.getNumber()));
    }
    
    /** 
     * Checks is the friend is a member of the specified group
     * @param group Group to check
     */
    public boolean isInGroup(LJGroup group) {
        return (getGroupMask() & (1 << group.getNumber())) != 0;
    }
}
