/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

import java.util.*;

/**
 * This class provides the container for the friends loaded from server or restored
 * from the local cash
 * @author Petr Panteleyev
 */
public final class LJFriendList {
    private int m_friendCount;
    private int m_friendOfCount;
    private int m_mutualCount;
    private int m_communityCount;
    private int m_syndicatedCount;
    
    private HashMap<String,LJFriend> m_hash;
    private ArrayList<LJFriend> m_friendArray;
    
    /** Creates a new instance of LJFriendList */
    public LJFriendList() {
        m_hash = new HashMap<String, LJFriend>();
        m_friendArray = new ArrayList<LJFriend>();
    }
   
    /**
     * Clears all lists and counters
     * This method must be called prior to restoring friends from local cash. During
     * this process LJFriend objects are added to the list manually.
     */
    public void clear() {
        m_hash.clear();
        m_friendArray.clear();
        clearCounters();
    }
    
    /**
     * Loads the friend list from LiveJournal server data
     * @param data Hash table returned by the LiveJournal server. The method parses
     * this data, creates <code>LJFriend</code> objects and adds them to the list.
     * @param change changes in the friends list
     * @param ph Progress callback. May be <code>null</code>
     * @throws LJException in case of error
     */
    public void load(LJRawResult data, ArrayList<LJFriendChange> change, LJProgressCallback ph) throws LJException {
        // This is full reload so clear all keys first
        clearCounters();
        
        String value;
        
        // Get counters
        m_friendCount = Math.max(data.getInt("friend_count", 0), 0);
        m_friendOfCount = Math.max(data.getInt("friendof_count", 0), 0);
        
        HashMap<String, LJFriend> newHash = new HashMap<String, LJFriend>(m_friendCount + m_friendOfCount);
        
        // Set progress handler limits
        if (ph != null) {
            ph.setMinimum(1);
            ph.setMaximum(m_friendCount + m_friendOfCount);
            ph.setValue(0);
        }
        
        int prgValue = 1;
        
        // Load friends
        for (int i = 1; i <= m_friendCount; i++) {                    
            String prefix = "friend_" + Integer.toString(i) + "_";

            value = data.get(prefix + "user");
            if (value != null) {
                LJFriend friend = new LJFriend(value);
                friend.parseResponse(data, prefix);
                newHash.put(friend.getUserName(), friend);
                
                if (friend.isSyndicated()) {
                    m_syndicatedCount++;
                }            
            }

            if (ph != null) {
                ph.setValue(prgValue++);
            }
        }
        
        // load friend ofs
        for (int i = 1; i <= m_friendOfCount; i++) {
            String prefix = "friendof_" + Integer.toString(i) + "_";
            value = data.get(prefix + "user");
            if (value != null) {
                LJFriend friend = newHash.get(value);
                if (friend != null) {
                    friend.setMutual();
                    m_mutualCount++;
                } else {
                    friend = new LJFriend(value);
                    friend.setFriendOf();
                    friend.parseResponse(data, prefix);                                                    
                    newHash.put(friend.getUserName(), friend);
                }

                if (friend.isCommunity()) {
                    m_communityCount++;
                }
            }

            if (ph != null) {
                ph.setValue(prgValue++);
            }
        }
        
        if (change != null) {
            
            /* Check for added or changed friends */
            for (LJFriend f : newHash.values()) {                                
                LJFriend oldF = m_hash.get(f.getUserName());
                                                
                /* New friend */
                if (oldF == null) {
                    LJFriendChangeType cType = LJFriendChangeType.NO_CHANGE;
                    switch (f.getRelation()) {
                        case LJFriend.RELATION_FRIEND:
                            cType = LJFriendChangeType.YOU_ADDED;
                            break;                         
                        case LJFriend.RELATION_FRIEND_OF:
                            cType = LJFriendChangeType.ADDED_YOU;
                            break;                            
                        case LJFriend.RELATION_MUTUAL:
                            cType = LJFriendChangeType.ADDED_MUTUALLY;
                            break;
                    }
                    
                    if (cType != LJFriendChangeType.NO_CHANGE) {
                        change.add(new LJFriendChange(f.getUserName(), cType));
                    }
                } else {
                    /* Check journal status changes */
                    if (f.getStatus() != oldF.getStatus()) {
                        LJFriendChangeType cType = LJFriendChangeType.NO_CHANGE;
                        switch (f.getStatus()) {
                            case LJFriend.STATUS_NORMAL:
                                cType = LJFriendChangeType.JOURNAL_RESTORED;
                                break;
                            case LJFriend.STATUS_DELETED:
                                cType = LJFriendChangeType.JOURNAL_DELETED;
                                break;
                            case LJFriend.STATUS_SUSPENDED:
                                cType = LJFriendChangeType.JOURNAL_SUSPENDED;
                                break;
                            case LJFriend.STATUS_PURGED:
                                cType = LJFriendChangeType.JOURNAL_PURGED;
                                break;
                        }
                        
                        if (cType != LJFriendChangeType.NO_CHANGE) {
                            change.add(new LJFriendChange(f.getUserName(), cType));
                        }
                    }
                        
                    /* Check relationship changes */
                    if (f.getRelation() != oldF.getRelation()) {
                        LJFriendChangeType cType = LJFriendChangeType.NO_CHANGE;
                        switch (f.getRelation()) {
                            case LJFriend.RELATION_FRIEND:
                                if (oldF.getRelation() == LJFriend.RELATION_MUTUAL) {
                                    cType = LJFriendChangeType.REMOVED_YOU;
                                } else {
                                    cType = LJFriendChangeType.YOU_ADDED; 
                                }
                                break;
                            case LJFriend.RELATION_FRIEND_OF:
                                if (oldF.getRelation() == LJFriend.RELATION_MUTUAL) {
                                    cType = LJFriendChangeType.YOU_REMOVED;
                                } else {
                                    cType = LJFriendChangeType.ADDED_YOU;
                                }
                                break;
                            case LJFriend.RELATION_MUTUAL:
                                if (oldF.getRelation() == LJFriend.RELATION_FRIEND) {
                                    cType = LJFriendChangeType.ADDED_YOU;
                                } else {
                                    cType = LJFriendChangeType.YOU_ADDED;
                                }
                                break;
                        }
                        
                        if (cType != LJFriendChangeType.NO_CHANGE) {
                            change.add(new LJFriendChange(f.getUserName(), cType));
                        }
                    }
                }                
            }
            
            /* Check for removed friends */
            for (LJFriend f : m_hash.values()) {                                
                LJFriend newF = newHash.get(f.getUserName());
                if (newF == null) {
                    LJFriendChangeType cType = LJFriendChangeType.NO_CHANGE;                    
                    switch (f.getRelation()) {
                        case LJFriend.RELATION_FRIEND:
                            cType = LJFriendChangeType.YOU_REMOVED;
                            break;
                        case LJFriend.RELATION_FRIEND_OF:
                            cType = LJFriendChangeType.REMOVED_YOU;
                            break;
                        case LJFriend.RELATION_MUTUAL:
                            cType = LJFriendChangeType.REMOVED_MUTUALLY;
                            break;                          
                    }
                    
                    if (cType != LJFriendChangeType.NO_CHANGE) {
                        change.add(new LJFriendChange(f.getUserName(), cType));
                    }
                }
            }            
        }
        
        m_hash = newHash;
        m_friendArray = new ArrayList<LJFriend>(m_hash.values());
    }

    /**
     * Loads the friend list from LiveJournal server data
     * @param data Hash table returned by the LiveJournal server. The method parses
     * this data, creates <code>LJFriend</code> objects and adds them to the list.
     * @param ph Progress callback. May be <code>null</code>
     * @throws LJException in case of error
     */
    public void load(LJRawResult data, LJProgressCallback ph) throws LJException {
        load(data, null, ph);
    }
    
    /**
     * Method intended for restoring friends from some local storage
     */
    public void restoreFriend(LJFriend f) {
        m_hash.put(f.getUserName(), f);
        m_friendArray.add(f);
        updateCounters(f);
    }
    
    /**
     * Adds the specified friend to the list
     * @param f Friend to add
     */
    void addFriend(LJFriend f) {
        LJFriend old = m_hash.get(f.getUserName());
        if (old == null) {
            m_hash.put(f.getUserName(), f);
            m_friendArray.add(f);
        } else {
            if (old.getRelation() == LJFriend.RELATION_FRIEND_OF) {
                old.setRelation(LJFriend.RELATION_MUTUAL);
            }
            old.setGroupMask(f.getGroupMask());
            old.setFg(f.getFg());
            old.setBg(f.getBg());
            old.setFullName(f.getFullName());
        }
        
        updateCounters();
    }
    
    /**
     * Returns the friend according to its index
     * @param index Index of the friend. Must be in [0 .. LJFriend.size()]
     * @return Friend or <code>null</code> if the index is out of range
     */
    public LJFriend getFriend(int index) {
        if (m_friendArray == null) {
            return null;
        } else {
            return m_friendArray.get(index);
        }
    }
    
    /**
     * Returns the friend according to its account name
     * @param username Name of the friend on the LiveJournal server
     * @return Friend or <code>null</code> if the friend with such a user name does
     * not exist
     */
    public LJFriend getFriend(String username) {
        return m_hash.get(username);
    }
    
    /**
     * Removes the specified friend from the list
     * If the friend was mutual then it's not removed, only relation is modified
     * @param friend Friend to remove
     */
    public void removeFriend(LJFriend friend) {
        if (friend.getRelation() == LJFriend.RELATION_MUTUAL) {
            friend.setRelation(LJFriend.RELATION_FRIEND_OF);
            friend.setGroupMask(0);
        } else {
            m_friendArray.remove(friend);
            m_hash.remove(friend.getUserName());
        }
        updateCounters();
    }

    private void updateCounters(LJFriend f) {
        switch (f.getRelation()) {
            case LJFriend.RELATION_MUTUAL:
                m_friendOfCount++;
                m_mutualCount++;
                m_friendCount++;
                if (f.getType() == LJFriend.TYPE_COMMUNITY) {
                    m_communityCount++;
                }
                if (f.getType() == LJFriend.TYPE_SYNDICATED) {
                    m_syndicatedCount++;
                }
                break;
            
            case LJFriend.RELATION_FRIEND:
                m_friendCount++;
                if (f.getType() == LJFriend.TYPE_SYNDICATED) {
                    m_syndicatedCount++;
                }
                break;
                
            case LJFriend.RELATION_FRIEND_OF:
                m_friendOfCount++;
                if (f.getType() == LJFriend.TYPE_COMMUNITY) {
                    m_communityCount++;
                }
                break;
        }
    }
    
    private void clearCounters() {
        m_friendCount = 0;
        m_friendOfCount = 0;
        m_mutualCount = 0;
        m_communityCount = 0;
        m_syndicatedCount = 0;
    }
    
    private void updateCounters() {
        clearCounters();
        
        for (LJFriend f : m_friendArray) {
            updateCounters(f);
        }
    }
    
    public ArrayList<LJFriend> getFriendArray() { return m_friendArray; }
    public ArrayList<LJFriend> getFriendArrayClone() { return (ArrayList<LJFriend>)m_friendArray.clone(); }
    
    public int getFriendCount() { return m_friendCount; }
    public int getFriendOfCount() { return m_friendOfCount - m_communityCount; }
    public int getMutualCount() { return m_mutualCount; }
    public int getCommunityCount() { return m_communityCount; }
    public int getSyndicatedCount() { return m_syndicatedCount++; }
    
    /**
     * Returns the number of friends in the list
     * @return Number of friends
     */
    public int size() { return m_friendArray.size(); }
}
