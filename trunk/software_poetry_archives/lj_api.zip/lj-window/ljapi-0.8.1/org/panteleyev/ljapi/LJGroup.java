/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

/**
 * This class represents user group.
 * @author Petr Panteleyev
 */
public class LJGroup implements Comparable<LJGroup>, Cloneable {
    private int m_number;
    private String m_name;
    private boolean pub;
    private int sortOrder;
    
    /* Special field for clients that allows for creating new groups 
     * If the group is temporary then deletion is just local 
     */
    private boolean temporary;
   
    /**
     * Creates a new instance of the LJGroup with the specified number
     * @param number Number of the group
     * @param name Name of the group
     */
    public LJGroup(int number, String name) {
        m_number = number;
        m_name = name;
    }
    
    /**
     * Creates a new instance of the LJGroup
     * @param name Name of the group
     */
    public LJGroup(String name) {
        m_name = name;
    }

    /**
     * Sets sort order for the group
     * @param order Sort order
     */
    public void setSortOrder(int order) { this.sortOrder = order; }
    
    /**
     * Sets the public flag for the group
     * @param pub Public flag
     */
    public void setPublic(boolean pub) { this.pub = pub; }
    
    /**
     * Returns the public status of the group
     * @return Public status
     */
    public boolean isPublic() { return this.pub; }

    /**
     * Compares two groups according to their sorting order
     * @param grp Another group to compare with
     * @return Comparison value
     */
    public int compareTo(LJGroup grp) {
        return this.sortOrder - grp.sortOrder;
    }
    
    /**
     * Returns the group number
     * @return Group number
     */
    public int getNumber() { return m_number; }
    
    /**
     * Sets the group number
     * @param num Group number
     */
    public void setNumber(int num) { m_number = num; }

    /**
     * Returns the name of the group
     * @return Name of the group
     */
    public String getName() { return m_name; }
    
    /**
     * Clones the LJGroup object
     * @return Clone of the group
     */
    public LJGroup clone() {
        LJGroup c = null;
        
        try {
            c = (LJGroup)super.clone();
        }
        catch (CloneNotSupportedException e) {}
        
        return c;
    }
    
    /**
     * Returns the temporary status of the group
     * Temporary groups are used to edit the group list in the client.
     * @return Temporary status
     */
    public boolean isTemporary() { return this.temporary; }
    
    /**
     * Sets the temporary status of the group
     * Temporary groups are used to edit the group list in the client.
     * @param temp Status
     */
    public void setTemporary(boolean temp) { this.temporary = temp; }
}
