/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

import java.text.*;

/**
 * Various functions - converters, encoders, etc.
 */
public class LJHelpers {
    public static SimpleDateFormat dateFormat;

    public static String bytesToHex(byte[] buf) {
        StringBuilder b = new StringBuilder(buf.length * 2);

        for (int i = 0; i < buf.length; i++) {
            int cell = (int)(buf[i] & 0xFF);
            if (cell < 16) {
                b.append("0");
            }

            b.append(Integer.toString(cell, 16));
        }

        return b.toString();
    }

    /**
     * Produces MD5 hash for the specified string
     * @param s String to encode
     * @return MD5 hash
     */
    public static String MD5Encode(String s) {
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            return bytesToHex(md.digest(s.getBytes()));
        } catch (Exception e) {
            return "";
        }        
    }
    
    /**
     * Parses HTML color representation
     * @param htmlColor HTML representation of the color #RRGGBB
     * @return Integer color value
     */
    public static int HTMLtoRGB(String htmlColor) {
        return Integer.parseInt(htmlColor.replace("#", ""), 16);
    }
    
    /**
     * Produces HTML color representation
     * @param rgb Integer coloe value
     * @return HTML color representation
     */
    public static String RGBtoHTML(int rgb) {
        StringBuilder b = new StringBuilder("0000000");
        b.replace(0, 1, "#");
        for (int i = 5; i > 0; i -= 2) {
            int bt = rgb & 0xFF;
            rgb = rgb >> 8;
            StringBuilder b2 = new StringBuilder(Integer.toString(bt, 16));
            if (bt < 16) {
                b2.insert(0, "0");
            }
            b.replace(i, i + 2, b2.toString());
        }
        
        return b.toString();
    }        
    
    static {
        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    }
}
