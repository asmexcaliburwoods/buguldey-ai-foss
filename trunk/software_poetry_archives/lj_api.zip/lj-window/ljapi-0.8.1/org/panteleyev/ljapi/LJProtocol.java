/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

import java.io.*;
import java.text.*;
import java.net.*;
import java.util.*;

/**
 * This class provides LiveJournal protocol implementation.
 * @author Petr Panteleyev
 */
final class LJProtocol {
    LJConnection m_conn;
    String authString;
    
    private static SimpleDateFormat dateFormat;
    
    /** Creates a new instance of the LJProtocol */
    public LJProtocol(LJConnection conn) {
        m_conn = conn;
    }
    
    /**
     * Performs login to the specified account
     * @param userName Name of the account as it is on LiveJournal
     * @param md5Passwd MD5 hash of the password
     * @param maxMoodID Maximum mood id retrieved from server. If no moods were retrieved yet
     * 0 must be set here.
     * @return Hash table of the data returned by the server
     * @throws LJException in case of error
     */
    public LJRawResult login(String userName, String md5Passwd, int maxMoodID) throws LJException {
        StringBuilder b = new StringBuilder("");
        b.append("&user=");
        b.append(userName);
        b.append("&hpassword=");
        b.append(md5Passwd);
        this.authString = b.toString();

        b = new StringBuilder("mode=login");
        b.append(this.authString);
        b.append("&ver=1&getpickws=1&getpickwurls=1&getmoods=");
        b.append(Integer.toString(maxMoodID));
        b.append("&clientversion=Java-LJWindow/0.1.1");
                
        LJRawResult data = m_conn.sendRequest(b.toString());
        
        /* Check for fast server */
        String value = data.get("fastserver");
        m_conn.setFastServer((value != null) && (value.equals("1")));
        
        return data;
    }
    
    public LJRawResult getFriends(boolean includeFriendOf, LJProgressCallback ph) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();
        
        StringBuilder b = new StringBuilder("mode=getfriends");
        b.append(this.authString);
        b.append("&ver=1&includebdays=1");
        
        if (includeFriendOf) {
            b.append("&includefriendof=1");
        }
        
        return m_conn.sendRequest(b.toString());
    }
    
    public LJRawResult deleteFriend(String username) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();
        
        StringBuilder b = new StringBuilder("mode=editfriends");
        b.append(this.authString);
        b.append("&ver=1&editfriend_delete_");
        b.append(username);
        b.append("=1");
        return m_conn.sendRequest(b.toString());        
    }
    
    public LJRawResult updateFriend(LJFriend f) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();
        
        StringBuilder b = new StringBuilder("mode=editfriends");
        b.append(this.authString);
        b.append("&ver=1");
        b.append("&editfriend_add_1_user=");
        b.append(f.getUserName());
        b.append("&editfriend_add_1_fg=");
        b.append(LJHelpers.RGBtoHTML(f.getFg()));
        b.append("&editfriend_add_1_bg=");
        b.append(LJHelpers.RGBtoHTML(f.getBg()));
        b.append("&editfriend_add_1_groupmask=");
        b.append(Integer.toString(f.getGroupMask()));
        LJRawResult data = m_conn.sendRequest(b.toString());
        f.parseResponse(data, "friend_1_");
        return data;
    }
    
    public int addFriend(LJFriend f) throws LJException {
        LJRawResult data = updateFriend(f);        
        return data.getInt("friends_added");
    }
    
    public void postEvent(LJEvent event) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        try {
            int id = event.getID();

            StringBuffer b = new StringBuffer("");
            if (id == -1) {
                b.append("mode=postevent");
            } else {
                b.append("mode=editevent");
            }

            b.append(this.authString);
            b.append("&ver=1");

            if (id != -1) {
                b.append("&itemid=");
                b.append(Integer.toString(event.getID()));
            }

            b.append("&event=");
            b.append(URLEncoder.encode(event.getBody(), "UTF-8"));
            b.append("&subject=");
            b.append(URLEncoder.encode(event.getSubject(), "UTF-8"));

            if (event.getUserpic() != null) {
                b.append("&prop_picture_keyword=");
                b.append(event.getUserpic());
            }

            // Screening type
            b.append("&prop_opt_screening=");
            b.append(event.getScreeningTypeString());

            b.append("&security=");
            switch (event.getAccessLevel()) {
                case LJEvent.ACCESS_PUBLIC:
                    b.append("public");
                    break;

                case LJEvent.ACCESS_PRIVATE:
                    b.append("private");
                    break;

                case LJEvent.ACCESS_FRIENDS:
                case LJEvent.ACCESS_GROUPS:
                    b.append("usemask&allowmask=");
                    b.append(Integer.toString(event.getGroupMask()));
                    break;

            }

            Calendar cal = new GregorianCalendar();
            Date date = event.getDate();

            if (date != null) {
                cal.setTime(date);
            }

            b.append("&year=");
            b.append(Integer.toString(cal.get(Calendar.YEAR)));
            b.append("&mon=");
            b.append(Integer.toString(cal.get(Calendar.MONTH) + 1));
            b.append("&day=");
            b.append(Integer.toString(cal.get(Calendar.DAY_OF_MONTH)));
            b.append("&hour=");
            b.append(Integer.toString(cal.get(Calendar.HOUR_OF_DAY)));
            b.append("&min=");
            b.append(Integer.toString(cal.get(Calendar.MINUTE)));

            if (event.getBackdate()) {
                b.append("&prop_opt_backdated=1");
            }

            if (event.getNoAutoFormat()) {
                b.append("&prop_opt_preformatted=1");
            }

            if (event.getNoEmail()) {
                b.append("&prop_opt_noemail=1");
            }

            if (event.getNoComments()) {
                b.append("&prop_opt_nocomments=1");
            }

            // Current Mood
            if (event.getMoodID() != -1) {
                b.append("&prop_current_moodid=");
                b.append(Integer.toString(event.getMoodID()));
            } else {
                if (event.getMoodText() != null) {
                    b.append("&prop_current_mood=");
                    b.append(URLEncoder.encode(event.getMoodText(), "UTF-8"));
                }
            }

            // Current Music
            String music = event.getMusic();
            if ((music != null) && (music.length() != 0)) {
                b.append("&prop_current_music=");
                b.append(URLEncoder.encode(music, "UTF-8"));
            }

            // Current Location
            String location = event.getLocation();
            if ((location != null) && (location.length() != 0)) {
                b.append("&prop_current_location=");
                b.append(URLEncoder.encode(location, "UTF-8"));
            }

            // Use Journal
            String journal = event.getJournal();
            if (journal.length() != 0) {
                b.append("&usejournal=");
                b.append(event.getJournal());
            }

            // Tags
            String tagList = event.getTagList();
            if (tagList.length() != 0) {
                b.append("&prop_taglist=");
                b.append(URLEncoder.encode(tagList, "UTF-8"));
            }

            LJRawResult data = m_conn.sendRequest(b.toString());
            
            event.setID(data.getInt("itemid"));
        }
        catch (UnsupportedEncodingException e) {
            throw new LJProgrammingException(e.getMessage());
        }
    }
    
    public void loadLastEntry(LJEvent event) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        StringBuilder b = new StringBuilder("mode=getevents");
        b.append(this.authString);
        b.append("&ver=1");

        b.append("&selecttype=one");
        b.append("&itemid=-1");
        b.append("&lineendings=unix");
        
        LJRawResult data = m_conn.sendRequest(b.toString());
        event.parseResponse(data, "events_1_");
    }
    
    public void deleteEvent(LJEvent event) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        StringBuilder b = new StringBuilder("mode=editevent");
        b.append(this.authString);
        b.append("&ver=1");

        b.append("&itemid=");
        b.append(Integer.toString(event.getID()));
                
        // Use Journal
        String journal = event.getJournal();
        if (journal.length() != 0) {
            b.append("&usejournal=");
            b.append(event.getJournal());
        }        
        
        b.append("&event=");
        
        LJRawResult data = m_conn.sendRequest(b.toString());        
    }
    
    public void saveGroups(ArrayList<LJGroup> groups, ArrayList<LJGroup> toDelete, ArrayList<LJFriend> friends) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        StringBuilder b = new StringBuilder("mode=editfriendgroups");
        b.append(this.authString);
        b.append("&ver=1");

        for (LJGroup g : toDelete) {
            b.append("&efg_delete_");
            b.append(Integer.toString(g.getNumber()));
            b.append("=1");
        }
        
        for (int index = 0; index < groups.size(); index++) {
            LJGroup g = groups.get(index);

            StringBuilder prefix = new StringBuilder("&efg_set_");
            prefix.append(Integer.toString(g.getNumber()));
            prefix.append("_");

            b.append(prefix);
            b.append("name=");
            try {
                b.append(URLEncoder.encode(g.getName(), "UTF-8"));
            }
            catch (Exception e) {
                throw new LJProgrammingException(e.getMessage());
            }

            b.append(prefix);
            b.append("sort=");
            b.append(Integer.toString(index));

            b.append(prefix);
            b.append("public=");
            if (g.isPublic()) {
                b.append("1");
            } else {
                b.append("0");
            }           
        }

        for (LJFriend f : friends) {
            b.append("&editfriend_groupmask_");
            b.append(f.getUserName());
            b.append("=");
            b.append(Integer.toString(f.getGroupMask()));
        }
        
        m_conn.sendRequest(b.toString());
    }
    
    public boolean consoleCommand(String cmd, ArrayList<String> res) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        StringBuilder b = new StringBuilder("mode=consolecommand");
        b.append(this.authString);
        b.append("&ver=1");

        b.append("&command=");
        try {
            b.append(URLEncoder.encode(cmd, "UTF-8"));
        }
        catch (Exception e) {
            throw new LJProgrammingException(e.getMessage());
        }
        
        LJRawResult hash = m_conn.sendRequest(b.toString());
        
        boolean bRes;
        res.clear();
        
        String value = hash.get("cmd_success");
        bRes = ((value != null) && (value.equals("1")));
        
        int count = hash.getCount("cmd_line_count");
        
        for (int i = 1; i <= count; i++) {
            value = hash.get("cmd_line_" + Integer.toString(i));
            if (value != null) {
                res.add(value);
            }
        }
        
        return bRes;
    }
    
    public ArrayList<LJEvent> loadHistory(int trunc, int howMany, Date beforeDate, String useJournal) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        StringBuilder b = new StringBuilder("mode=getevents");
        b.append(this.authString);
        b.append("&ver=1");
        
        /* Load subjects only */
        b.append("&prefersubject=1");
        
        /* Truncate to some reasonable value */
        b.append("&truncate=");
        b.append(Integer.toString(trunc));
        
        /* Ask to load some number */
        b.append("&selecttype=lastn");
        b.append("&howmany=");
        b.append(Integer.toString(howMany));
        
        if (beforeDate != null) {
            b.append("&beforedate=");
            b.append(dateFormat.format(beforeDate));
        }
        
        b.append("&lineendings=unix");
        
        b.append("&usejournal=");
        b.append(useJournal);
        
        LJRawResult hash = m_conn.sendRequest(b.toString());
        
        int count = hash.getCount("events_count");
        
        ArrayList<LJEvent> events = new ArrayList<LJEvent>(count);

        for (int i = 1; i <= count; i++) {
            LJEvent event = new LJEvent();
            event.parseResponse(hash, "events_" + Integer.toString(i) + "_");
            event.setJournal(useJournal);
            events.add(event);
        }
        
        return events;
    }
    
    public LJEvent loadEvent(int id, String useJournal) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        StringBuilder b = new StringBuilder("mode=getevents");
        b.append(this.authString);
        b.append("&ver=1");

        b.append("&selecttype=one");
        b.append("&itemid=");
        b.append(Integer.toString(id));
        b.append("&lineendings=unix");
        b.append("&usejournal=");
        b.append(useJournal);
        
        LJRawResult data = m_conn.sendRequest(b.toString());
        
        LJEvent event = new LJEvent();
        event.parseResponse(data, "events_1_");
        event.setJournal(useJournal);
        return event;
    }
    
    /**
     * Loads user tags
     * @param tags Tags array that will be filled by the tags
     * @throws LJException In case of error
     */
    public void loadUserTags(ArrayList<LJTag> tags, LJProgressCallback ph) throws LJException {
        if (this.authString == null)
            throw new LJNotLoggedInException();

        StringBuilder b = new StringBuilder("mode=getusertags");
        b.append(this.authString);
        b.append("&ver=1");
        
        LJRawResult data = m_conn.sendRequest(b.toString());
        int count = data.getCount("tag_count");
        
        if (ph != null) {
            ph.setMinimum(1);
            ph.setMaximum(count);
        }
        
        tags.clear();
        tags.ensureCapacity(count);
        for (int i = 1; i <= count; i++) {
            String prefix = "tag_" + Integer.toString(i) + "_";
            LJTag t = new LJTag();
            t.parseResponse(data, prefix);
            tags.add(t);
            
            if (ph != null) {
                ph.setValue(i);
            }
        }
        Collections.sort(tags);
    }
    
    static {
        dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
    }
}
