/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

/** 
 * This class provides several data conversion helpers to the <code>HashMap</code>
 * returned by the LiveJournal requests
 * @author Petr Panteleyev
 */
public class LJRawResult extends java.util.HashMap<String,String> {
    
    /** Creates a new instance of LJRawResult */
    public LJRawResult() {
    }
    
    /**
     * Returns value as integer (no default value)
     * @param name Key for the value
     * @return Integer value
     * @throws LJValueNotFoundException When there is no value with the specified
     *          key
     * @throws LJJournalException When the value is not intever as expected
     */
    public int getInt(String name) throws LJValueNotFoundException, LJJournalException {
        String value = get(name);
        if (value == null) {
            throw new LJValueNotFoundException(name);
        }
        
        try {
            return Integer.parseInt(value);
        }
        catch (NumberFormatException e) {
            throw new LJJournalException("");
        }
    }

    /**
     * Returns value as integer
     * @param name Key for the value
     * @param defValue Default value in case the key does not exist
     * @return Integer value or 0 if the key does not exist
     * @throws LJJournalException When the value is not integer as expected
     */
    public int getInt(String name, int defValue) throws LJJournalException {
        String value = get(name);
        if (value == null) {
            return defValue;
        }
        
        try {
            return Integer.parseInt(value);
        }
        catch (NumberFormatException e) {
            throw new LJJournalException("");
        }
    }
    
    /**
     * Returns value as integer which is supposed to be a counter
     * @param name Key for the value
     * @return Integer value or 0 if the key does not exist
     */
    public int getCount(String name) {
        try {
            return Math.max(getInt(name, 0), 0);
        }
        catch (Exception e) {
            return 0;
        }
    }
    
    /**
     * Returns value as boolean.<br>
     * 1 means true, everything else or non existant key means false.
     * @param name Key for the value
     * @return Boolean value
     */
    public boolean getBoolean(String name) {
        String value = get(name);
        return (value != null) && (value.equals("1"));
    }
}
