/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljapi;

/**
 * This class represents LiveJournal tag which is associated with some of the events
 * posted in journal.
 * @author Petr Panteleyev
 */
public class LJTag implements Comparable<LJTag> {
    private String m_name;
    private int m_count;
    private boolean m_display;
   
    /** Creates a new instance of the LJTag */
    public LJTag() {
    }

    /** Creates a new instance of the LJTag */
    public LJTag(String name) {
        m_name = name;
    }
    
    /**
     * Returns name of the tag
     * @return Name of the tag
     */
    public String getName() { return m_name; }

    /**
     * Parses LJTag object from the data returned by the LiveJournal request
     * @param data LiveJournal response data
     * @param prefix Prefic for the object to be parsed
     * @throws LJJournalException When the data is in bad format
     */
    public void parseResponse(LJRawResult data, String prefix) throws LJException {
        String value;
        
        m_name = data.get(prefix + "name");
        if (m_name == null)
            throw new LJJournalException(prefix);
        
        m_count = data.getCount(prefix + "uses");
        m_display = data.getBoolean(prefix + "display");
        
        // TODO: security!!!
    }
    
    /**
     * Compares tags alphbetically
     * @param t Tag to compare with
     */
    public int compareTo(LJTag t) {
        return getName().compareTo(t.getName());
    }        
}
