Copyright (c) 2006, Petr Panteleyev
All rights reserved.

ljapi - is a separately delivered LiveJournal API library. It is intended for
those needs API only for their own purpose.

LJ Protocol
http://www.livejournal.com/doc/server/ljp.csp.protocol.html