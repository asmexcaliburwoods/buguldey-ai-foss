/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import org.panteleyev.tools.*;
import org.panteleyev.ljapi.*;

abstract class ColumnHeaderMouseListener  extends java.awt.event.MouseAdapter {
    private JTable m_table;
    
    public ColumnHeaderMouseListener(JTable table) {
        m_table = table;
    }
    
    public abstract void columnClicked(int i);
    
    public void mouseClicked(java.awt.event.MouseEvent e) {
        TableColumnModel colModel = m_table.getColumnModel();
        int columnModelIndex = colModel.getColumnIndexAtX(e.getX());
        if ((columnModelIndex >= 0) && (columnModelIndex < colModel.getColumnCount())) {
            int modelIndex = colModel.getColumn(columnModelIndex).getModelIndex();

            if (modelIndex < 0) {
                return;
            } else {
                columnClicked(modelIndex);
            }
        }
    }        
}

public class FriendsWindow extends MDIChildWindow {
    private AbstractTableModel friendsListTableModel;
    private SimpleListModel groupListModel;
    private SimpleListModel friendsNotInListModel;
    private SimpleListModel friendsInListModel;
    private LJAccount m_account;
    private ArrayList<LJFriend> m_friends;
    private ArrayList<LJFriend> friendsIn;
    private ArrayList<LJFriend> friendsNotIn;
        
    /* Local copy for groups */
    private ArrayList<LJGroup> groupsCopy;
    private ArrayList<LJGroup> groupsToDelete;
    private int groupBitMap;
    private boolean groupsChanged;
    private ArrayList<LJFriend> changedFriends;
    
    /* Remember selected tab */
    private int selectedTab;
    
    /* Variables for separate thread */
    ProgressDialog pDial = null;
    ArrayList<LJFriendChange> m_change;
    /**********************************/
        
    private final String[] friendsTableHeaderNames = {
        " ",
        Options.getResourceBundle().getString("friendsTableHeaderNames_1"),
        Options.getResourceBundle().getString("friendsTableHeaderNames_2"),
        "C",
        Options.getResourceBundle().getString("friendsTableHeaderNames_4"),
    };
    
    /* 0  - no sort
     * 1  - asc
     * -1 - desc
     */
    private int[] m_sortOrder = {
        0, 0, 0, 0, 0
    };
    private int m_sortColumn = -1;
    private Comparator<LJFriend> m_cmp[];
    
    private static FriendsWindow m_self = null;
    
    public static FriendsWindow getFriendsWindow() {
        return m_self;
    }
    
    public static FriendsWindow createFriendsWindow(JFrame mainFrame, JDesktopPane pane, LJAccount account) {
        if (m_self == null) {
            m_self = new FriendsWindow(mainFrame, account);
            pane.add(m_self);
        }
        
        return m_self;
    }
    
    /** Creates new form FriendsWindow */
    private FriendsWindow(JFrame mainFrame, LJAccount account) {
        super(mainFrame);
        initComponents();
                
        m_account = account;
       
        m_friends = m_account.getFriendList().getFriendArrayClone();                
        
        this.changedFriends = new ArrayList<LJFriend>();
        this.friendsIn = new ArrayList<LJFriend>();
        this.friendsNotIn = new ArrayList<LJFriend>();
        this.groupsCopy = new ArrayList<LJGroup>();                 
        this.groupsChanged = false;
        this.groupsToDelete = new ArrayList<LJGroup>();
        
        this.selectedTab = -1;
        
        m_cmp = (Comparator<LJFriend>[])new Comparator[5];
        m_cmp[0] = new LJFriendRelationComparator();
        m_cmp[1] = new LJFriendAlphabeticalComparator();
        m_cmp[2] = new LJFriendFullNameComparator();
        m_cmp[3] = new LJFriendTypeComparator();
        m_cmp[4] = new LJFriendBirthdayComparator();
        
        createFriendsTable();
        createGroupListModels();
        
        // Sort friends initially
        m_sortColumn = Options.getFriendSortColumn();
        if (m_sortColumn != -1) {
            m_sortOrder[m_sortColumn] = Options.getFriendSortOrder();
            sortFriends(Options.getFriendSortColumn());
        }
        
        TableUtil.adjustTableColumnSizes(friendsTable);
        updateFriendStatFields();
        reloadGroupsTab();
        Options.loadBounds(this);
    }
        
    private void reloadGroupsTab() {
        this.groupsToDelete.clear();
        
        for (LJFriend f : this.changedFriends) {
            f.cancelChanges();
        }
        
        this.changedFriends.clear();

        /* Fill local copy of groups */        
        this.groupBitMap = 0;
        this.groupsCopy.clear();
        for (LJGroup g : m_account.getGroups()) {
            this.groupsCopy.add(g.clone());
            this.groupBitMap |= (1 << g.getNumber());
        }

        this.groupsChanged = false;
        groupListModel.fireListDataChanged();        
        groupListValueChanged(null);
        updateGroupButtonsState();
    }
    
    /** Helper function returns currently selected friend if any */
    private LJFriend getSelectedFriend() {
        int index = this.friendsTable.getSelectedRow();
        if (index != -1) {
            return m_friends.get(index);
        } else {
            return null;
        }
    }       
    
    /** Helper function returns currently selected group if any */
    private LJGroup getSelectedGroup() {
        int index = this.groupList.getSelectedIndex();
        return ((index >= 0) && (index < this.groupsCopy.size()))? this.groupsCopy.get(index) : null;
    }
    
    private void createFriendsTable() {
        friendsListTableModel = new AbstractTableModel() {
            public int getColumnCount() { 
                return friendsTableHeaderNames.length;
            }
            
            public int getRowCount() {
                return m_friends.size();
            }

            public Object getValueAt(int row, int col) {
                return m_friends.get(row);
            }
            
            public String getColumnName(int column) {
                return friendsTableHeaderNames[column]; 
            }                                    
        };
        
        friendsTable.setModel(friendsListTableModel);
        
        FriendTableCellRenderer renderer = new FriendTableCellRenderer();
        for (int i = 0; i < friendsListTableModel.getColumnCount(); i++) {
            TableColumn column = new TableColumn(i, 10, renderer, null);
            friendsTable.addColumn(column);            
        }
        
        
//        friendsTable.setDefaultRenderer(Object.class, new FriendTableCellRenderer());
        
        JTableHeader header = friendsTable.getTableHeader();
        header.addMouseListener(new ColumnHeaderMouseListener(friendsTable) {
            public void columnClicked(int index) {
                if (m_cmp[index] != null) {
                    int count = friendsListTableModel.getColumnCount();
                    
                    // Clear other column sorting
                    for (int i = 0; i < count; i++) {
                        if (i != index) {
                            m_sortOrder[i] = 0;
                        }
                    }
                    
                    switch (m_sortOrder[index]) {
                        case 0:
                            m_sortOrder[index] = 1;
                            break;
                        case 1:
                            m_sortOrder[index] = -1;
                            break;
                        case -1:
                            m_sortOrder[index] = 1;
                            break;
                    }
                    
                    sortFriends(index);
                    friendsListTableModel.fireTableDataChanged();
                    
                    Options.setFriendSortColumn(index);
                    Options.setFriendSortOrder(m_sortOrder[index]);
                }
            }
        });
    }
    
    private void updateGroupButtonsState() {
        this.groupSaveButton.setEnabled(this.groupsChanged);
        this.groupAddButton.setEnabled(this.groupsCopy.size() < 30);
        
////        int index = this.groupList.getSelectedIndex();
////        this.groupRemoveButton.setEnabled(index != -1);
    }
    
    private void createGroupListModels() {
        groupListModel = new SimpleListModel() {
            public int getSize() { return groupsCopy.size(); }
            public Object getElementAt(int index) { return groupsCopy.get(index).getName(); }            
        };
        
        friendsNotInListModel = new SimpleListModel() {
            public int getSize() { return friendsNotIn.size(); }
            public Object getElementAt(int index) { return friendsNotIn.get(index).getUserName(); }
        };

        friendsInListModel = new SimpleListModel() {
            public int getSize() { return friendsIn.size(); }
            public Object getElementAt(int index) { return friendsIn.get(index).getUserName(); }
        };
        
        groupList.setModel(groupListModel);
        friendsNotInList.setModel(friendsNotInListModel);
        friendsInList.setModel(friendsInListModel);        
    }
    
    private void sortFriends(int index) {
        if ((index >= 0) && (index < friendsListTableModel.getColumnCount()) && (m_sortOrder[index] != 0)) {
            Comparator<LJFriend> cmp = m_cmp[index];
            if (m_sortOrder[index] == -1) {
                cmp = Collections.reverseOrder(cmp);
            }
            Collections.sort(m_friends, cmp);
            m_sortColumn = index;
        }
    }
    
    private void onFriendListUpdated() {
        m_friends = m_account.getFriendList().getFriendArrayClone();
        sortFriends(m_sortColumn);        
        
        friendsListTableModel.fireTableDataChanged();
        TableUtil.adjustTableColumnSizes(friendsTable);
        updateFriendStatFields();
        reloadGroupsTab();        
        Options.storeFriends(m_account.getFriendList());
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        tabbedPane = new javax.swing.JTabbedPane();
        friendsTab = new javax.swing.JPanel();
        friendListPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        friendsTable = new javax.swing.JTable();
        friendRightPanel = new javax.swing.JPanel();
        friendUpdateButton = new javax.swing.JButton();
        friendAddButton = new javax.swing.JButton();
        friendRemoveButton = new javax.swing.JButton();
        friendJournalButton = new javax.swing.JButton();
        friendInfoButton = new javax.swing.JButton();
        friendCalendarButton = new javax.swing.JButton();
        friendFriendsButton = new javax.swing.JButton();
        friendStatPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        friendCountEdit = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        mutualCountEdit = new javax.swing.JTextField();
        friendsOfLabel = new javax.swing.JLabel();
        friendofCountEdit = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        communityCountEdit = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        synCountEdit = new javax.swing.JTextField();
        groupsTab = new javax.swing.JPanel();
        groupMainPanel = new javax.swing.JPanel();
        groupPanel_1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        groupList = new javax.swing.JList();
        groupPanel_4 = new javax.swing.JPanel();
        publicGroupCheckBox = new javax.swing.JCheckBox();
        friendsNotInPanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        friendsNotInList = new javax.swing.JList();
        groupPanel_6 = new javax.swing.JPanel();
        removeFromGroupButton = new javax.swing.JButton();
        groupPanel_5 = new javax.swing.JPanel();
        addToGroupButton = new javax.swing.JButton();
        friendsInPanel = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        friendsInList = new javax.swing.JList();
        groupRightPanel = new javax.swing.JPanel();
        groupAddButton = new javax.swing.JButton();
        groupRemoveButton = new javax.swing.JButton();
        groupUpButton = new javax.swing.JButton();
        groupDownButton = new javax.swing.JButton();
        groupSaveButton = new javax.swing.JButton();

        setClosable(true);
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setResizable(true);
        setTitle(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Friends"));
        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/edit_friends.gif")));
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosed(evt);
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosing(evt);
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        tabbedPane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                tabbedPaneStateChanged(evt);
            }
        });

        friendsTab.setLayout(new java.awt.GridBagLayout());

        friendListPanel.setLayout(new java.awt.BorderLayout());

        jScrollPane1.setPreferredSize(new java.awt.Dimension(300, 200));
        friendsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        friendsTable.setAutoCreateColumnsFromModel(false);
        friendsTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        friendsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                friendsTableMouseClicked(evt);
            }
        });

        jScrollPane1.setViewportView(friendsTable);

        friendListPanel.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        friendsTab.add(friendListPanel, gridBagConstraints);

        friendRightPanel.setLayout(new java.awt.GridBagLayout());

        friendUpdateButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Update"));
        friendUpdateButton.setFocusPainted(false);
        friendUpdateButton.setFocusable(false);
        friendUpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendUpdateButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 5);
        friendRightPanel.add(friendUpdateButton, gridBagConstraints);

        friendAddButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Add..."));
        friendAddButton.setFocusPainted(false);
        friendAddButton.setFocusable(false);
        friendAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendAddButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        friendRightPanel.add(friendAddButton, gridBagConstraints);

        friendRemoveButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Remove"));
        friendRemoveButton.setFocusPainted(false);
        friendRemoveButton.setFocusable(false);
        friendRemoveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendRemoveButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        friendRightPanel.add(friendRemoveButton, gridBagConstraints);

        friendJournalButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        friendJournalButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_journal"));
        friendJournalButton.setFocusPainted(false);
        friendJournalButton.setFocusable(false);
        friendJournalButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        friendJournalButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendJournalButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(20, 5, 0, 5);
        friendRightPanel.add(friendJournalButton, gridBagConstraints);

        friendInfoButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        friendInfoButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_info"));
        friendInfoButton.setFocusPainted(false);
        friendInfoButton.setFocusable(false);
        friendInfoButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        friendInfoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendInfoButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        friendRightPanel.add(friendInfoButton, gridBagConstraints);

        friendCalendarButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        friendCalendarButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_calendar"));
        friendCalendarButton.setFocusPainted(false);
        friendCalendarButton.setFocusable(false);
        friendCalendarButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        friendCalendarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendCalendarButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        friendRightPanel.add(friendCalendarButton, gridBagConstraints);

        friendFriendsButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        friendFriendsButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_friends"));
        friendFriendsButton.setFocusPainted(false);
        friendFriendsButton.setFocusable(false);
        friendFriendsButton.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        friendFriendsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendFriendsButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        friendRightPanel.add(friendFriendsButton, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        friendsTab.add(friendRightPanel, gridBagConstraints);

        friendStatPanel.setLayout(new java.awt.GridBagLayout());

        jLabel1.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Friends:"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 0);
        friendStatPanel.add(jLabel1, gridBagConstraints);

        friendCountEdit.setColumns(5);
        friendCountEdit.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 3, 0, 0);
        friendStatPanel.add(friendCountEdit, gridBagConstraints);

        jLabel2.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Mutual Friends:"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 0);
        friendStatPanel.add(jLabel2, gridBagConstraints);

        mutualCountEdit.setColumns(5);
        mutualCountEdit.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 3, 0, 5);
        friendStatPanel.add(mutualCountEdit, gridBagConstraints);

        friendsOfLabel.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_friendsOfLabel"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 0);
        friendStatPanel.add(friendsOfLabel, gridBagConstraints);

        friendofCountEdit.setColumns(5);
        friendofCountEdit.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 3, 0, 0);
        friendStatPanel.add(friendofCountEdit, gridBagConstraints);

        jLabel4.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_communitiesLabel"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 0);
        friendStatPanel.add(jLabel4, gridBagConstraints);

        communityCountEdit.setColumns(5);
        communityCountEdit.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 3, 0, 5);
        friendStatPanel.add(communityCountEdit, gridBagConstraints);

        jLabel5.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_syndLabel"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 5, 0);
        friendStatPanel.add(jLabel5, gridBagConstraints);

        synCountEdit.setColumns(5);
        synCountEdit.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 3, 5, 0);
        friendStatPanel.add(synCountEdit, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        friendsTab.add(friendStatPanel, gridBagConstraints);

        tabbedPane.addTab(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Friends"), friendsTab);

        groupsTab.setLayout(new java.awt.GridBagLayout());

        groupMainPanel.setLayout(new java.awt.GridBagLayout());

        groupPanel_1.setLayout(new java.awt.BorderLayout());

        groupPanel_1.setBorder(javax.swing.BorderFactory.createTitledBorder(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Groups")));
        jScrollPane2.setPreferredSize(new java.awt.Dimension(10, 10));
        groupList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        groupList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                groupListValueChanged(evt);
            }
        });

        jScrollPane2.setViewportView(groupList);

        groupPanel_1.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        groupMainPanel.add(groupPanel_1, gridBagConstraints);

        groupPanel_4.setLayout(new java.awt.GridBagLayout());

        publicGroupCheckBox.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Public Group"));
        publicGroupCheckBox.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        publicGroupCheckBox.setMargin(new java.awt.Insets(0, 0, 0, 0));
        publicGroupCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                publicGroupCheckBoxActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        groupPanel_4.add(publicGroupCheckBox, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        groupMainPanel.add(groupPanel_4, gridBagConstraints);

        friendsNotInPanel.setLayout(new java.awt.BorderLayout());

        friendsNotInPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_friendsNotInPanel")));
        jScrollPane3.setPreferredSize(new java.awt.Dimension(10, 10));
        jScrollPane3.setViewportView(friendsNotInList);

        friendsNotInPanel.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.3;
        gridBagConstraints.weighty = 1.0;
        groupMainPanel.add(friendsNotInPanel, gridBagConstraints);

        removeFromGroupButton.setText("<<");
        removeFromGroupButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeFromGroupButtonActionPerformed(evt);
            }
        });

        groupPanel_6.add(removeFromGroupButton);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        groupMainPanel.add(groupPanel_6, gridBagConstraints);

        addToGroupButton.setText(">>");
        addToGroupButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addToGroupButtonActionPerformed(evt);
            }
        });

        groupPanel_5.add(addToGroupButton);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        groupMainPanel.add(groupPanel_5, gridBagConstraints);

        friendsInPanel.setLayout(new java.awt.BorderLayout());

        friendsInPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_friendsInPanel")));
        jScrollPane4.setPreferredSize(new java.awt.Dimension(10, 10));
        jScrollPane4.setViewportView(friendsInList);

        friendsInPanel.add(jScrollPane4, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.3;
        gridBagConstraints.weighty = 1.0;
        groupMainPanel.add(friendsInPanel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        groupsTab.add(groupMainPanel, gridBagConstraints);

        groupRightPanel.setLayout(new java.awt.GridBagLayout());

        groupAddButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Add..."));
        groupAddButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groupAddButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 5);
        groupRightPanel.add(groupAddButton, gridBagConstraints);

        groupRemoveButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Remove"));
        groupRemoveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groupRemoveButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        groupRightPanel.add(groupRemoveButton, gridBagConstraints);

        groupUpButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_groupUpButton"));
        groupUpButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groupUpButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(10, 5, 0, 5);
        groupRightPanel.add(groupUpButton, gridBagConstraints);

        groupDownButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_groupDownButton"));
        groupDownButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groupDownButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        groupRightPanel.add(groupDownButton, gridBagConstraints);

        groupSaveButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsWindow_groupSaveButton"));
        groupSaveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                groupSaveButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(10, 5, 5, 5);
        groupRightPanel.add(groupSaveButton, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        groupsTab.add(groupRightPanel, gridBagConstraints);

        tabbedPane.addTab(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Groups"), groupsTab);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 534, 403);
    }// </editor-fold>//GEN-END:initComponents

    private void openFriendLink(String suffix) {
        LJFriend friend = getSelectedFriend();
        if (friend != null) {
            // TODO: Use some option from the API instead of hardcoded address
            StringBuilder b = new StringBuilder("http://www.livejournal.com/users/");
            b.append(friend.getUserName());
            b.append("/");
            b.append(suffix);
            Utils.runBrowser(b.toString());
        }
    }
    
    private void friendFriendsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendFriendsButtonActionPerformed
        // TODO: Use some option from the API instead of hardcoded address
        openFriendLink("friends");
    }//GEN-LAST:event_friendFriendsButtonActionPerformed

    private void friendCalendarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendCalendarButtonActionPerformed
        // TODO: Use some option from the API instead of hardcoded address
        openFriendLink("calendar");
    }//GEN-LAST:event_friendCalendarButtonActionPerformed

    private void friendInfoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendInfoButtonActionPerformed
        // TODO: Use some option from the API instead of hardcoded address
        openFriendLink("profile");
    }//GEN-LAST:event_friendInfoButtonActionPerformed

    private void friendJournalButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendJournalButtonActionPerformed
        // TODO: Use some option from the API instead of hardcoded address
        openFriendLink("");
    }//GEN-LAST:event_friendJournalButtonActionPerformed

    private void formInternalFrameClosed(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosed
        m_self = null;
    }//GEN-LAST:event_formInternalFrameClosed

    private void formInternalFrameClosing(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosing
        if (canCloseGroupTab()) {
            Options.saveBounds(this);
            dispose();
        }
    }//GEN-LAST:event_formInternalFrameClosing

    private void tabbedPaneStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_tabbedPaneStateChanged
        int selIndex = tabbedPane.getSelectedIndex();
        
        if ((this.selectedTab == 1) && (selIndex != 1)) {
            if (!canCloseGroupTab()) {
                tabbedPane.setSelectedIndex(this.selectedTab);
            }
        }

        this.selectedTab = tabbedPane.getSelectedIndex();
    }//GEN-LAST:event_tabbedPaneStateChanged

    private boolean canCloseGroupTab() {
        if (this.groupsChanged) {
            int res = JOptionPane.showConfirmDialog(getMainFrame(), "Save changes?");
            switch (res) {
                case JOptionPane.YES_OPTION:
                    onSaveGroups();
                    return true;
                    
                case JOptionPane.NO_OPTION:
                    reloadGroupsTab();
                    return true;
                    
                case JOptionPane.CANCEL_OPTION:
                    return false;
            }
        }
        return true;
    }
    
    private void addToGroupButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addToGroupButtonActionPerformed
        LJGroup g = getSelectedGroup();
        
        if (g != null) {            
            for (int i : this.friendsNotInList.getSelectedIndices()) {
                LJFriend f = friendsNotIn.get(i);
                
                if (!f.getEdit()) {
                    this.changedFriends.add(f);
                }
                
                f.edit();
                f.addToGroup(g);
            }
            
            this.friendsNotInList.setSelectedIndices(new int[0]);
            groupListValueChanged(null);
            this.groupsChanged = true;
            updateGroupButtonsState();
        }
    }//GEN-LAST:event_addToGroupButtonActionPerformed

    private void removeFromGroupButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeFromGroupButtonActionPerformed
        LJGroup g = getSelectedGroup();
        if (g != null) {
            for (int i : this.friendsInList.getSelectedIndices()) {
                LJFriend f = friendsIn.get(i);

                if (!f.getEdit()) {
                    this.changedFriends.add(f);
                }
                
                f.edit();
                f.removeFromGroup(g);
            }
            
            this.friendsInList.setSelectedIndices(new int[0]);
            groupListValueChanged(null);
            this.groupsChanged = true;
            updateGroupButtonsState();
        }
    }//GEN-LAST:event_removeFromGroupButtonActionPerformed

    private void groupDownButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groupDownButtonActionPerformed
        int index = this.groupList.getSelectedIndex();
        if (index < this.groupsCopy.size() - 1) {
            LJGroup g = this.groupsCopy.set(index + 1, this.groupsCopy.get(index));
            this.groupsCopy.set(index, g);
            this.groupsChanged = true;
            updateGroupButtonsState();
            this.groupListModel.fireListDataChanged();
            this.groupList.setSelectedIndex(index + 1);
        }        
    }//GEN-LAST:event_groupDownButtonActionPerformed

    private void groupUpButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groupUpButtonActionPerformed
        int index = this.groupList.getSelectedIndex();
        if (index > 0) {
            LJGroup g = this.groupsCopy.set(index - 1, this.groupsCopy.get(index));
            this.groupsCopy.set(index, g);            
            this.groupsChanged = true;
            updateGroupButtonsState();
            this.groupListModel.fireListDataChanged();
            this.groupList.setSelectedIndex(index - 1);
        }
    }//GEN-LAST:event_groupUpButtonActionPerformed

    private void publicGroupCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_publicGroupCheckBoxActionPerformed
        LJGroup g = getSelectedGroup();
        if (g != null) {
            g.setPublic(!g.isPublic());
            this.groupsChanged = true;
            updateGroupButtonsState();
        }
    }//GEN-LAST:event_publicGroupCheckBoxActionPerformed

    private void onSaveGroups() {
        try {
            m_account.saveGroups(this.groupsCopy, this.groupsToDelete, this.changedFriends);
            
            for (LJGroup g : this.groupsCopy) {
                g.setTemporary(false);
            }
            
            m_account.setGroups(this.groupsCopy);
            for (LJFriend f : this.changedFriends) {
                f.applyChanges();
            }
            
            this.groupsChanged = false;
            this.changedFriends.clear();
            updateGroupButtonsState();
            Options.storeFriends(m_account.getFriendList());
        }
        catch (LJException e) {
            for (LJFriend f : this.changedFriends) {
                f.cancelChanges();
            }
            ((LJMainFrame)getMainFrame()).handleException(e);
        }
    }
    
    private void groupSaveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groupSaveButtonActionPerformed
        onSaveGroups();
    }//GEN-LAST:event_groupSaveButtonActionPerformed

    private void groupAddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groupAddButtonActionPerformed
        if (this.groupsCopy.size() < 30) {
            String gName = JOptionPane.showInputDialog("Enter Group Name:");
            if ((gName != null) && (gName.length() != 0)) {
                LJGroup g = new LJGroup(gName);
                g.setTemporary(true);
                
                // Find unused number
                int mask = 2;
                for (int num = 1; num <= 30; num++) {
                    if ((mask & this.groupBitMap) == 0) {
                        this.groupBitMap |= mask;
                        g.setNumber(num);
                        break;
                    }                        
                    mask = mask << 1;
                }
                
                this.groupsCopy.add(g);
                this.groupsChanged = true;
                groupListModel.fireListDataChanged();
                updateGroupButtonsState();
            }            
        } else {
            JOptionPane.showMessageDialog(getMainFrame(), "No more groups can be created", "Info", JOptionPane.OK_OPTION);
        }
        
    }//GEN-LAST:event_groupAddButtonActionPerformed

    private void groupRemoveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_groupRemoveButtonActionPerformed
        LJGroup group = getSelectedGroup();

        if (group != null) {
            int mask = 1 << group.getNumber();
            /* release number */
            this.groupBitMap ^= mask;

            /* Clear group masks */
            for (LJFriend f : m_account.getFriendArray()) {
                if (!f.getEdit()) {
                    this.changedFriends.add(f);
                    f.edit();
                }
                f.removeFromGroup(group);
            }

            /* Schedule the group for deletion if it was not just created */
            if (!group.isTemporary()) {
                this.groupsToDelete.add(group);
            }
            this.groupsCopy.remove(group);
            this.groupsChanged = true;
            groupListModel.fireListDataChanged();
            updateGroupButtonsState();
            groupListValueChanged(null);
        }
    }//GEN-LAST:event_groupRemoveButtonActionPerformed

    private void friendRemoveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendRemoveButtonActionPerformed
        LJFriend f = getSelectedFriend();
        if (f != null) {
            try {
                m_account.deleteFriend(f);
                onFriendListUpdated();
            }
            catch (LJException e) {
                ((LJMainFrame)getMainFrame()).handleException(e);
            }
        }
    }//GEN-LAST:event_friendRemoveButtonActionPerformed

    public void onAddFriend() {
        LJFriend sf = getSelectedFriend();
        if ((sf != null) && (!sf.isFriendOf())) {
            sf = null;
        }
        
        FriendDialog dial = new FriendDialog(getMainFrame(), sf, m_account.getGroups(), true);
        if (dial.showDialog()) {
            LJFriend f;
            /* Check if it's the same friend of */
            String newName = dial.getUserName();
            if ((sf != null) && (newName.equals(sf.getUserName()))) {
                f = sf;
            } else {
                f = new LJFriend(dial.getUserName());
            }
            
            f.setFg(dial.getFg());
            f.setBg(dial.getBg());
            f.setGroupMask(dial.getGroupMask());
            try {
                if (m_account.addFriend(f) != 0)                
                    onFriendListUpdated();
            }
            catch (LJException e) {
                ((LJMainFrame)getMainFrame()).handleException(e);
            }
        }        
    }
    
    private void friendAddButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendAddButtonActionPerformed
        onAddFriend();
    }//GEN-LAST:event_friendAddButtonActionPerformed

    private void friendsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_friendsTableMouseClicked
        if (evt.getClickCount() == 2) {
            LJFriend f = getSelectedFriend();
            if ((f != null) && (!f.isFriendOf())) {
                FriendDialog dial = new FriendDialog(getMainFrame(), f, m_account.getGroups(), false);
                if (dial.showDialog()) {
                    f.setFg(dial.getFg());
                    f.setBg(dial.getBg());
                    f.setGroupMask(dial.getGroupMask());
                    try {
                        m_account.updateFriend(f);
                    }
                    catch (LJException e) {
                        ((LJMainFrame)getMainFrame()).handleException(e);
                    }
                }
            }
        }
    }//GEN-LAST:event_friendsTableMouseClicked

    private void groupListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_groupListValueChanged
        friendsIn.clear();
        friendsNotIn.clear();
        
        LJGroup group = getSelectedGroup();
        if (group != null) {
            publicGroupCheckBox.setSelected(group.isPublic());

            for (LJFriend f: m_friends) {
                if (!f.isFriendOf()) {
                    if (f.isInGroup(group)) {
                        friendsIn.add(f);
                    } else {
                        friendsNotIn.add(f);                        
                    }
                }
            }                
        }
        
        friendsNotInListModel.fireListDataChanged();
        friendsInListModel.fireListDataChanged();
    }//GEN-LAST:event_groupListValueChanged
        
    private void friendUpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendUpdateButtonActionPerformed
        Thread thread = new Thread() {
            public void run() {
                try {
                    pDial.asyncShowDialog();
                    pDial.setMessage("Sending request...");
                    
                    LJFriendList fList = m_account.getFriendList();
                    m_change = null;
                    if (fList.size() != 0) {
                        m_change = new ArrayList<LJFriendChange>();
                    }                    
                    
                    LJRawResult data = m_account.getFriends(true, pDial);
                    fList.load(data, m_change, pDial);
                    ((LJMainFrame)getMainFrame()).createFriendMenu();
                    SwingUtilities.invokeAndWait(new Runnable() {
                        public void run() {
                            onFriendListUpdated();                        
                        }
                    });
                    
                    if ((m_change != null) && (m_change.size() != 0)) {
                        /* Show friend list changes */
                        SwingUtilities.invokeAndWait(new Runnable() {
                            public void run() {
                                new FriendListChangeDialog(getMainFrame(), m_change).showDialog();
                            }
                        });
                    }
                }
                catch (LJException e) {
                    ((LJMainFrame)getMainFrame()).handleException(e);
                }
                catch (Exception e) {
                }
                finally {
                    pDial.asyncCloseDialog();
                }
            }
        };
        
        pDial = new ProgressDialog(getMainFrame());
        thread.start();        
    }//GEN-LAST:event_friendUpdateButtonActionPerformed
    
    private void updateFriendStatFields() {
        LJFriendList fList = m_account.getFriendList();
        friendCountEdit.setText(Integer.toString(fList.getFriendCount()));
        mutualCountEdit.setText(Integer.toString(fList.getMutualCount()));
        friendofCountEdit.setText(Integer.toString(fList.getFriendOfCount()));
        communityCountEdit.setText(Integer.toString(fList.getCommunityCount()));
        synCountEdit.setText(Integer.toString(fList.getSyndicatedCount()));
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addToGroupButton;
    private javax.swing.JTextField communityCountEdit;
    private javax.swing.JButton friendAddButton;
    private javax.swing.JButton friendCalendarButton;
    private javax.swing.JTextField friendCountEdit;
    private javax.swing.JButton friendFriendsButton;
    private javax.swing.JButton friendInfoButton;
    private javax.swing.JButton friendJournalButton;
    private javax.swing.JPanel friendListPanel;
    private javax.swing.JButton friendRemoveButton;
    private javax.swing.JPanel friendRightPanel;
    private javax.swing.JPanel friendStatPanel;
    private javax.swing.JButton friendUpdateButton;
    private javax.swing.JTextField friendofCountEdit;
    private javax.swing.JList friendsInList;
    private javax.swing.JPanel friendsInPanel;
    private javax.swing.JList friendsNotInList;
    private javax.swing.JPanel friendsNotInPanel;
    private javax.swing.JLabel friendsOfLabel;
    private javax.swing.JPanel friendsTab;
    private javax.swing.JTable friendsTable;
    private javax.swing.JButton groupAddButton;
    private javax.swing.JButton groupDownButton;
    private javax.swing.JList groupList;
    private javax.swing.JPanel groupMainPanel;
    private javax.swing.JPanel groupPanel_1;
    private javax.swing.JPanel groupPanel_4;
    private javax.swing.JPanel groupPanel_5;
    private javax.swing.JPanel groupPanel_6;
    private javax.swing.JButton groupRemoveButton;
    private javax.swing.JPanel groupRightPanel;
    private javax.swing.JButton groupSaveButton;
    private javax.swing.JButton groupUpButton;
    private javax.swing.JPanel groupsTab;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField mutualCountEdit;
    private javax.swing.JCheckBox publicGroupCheckBox;
    private javax.swing.JButton removeFromGroupButton;
    private javax.swing.JTextField synCountEdit;
    private javax.swing.JTabbedPane tabbedPane;
    // End of variables declaration//GEN-END:variables

}
