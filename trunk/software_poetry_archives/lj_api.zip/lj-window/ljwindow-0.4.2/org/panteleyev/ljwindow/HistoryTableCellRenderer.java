/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import java.text.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import org.panteleyev.ljapi.*;

final class HistoryTableCellRenderer extends JLabel implements TableCellRenderer {
    protected static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);
    protected static Border focusBorder = UIManager.getBorder("Table.focusCellHightlightBorder");
    
    private static DateFormat dateFormat;
    private static java.awt.Color color;
    
    public HistoryTableCellRenderer() {
    }
    
    public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int nRow, int nCol) {       
        ImageIcon icon = null;
        String text = null;
        
        if (value != null) {
            LJEvent event = (LJEvent)value;

            switch (nCol) {
                case 0:
                    switch (event.getAccessLevel()) {
                        case LJEvent.ACCESS_PRIVATE:
                            icon = IconManager.getIcon(IconManager.PRIVATE);
                            break;

                        case LJEvent.ACCESS_FRIENDS:
                        case LJEvent.ACCESS_GROUPS:
                            icon = IconManager.getIcon(IconManager.LOCK);
                            break;
                    }
                    break;

                case 1:                
                    text = dateFormat.format(event.getDate());
                    break;

                case 2:
                    text = event.getBody();
                    break;
            }

            setOpaque(true);
            if ((event.getPoster() == null) || (event.getPoster().equals(UserProfileManager.getCurrentProfileName()))) {
                setBackground(isSelected ? table.getSelectionBackground() : color);
            } else {
                setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
            }
            setForeground(isSelected ? table.getSelectionForeground() : table.getForeground());
            setFont(table.getFont());
            setBorder(hasFocus ? focusBorder : noFocusBorder);
        }

        setIcon(icon);
        setText(text);
        
        return this;
    }
    
    static {
        color = new java.awt.Color(100, 240, 200);
        dateFormat = new SimpleDateFormat("yyyy-MM-dd kk:mm");
    }
}
