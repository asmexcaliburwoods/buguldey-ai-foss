/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import java.util.*;
import java.io.*;
import org.w3c.dom.*;
import javax.swing.*;
import javax.swing.table.*;
import org.panteleyev.ljapi.*;
import org.panteleyev.tools.*;

public class HistoryWindow extends MDIChildWindow {
    public static final int EVENT_TRUNC     = 60;
    public static final int LASTN_DEFAULT   = 20;
    public static final int LASTN_MAX       = 50;
    
    private AbstractTableModel historyTableModel;
    private LJAccount m_account;
    private ArrayList<LJEvent> m_history;
    private int m_lastN;
    
    private JFileChooser m_exportFileChooser;
    
    private static String m_ExportDialogTitle;
    
    /* Variables for separate thread */
    ProgressDialog m_progressDialog = null;
    int[] m_rows;
    /**********************************/
    
    private final String[] historyTableHeaderNames = {
        " ",
        Options.getResourceBundle().getString("historyTableHeaderNames_date"),
        Options.getResourceBundle().getString("historyTableHeaderNames_subject"),
    };
    
    private static HistoryWindow m_self = null;
    
    public static HistoryWindow getHistoryWindow(JFrame mainFrame, JDesktopPane pane, LJAccount account) {
        if (m_self == null) {
            m_self = new HistoryWindow(mainFrame, account);
            pane.add(m_self);
        }
        
        return m_self;
    }    
    
    /** Creates new form HistoryWindow */
    private HistoryWindow(JFrame frame, LJAccount account) {
        super(frame);
        
        m_lastN = LASTN_DEFAULT;
        
        m_account = account;
        initComponents();
        dateSpinner.setModel(new SpinnerDateModel());
        sharedJournalsComboBox.setModel(new DefaultComboBoxModel(new Vector(account.getSharedJournals())));
        
        lastEdit.setText(Integer.toString(m_lastN));
        m_history = new ArrayList<LJEvent>();
        createHistoryTable();
        
        onUpdateHistory();
        
        Options.loadBounds(this);        
    }
    
    private void onUpdateHistory() {
        Thread thread = new Thread() {
            public void run() {
                m_progressDialog.asyncShowDialog();
                m_progressDialog.setMessage("Loading History...");
                m_progressDialog.setIndeterminate(true);
                
                try {                    
                    try {
                       m_lastN = Integer.parseInt(lastEdit.getText());
                    }
                    catch (NumberFormatException e) {
                        m_lastN = LASTN_DEFAULT;
                    }

                    m_lastN = Math.min(m_lastN, LASTN_MAX);                    
                    if (m_lastN <= 0) {
                        m_lastN = LASTN_DEFAULT;
                    }

                    SwingUtilities.invokeAndWait(new Runnable() {
                        public void run() {
                            lastEdit.setText(Integer.toString(m_lastN));
                        }
                    });                    
                    
                    Date beforeDate = null;
                    if (beforeCheck.isSelected()) {
                        beforeDate = (Date)dateSpinner.getValue();
                    }
                    
                    String useJournal = (String)sharedJournalsComboBox.getSelectedItem();

                    m_history = m_account.loadHistory(EVENT_TRUNC, m_lastN, beforeDate, useJournal);
                    
                    SwingUtilities.invokeAndWait(new Runnable() {
                        public void run() {
                            historyTableModel.fireTableDataChanged();
                            TableUtil.adjustTableColumnSizes(historyTable);
                        }
                    });                    
                }
                catch (LJException e) {
                    ((LJMainFrame)getMainFrame()).handleException(e);
                }
                catch (Exception e) {                    
                }
                finally {
                    m_progressDialog.asyncCloseDialog();
                }
            }
        };
        
        m_progressDialog = new ProgressDialog(getMainFrame());
        thread.start();
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        eventListPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        historyTable = new javax.swing.JTable();
        buttonPanel = new javax.swing.JPanel();
        updateButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lastEdit = new javax.swing.JTextField();
        dateSpinner = new javax.swing.JSpinner();
        beforeCheck = new javax.swing.JCheckBox();
        sharedJournalsComboBox = new javax.swing.JComboBox();
        bottomButtonPanel = new javax.swing.JPanel();
        editEventButton = new javax.swing.JButton();
        deleteEventButton = new javax.swing.JButton();
        exportButton = new javax.swing.JButton();

        getContentPane().setLayout(new java.awt.GridBagLayout());

        setClosable(true);
        setResizable(true);
        setTitle(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("historyWindow_title"));
        setFrameIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/history.gif")));
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosed(evt);
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosing(evt);
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        eventListPanel.setLayout(new java.awt.BorderLayout());

        jScrollPane1.setPreferredSize(new java.awt.Dimension(50, 50));
        historyTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        historyTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        historyTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                historyTableMouseClicked(evt);
            }
        });

        jScrollPane1.setViewportView(historyTable);

        eventListPanel.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        getContentPane().add(eventListPanel, gridBagConstraints);

        buttonPanel.setLayout(new java.awt.GridBagLayout());

        updateButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("historyWindow_updateButton"));
        updateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        buttonPanel.add(updateButton, gridBagConstraints);

        jLabel1.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("historyWindow_last"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 0);
        buttonPanel.add(jLabel1, gridBagConstraints);

        lastEdit.setColumns(3);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 3, 0, 5);
        buttonPanel.add(lastEdit, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 3, 0, 0);
        buttonPanel.add(dateSpinner, gridBagConstraints);

        beforeCheck.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("historyWindow_before"));
        beforeCheck.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        beforeCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 0);
        buttonPanel.add(beforeCheck, gridBagConstraints);

        sharedJournalsComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        buttonPanel.add(sharedJournalsComboBox, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        getContentPane().add(buttonPanel, gridBagConstraints);

        bottomButtonPanel.setLayout(new java.awt.GridBagLayout());

        editEventButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("historyWindow_editButton"));
        editEventButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editEventButtonActionPerformed(evt);
            }
        });

        bottomButtonPanel.add(editEventButton, new java.awt.GridBagConstraints());

        deleteEventButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("historyWindow_deleteButton"));
        deleteEventButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteEventButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 3, 0, 0);
        bottomButtonPanel.add(deleteEventButton, gridBagConstraints);

        exportButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("historyWindow_exportButton"));
        exportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 3, 0, 0);
        bottomButtonPanel.add(exportButton, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        getContentPane().add(bottomButtonPanel, gridBagConstraints);

        setBounds(0, 0, 557, 411);
    }// </editor-fold>//GEN-END:initComponents

    private void exportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportButtonActionPerformed
        m_rows = historyTable.getSelectedRows();
        if (m_rows.length != 0) {
            if (m_exportFileChooser == null) {
                m_exportFileChooser = new JFileChooser();
                m_exportFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                m_exportFileChooser.setDialogTitle(m_ExportDialogTitle);
            }
            
            if (m_exportFileChooser.showDialog(getMainFrame(), m_ExportDialogTitle) == JFileChooser.APPROVE_OPTION) {
                Thread thread = new Thread() {
                    public void run() {
                        try {
                            m_progressDialog.setMessage("");
                            m_progressDialog.setMinimum(1);
                            m_progressDialog.setMaximum(m_rows.length);
                            m_progressDialog.asyncShowDialog();
                            
                            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();

                            File dir = m_exportFileChooser.getSelectedFile();

                            int progress = 1;
                            for (int row : m_rows) {
                                LJEvent event = m_history.get(row);
                                LJEvent expEvent = m_account.loadEvent(event.getID(), event.getJournal());

                                StringBuilder fName = new StringBuilder(dir.getAbsolutePath());
                                fName.append("\\");
                                fName.append(expEvent.getJournal());
                                fName.append("-");
                                if (expEvent.getPoster() == null) {
                                    fName.append(expEvent.getJournal());
                                } else {
                                    fName.append(expEvent.getPoster());
                                }
                                fName.append("-");
                                fName.append(expEvent.getID());
                                fName.append(".xml");
                                File expFile = new File(fName.toString());

                                org.w3c.dom.Document doc = builder.newDocument();
                                expEvent.toXML(doc);
                                javax.xml.transform.Transformer t = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
                                t.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(new FileOutputStream(expFile)));
                             
                                m_progressDialog.setValue(progress++);
                            }
                        }
                        catch (Exception e) {                    
                        }
                        finally {
                            m_progressDialog.asyncCloseDialog();
                        }
                    }
                };
                
                m_progressDialog = new ProgressDialog(getMainFrame());
                thread.start();
            }
        }
    }//GEN-LAST:event_exportButtonActionPerformed

    private void formInternalFrameClosed(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosed
        m_self = null;
    }//GEN-LAST:event_formInternalFrameClosed

    private void formInternalFrameClosing(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosing
        Options.saveBounds(this);
    }//GEN-LAST:event_formInternalFrameClosing

    private void editEventButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editEventButtonActionPerformed
        onEditEvent();
    }//GEN-LAST:event_editEventButtonActionPerformed

    private void deleteEventButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteEventButtonActionPerformed
        onDeleteEvent();
    }//GEN-LAST:event_deleteEventButtonActionPerformed

    private void historyTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_historyTableMouseClicked
        if (evt.getClickCount() == 2) {
            onEditEvent();
        }
    }//GEN-LAST:event_historyTableMouseClicked

    private void updateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateButtonActionPerformed
        onUpdateHistory();
    }//GEN-LAST:event_updateButtonActionPerformed
    
    private void onEditEvent() {
        int index = historyTable.getSelectedRow();
        if (index != -1) {
            LJEvent event = m_history.get(index);
            if ((event.getPoster() == null) || (event.getPoster().equals(UserProfileManager.getCurrentProfileName()))) {
                ((LJMainFrame)getMainFrame()).openPostWindow(event.getID(), event.getJournal());
            }
        }
    }
    
    private void onDeleteEvent() {
        int index = historyTable.getSelectedRow();
        if (index != -1) {
            if (JOptionPane.showConfirmDialog(getMainFrame(), "Are you sure?", "", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                try {
                    LJEvent event = m_history.get(index);
                    if ((event.getPoster() == null) || (event.getPoster().equals(UserProfileManager.getCurrentProfileName()))) {
                        m_account.deleteEvent(event);
                        ((LJMainFrame)getMainFrame()).closePostWindow(event.getID(), event.getJournal());
                        m_history.remove(index);
                        historyTableModel.fireTableDataChanged();
                        // TODO: close appropriate post window
                    }
                }
                catch (LJException e) {
                    ((LJMainFrame)getMainFrame()).handleException(e);
                }
            }
        }
    }
    
    private void createHistoryTable() {
        historyTableModel = new AbstractTableModel() {
            public int getColumnCount() { 
                return historyTableHeaderNames.length;
            }
            
            public int getRowCount() {
                return m_history.size();
            }

            public Object getValueAt(int row, int col) {
                return m_history.get(row);
            }
            
            public String getColumnName(int column) {
                return historyTableHeaderNames[column]; 
            }                                    
        };
        
        historyTable.setModel(historyTableModel);
        historyTable.setDefaultRenderer(Object.class, new HistoryTableCellRenderer());        
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox beforeCheck;
    private javax.swing.JPanel bottomButtonPanel;
    private javax.swing.JPanel buttonPanel;
    private javax.swing.JSpinner dateSpinner;
    private javax.swing.JButton deleteEventButton;
    private javax.swing.JButton editEventButton;
    private javax.swing.JPanel eventListPanel;
    private javax.swing.JButton exportButton;
    private javax.swing.JTable historyTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lastEdit;
    private javax.swing.JComboBox sharedJournalsComboBox;
    private javax.swing.JButton updateButton;
    // End of variables declaration//GEN-END:variables

    static {
        m_ExportDialogTitle = Options.getResourceBundle().getString("historyExportDialog_title");
    }
}
