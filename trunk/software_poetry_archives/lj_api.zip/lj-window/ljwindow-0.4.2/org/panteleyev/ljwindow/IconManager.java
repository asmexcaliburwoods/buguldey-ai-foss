/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import javax.swing.*;
import java.net.*;
import java.io.*;
import java.util.*;
import org.panteleyev.ljapi.*;
import org.panteleyev.tools.*;

public class IconManager {
    public static final int FRIEND_ICON         = 0;
    public static final int FRIENDOF_ICON       = 1;
    public static final int MUTUAL_FRIEND_ICON  = 2;
    public static final int COMMUNITY_ICON      = 3;
    public static final int SUSPENDED_ICON      = 4;
    public static final int DELETED_ICON        = 5;
    public static final int PURGED_ICON         = 6;
    public static final int FRIENDS_WINDOW_ICON = 7;
    public static final int FRIEND_HEAD_ICON    = 8;
    public static final int ABOUT               = 9;
    public static final int DOWN_MENU           = 10;
    public static final int NEW_POST            = 11;
    public static final int LOCK                = 12;
    public static final int PRIVATE             = 13;
    public static final int HISTORY             = 14;
    public static final int EMPTY               = 15;
    public static final int SAVE                = 16;
    public static final int OPEN                = 17;
    public static final int SYNDICATED          = 18;
    
    private static final int NUM = 19;
    
    private static ImageIcon[] icons;
    private static HashMap<String,LJUserpic> userpics;
    
    public static void loadIcons(Object o) {
        icons = new ImageIcon[NUM];
        
        icons[FRIEND_ICON]          = new ImageIcon(o.getClass().getResource("resources/friend.gif"));
        icons[FRIENDOF_ICON]        = new ImageIcon(o.getClass().getResource("resources/friendof.gif"));
        icons[MUTUAL_FRIEND_ICON]   = new ImageIcon(o.getClass().getResource("resources/mutual.gif"));
        icons[COMMUNITY_ICON]       = new ImageIcon(o.getClass().getResource("resources/community.gif"));
        icons[SUSPENDED_ICON]       = new ImageIcon(o.getClass().getResource("resources/suspended.gif"));
        icons[DELETED_ICON]         = new ImageIcon(o.getClass().getResource("resources/deleted.gif"));
        icons[PURGED_ICON]          = new ImageIcon(o.getClass().getResource("resources/purged.gif"));
        icons[FRIENDS_WINDOW_ICON]  = new ImageIcon(o.getClass().getResource("resources/edit_friends.gif"));
        icons[FRIEND_HEAD_ICON]     = new ImageIcon(o.getClass().getResource("resources/friend_head.gif"));
        icons[ABOUT]                = new ImageIcon(o.getClass().getResource("resources/about.gif"));
        icons[DOWN_MENU]            = new ImageIcon(o.getClass().getResource("resources/down.gif"));
        icons[NEW_POST]             = new ImageIcon(o.getClass().getResource("resources/new_post.gif"));
        icons[LOCK]                 = new ImageIcon(o.getClass().getResource("resources/lock.gif"));
        icons[PRIVATE]              = new ImageIcon(o.getClass().getResource("resources/private.gif"));
        icons[HISTORY]              = new ImageIcon(o.getClass().getResource("resources/history.gif"));
        icons[EMPTY]                = new ImageIcon(o.getClass().getResource("resources/noicon.gif"));
        icons[SAVE]                 = new ImageIcon(o.getClass().getResource("resources/save.gif"));
        icons[OPEN]                 = new ImageIcon(o.getClass().getResource("resources/open.gif"));
        icons[SYNDICATED]           = new ImageIcon(o.getClass().getResource("resources/syn.gif"));
    }
    
    public static void loadUserpics(LJAccount account, LJProgressCallback ph) {
        userpics.clear();
        
        int count = account.getUserpicKeys().size();
        ph.setMinimum(0);
        ph.setMaximum(count - 1);
        
        for (int i = 0; i < count; i++) {
            try {
                String key = account.getUserpicKeys().get(i);
                URL url = account.getUserpicUrls().get(i);

                LJUserpic icon = Options.loadUserpic(key, url);
                if (icon == null) {
                    URLConnection conn = url.openConnection();
                    java.awt.image.BufferedImage bim = javax.imageio.ImageIO.read(conn.getInputStream());
                    if (bim != null) {
                        icon = new LJUserpic(bim, url.toString());
                        Options.storeUserpic(key, url, bim);
                    }
                }

                if (icon != null) {
                    userpics.put(key, icon);
                }
                ph.setValue(i);                    
            }
            catch (IOException e) {                            
            }
        }
    }
    
    public static ImageIcon getIcon(int index) { return icons[index]; }    
    public static LJUserpic getUserpic(String key) { return userpics.get(key); }
    
    static {
        userpics = new HashMap<String,LJUserpic>();        
    }
}
