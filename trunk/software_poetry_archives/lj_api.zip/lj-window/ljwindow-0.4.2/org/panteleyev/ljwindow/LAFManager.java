/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import javax.swing.*;

/**
 *
 * @author peterp
 */
public class LAFManager {
    private static UIManager.LookAndFeelInfo[] info;
    private static int currentIndex;
    
    public static UIManager.LookAndFeelInfo[] getLAFInfo() { return info; }
    
    public static String[] getLAFNames() {
        String names[] = new String[info.length];
        
        for (int i = 0; i < info.length; i++) {
            names[i] = info[i].getName();
        }

        return names;
    }
    
    public static void setLAF(int index) {        
        try {
            if ((index >= 0) && (index < info.length)) {
                UIManager.setLookAndFeel(info[index].getClassName());
                currentIndex = index;
            }
        }
        catch (Exception e) {
            // do nothing, just ignore
        }
    }
    
    public static String getClassName(int index) {
        if ((index >= 0) && (index < info.length)) {
            return info[index].getClassName();
        } else {
            return null;
        }
    }
    
    public static void setLAF(String className) {
        for (int i = 0; i < info.length; i++) {
            if (className.equals(info[i].getClassName())) {
                try {
                    UIManager.setLookAndFeel(className);
                    currentIndex = i;
                }
                catch (Exception e) {                    
                }
                return;
            }
        }
    }
    
    public static int getLAFIndex() { return currentIndex; }
    
    static {
        info = UIManager.getInstalledLookAndFeels();
    }
}
