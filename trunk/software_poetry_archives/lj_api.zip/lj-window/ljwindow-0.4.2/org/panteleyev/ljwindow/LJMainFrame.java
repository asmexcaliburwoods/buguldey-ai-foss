/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import org.panteleyev.ljapi.*;
import org.panteleyev.tools.*;

public class LJMainFrame extends javax.swing.JFrame implements ApplicationInternalEventHandler {
    private LJAccount m_account;
    
    private OptionsDialog optDialog;
    private boolean connected;
    
    /* Variables for separate thread */
    UserProfile prof;
    String loginName;
    String passwd;
    boolean storePasswd;
    ProgressDialog pDial = null;
    LJEvent m_event;
    int m_id;
    ArrayList<LJTag> m_tags;
    String m_useJournal;
    PostWindow m_postWnd;
    LJMainFrame m_self;
    /**********************************/
    
    /* Shared global resources */
    private static JMenu friendsMenu;
    private static JMenu communitiesMenu;
    private static JMenu tagsMenu;
    
    /* Various convenience arrays */
    AbstractAction m_postWindowActions[];
    AbstractAction m_toolbarActions[];
    
    /** Creates new form LJMainFrame */
    public LJMainFrame() {
        m_self = this;
        
        IconManager.loadIcons(this);

        UserProfileManager.loadProfiles();
        Options.setSystemProxySettings();
        
        createActions();
        initComponents();
        createToolBar();        
        
        m_account = new LJAccount();
        
        Options.loadMainFrameBounds(this);
        
        setConnected(false);
        updateMenuItems();        
        postWindowActivated(false); /* temporary hack */
    }
     
    private void createActions() {        
        ResourceBundle bundle = Options.getResourceBundle();

        addFriendAction = new AbstractAction(bundle.getString("addFriendAction"), IconManager.getIcon(IconManager.FRIEND_HEAD_ICON)) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onAddFriend(); }
        };       
        addFriendAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK | InputEvent.ALT_MASK));
        
        openFriendsWindowAction = new AbstractAction(bundle.getString("accountFriendsMenuItem"), IconManager.getIcon(IconManager.FRIENDS_WINDOW_ICON)) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onFriendsWindow(); }
        };
        openFriendsWindowAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_MASK));
        
        newPostAction = new AbstractAction(bundle.getString("fileNewPostMenuItem"), IconManager.getIcon(IconManager.NEW_POST)) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onNewPost(); }
        };
        
        editLastPostAction = new AbstractAction(bundle.getString("editLastPostAction")) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onEditLastPost();
            }
        };
        editLastPostAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_L, InputEvent.CTRL_MASK));
        
        historyWindowAction = new AbstractAction(bundle.getString("historyWindowAction"), IconManager.getIcon(IconManager.HISTORY)) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onHistoryWindow();
            }
        };
        historyWindowAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_MASK));
        
        /*
         * Format actions
         */
        strikeAction = new AbstractAction(bundle.getString("strikeMenuItem"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/strike.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onStrike(); }
        };
        strikeAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK));
        
        underscoreAction = new AbstractAction(bundle.getString("underscoreMenuItem"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/underscore.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onUnderscore(); }
        };
        underscoreAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_U, InputEvent.CTRL_MASK));

        boldAction = new AbstractAction(bundle.getString("boldMenuItem"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/bold.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onBold(); }
        };
        boldAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_B, InputEvent.CTRL_MASK));
        
        italicsAction = new AbstractAction(bundle.getString("italicsMenuItem"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/italics.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onItalics(); }
        };        
        italicsAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_MASK));
        
        fontIncreaseAction = new AbstractAction(bundle.getString("fontIncreaseAction"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/font_inc.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onFontIncrease(); }
        };        
        fontIncreaseAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_EQUALS, InputEvent.ALT_MASK));

        fontDecreaseAction = new AbstractAction(bundle.getString("fontDecreaseAction"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/font_dec.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onFontDecrease(); }
        };        
        fontDecreaseAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_MINUS, InputEvent.ALT_MASK));
        
        aboutAction = new AbstractAction(bundle.getString("aboutMenuItem"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/about.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onAbout(); }
        };
        
        insertFriendAction = new AbstractAction("", new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/insert_friend.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onFriendsMenuItemSelected(null); }
        };
        
        friendsMenuAction = new AbstractAction("", new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/down.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPopupMenu menu = getFriendsMenu().getPopupMenu();        
                int x = ((JButton)evt.getSource()).getX();
                menu.show(desktopPane, x, 0);
            }
        };
        
        insertCommunityAction = new AbstractAction("", new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/insert_community.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onCommunityMenuItemSelected(null); }
        };
        
        communitiesMenuAction = new AbstractAction("", new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/down.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JPopupMenu menu = getCommunitiesMenu().getPopupMenu();
                int x = ((JButton)evt.getSource()).getX();
                menu.show(desktopPane, x, 0);
            }
        };
        
        consoleAction = new AbstractAction(bundle.getString("consoleMenuItem"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/console.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { onConsole(); }
        };
        
        /* LJ-Cut */
        ljCutAction = new AbstractAction("", new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/ljcut.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) { 
                PostWindow wnd = getCurrentPostWindow();
                if (wnd != null) {
                    wnd.onLJCutOpen(null);
                }
            }
        };
        
        ljCutMenuAction = new AbstractAction("", new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/down.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                int x = ((JButton)evt.getSource()).getX();
                ljcutPopupMenu.show(desktopPane, x, 0);
            }
        };
        
        /* Edit menu */
        editInsertReferenceAction =  new AbstractAction(bundle.getString("insertReferenceMenuItem"), new ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/rich_reference.gif"))) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onInsertReference();
            }
        };
        editInsertReferenceAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.CTRL_MASK));
        
        /* Save As... */
        saveAsAction = new AbstractAction(bundle.getString("saveAsAction"), IconManager.getIcon(IconManager.EMPTY)) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onSaveAs();
            }
        };
        
        saveAction = new AbstractAction(bundle.getString("saveAction"), IconManager.getIcon(IconManager.SAVE)) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onSave();
            }
        };
        saveAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
        
        openAction = new AbstractAction(bundle.getString("openAction"), IconManager.getIcon(IconManager.OPEN)) {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                onOpen();
            }
        };
        openAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
        
        /* Create convenience arrays */
        m_postWindowActions = new AbstractAction[] {
            boldAction,
            italicsAction,
            underscoreAction,
            strikeAction,
            editInsertReferenceAction,
            ljCutAction,
            ljCutMenuAction,
            friendsMenuAction,
            communitiesMenuAction,
            insertFriendAction,
            insertCommunityAction,
            fontIncreaseAction,
            fontDecreaseAction,            
        };
        
        m_toolbarActions = new AbstractAction[] {
            addFriendAction,
            openFriendsWindowAction,
            historyWindowAction, 
            null,
            boldAction, 
            italicsAction, 
            underscoreAction, 
            strikeAction, 
            null,
            fontIncreaseAction, 
            fontDecreaseAction, 
            null,
            editInsertReferenceAction, 
            null,
            insertFriendAction, 
            friendsMenuAction, 
            insertCommunityAction, 
            communitiesMenuAction,
            ljCutAction, 
            ljCutMenuAction, 
            null,
            aboutAction
        };        
    }
        
    private void createToolBar() {        
        JButton button;
        
        for (AbstractAction a : m_toolbarActions) {
            if (a == null) {
                toolBar.addSeparator();
            } else {
                toolBar.add(a).setFocusPainted(false);
            }
        }
    }

    private void onConsole() {
        AdminConsoleWindow wnd = AdminConsoleWindow.getAdminConsoleWindow(this, desktopPane, m_account);
        wnd.bringToTop();
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        ljcutPopupMenu = new javax.swing.JPopupMenu();
        ljcutOpenMenuItem = new javax.swing.JMenuItem();
        ljcutWithTextMenuItem = new javax.swing.JMenuItem();
        ljcutCloseMenuItem = new javax.swing.JMenuItem();
        ljcutSurroundMenuItem = new javax.swing.JMenuItem();
        desktopPane = new javax.swing.JDesktopPane();
        toolBar = new javax.swing.JToolBar();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        fileNewPostMenuItem = new javax.swing.JMenuItem();
        openMenuItem = new javax.swing.JMenuItem();
        saveMenuItem = new javax.swing.JMenuItem();
        saveAsMenuItem = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JSeparator();
        fileExitMenuItem = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        insertReferenceMenuItem = new javax.swing.JMenuItem();
        insertAdvUserReferenceMenuItem = new javax.swing.JMenuItem();
        insertImageReferenceMenuItem = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JSeparator();
        quotesSubMenu = new javax.swing.JMenu();
        russianQuotesMenuItem = new javax.swing.JMenuItem();
        frenchQuotesMenuItem = new javax.swing.JMenuItem();
        englishQuotesMenuItem = new javax.swing.JMenuItem();
        englishSingleQuotesMenuItem = new javax.swing.JMenuItem();
        symbolsSubMenu = new javax.swing.JMenu();
        copyrightSymbolMenuItem = new javax.swing.JMenuItem();
        tradeSymbolMenuItem = new javax.swing.JMenuItem();
        hellipSymbolMenuItem = new javax.swing.JMenuItem();
        formatMenu = new javax.swing.JMenu();
        boldMenuItem = new javax.swing.JMenuItem();
        italicsMenuItem = new javax.swing.JMenuItem();
        underscoreMenuItem = new javax.swing.JMenuItem();
        strikeMenuItem = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        increaseFontMenuItem = new javax.swing.JMenuItem();
        decreaseFontMenuItem = new javax.swing.JMenuItem();
        accountMenu = new javax.swing.JMenu();
        fileConnectMenuItem = new javax.swing.JMenuItem();
        fileDisconnectMenuItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        editLastEntryMenuItem = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        addFriendMenuItem = new javax.swing.JMenuItem();
        accountFriendsMenuItem = new javax.swing.JMenuItem();
        historyMenuItem = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        consoleMenuItem = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JSeparator();
        webSubMenu = new javax.swing.JMenu();
        recentEntriesMenuItem = new javax.swing.JMenuItem();
        calendarMenuItem = new javax.swing.JMenuItem();
        friendsMenuItem = new javax.swing.JMenuItem();
        toolsMenu = new javax.swing.JMenu();
        toolsOptionsMenuItem = new javax.swing.JMenuItem();
        windowMenu = new javax.swing.JMenu();
        windowCloseMenuItem = new javax.swing.JMenuItem();
        windowListSeparator = new javax.swing.JSeparator();
        helpMenu = new javax.swing.JMenu();
        helpAboutMenuItem = new javax.swing.JMenuItem();
        helpLicenseMenuItem = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JSeparator();
        homePageMenuItem = new javax.swing.JMenuItem();
        communityMenuItem = new javax.swing.JMenuItem();

        ljcutOpenMenuItem.setText("LJ Cut");
        ljcutOpenMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ljcutOpenMenuItemActionPerformed(evt);
            }
        });

        ljcutPopupMenu.add(ljcutOpenMenuItem);

        ljcutWithTextMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("ljCutMenu_withText"));
        ljcutWithTextMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ljcutWithTextMenuItemActionPerformed(evt);
            }
        });

        ljcutPopupMenu.add(ljcutWithTextMenuItem);

        ljcutCloseMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("ljCutMenu_close"));
        ljcutCloseMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ljcutCloseMenuItemActionPerformed(evt);
            }
        });

        ljcutPopupMenu.add(ljcutCloseMenuItem);

        ljcutSurroundMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("ljCutMenu_surround"));
        ljcutSurroundMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ljcutSurroundMenuItemActionPerformed(evt);
            }
        });

        ljcutPopupMenu.add(ljcutSurroundMenuItem);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("LiveJournal Window");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        getContentPane().add(desktopPane, java.awt.BorderLayout.CENTER);

        toolBar.setFloatable(false);
        getContentPane().add(toolBar, java.awt.BorderLayout.NORTH);

        fileMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("menuFile"));
        fileNewPostMenuItem.setAction(newPostAction);
        fileNewPostMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        fileMenu.add(fileNewPostMenuItem);

        openMenuItem.setAction(openAction);
        fileMenu.add(openMenuItem);

        saveMenuItem.setAction(saveAction);
        fileMenu.add(saveMenuItem);

        saveAsMenuItem.setAction(saveAsAction);
        fileMenu.add(saveAsMenuItem);

        fileMenu.add(jSeparator7);

        fileExitMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        fileExitMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Exit"));
        fileExitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileExitMenuItemActionPerformed(evt);
            }
        });

        fileMenu.add(fileExitMenuItem);

        menuBar.add(fileMenu);

        editMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("menuEdit"));
        insertReferenceMenuItem.setAction(editInsertReferenceAction);
        editMenu.add(insertReferenceMenuItem);

        insertAdvUserReferenceMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        insertAdvUserReferenceMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        insertAdvUserReferenceMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("insertAdvUserReferenceMenuItem"));
        insertAdvUserReferenceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertAdvUserReferenceMenuItemActionPerformed(evt);
            }
        });

        editMenu.add(insertAdvUserReferenceMenuItem);

        insertImageReferenceMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        insertImageReferenceMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        insertImageReferenceMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("insertImageReferenceMenuItem"));
        insertImageReferenceMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertImageReferenceMenuItemActionPerformed(evt);
            }
        });

        editMenu.add(insertImageReferenceMenuItem);

        editMenu.add(jSeparator8);

        quotesSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        quotesSubMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("quotesSubMenu"));
        russianQuotesMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("russianQuotesMenuItem"));
        russianQuotesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                russianQuotesMenuItemActionPerformed(evt);
            }
        });

        quotesSubMenu.add(russianQuotesMenuItem);

        frenchQuotesMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("frenchQuotesMenuItem"));
        frenchQuotesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                frenchQuotesMenuItemActionPerformed(evt);
            }
        });

        quotesSubMenu.add(frenchQuotesMenuItem);

        englishQuotesMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("englishQuotesMenuItem"));
        englishQuotesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishQuotesMenuItemActionPerformed(evt);
            }
        });

        quotesSubMenu.add(englishQuotesMenuItem);

        englishSingleQuotesMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("englishSingleQuotesMenuItem"));
        englishSingleQuotesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishSingleQuotesMenuItemActionPerformed(evt);
            }
        });

        quotesSubMenu.add(englishSingleQuotesMenuItem);

        editMenu.add(quotesSubMenu);

        symbolsSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        symbolsSubMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("symbolsSubMenu"));
        copyrightSymbolMenuItem.setText("\u00a9 - Copyright");
        copyrightSymbolMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                copyrightSymbolMenuItemActionPerformed(evt);
            }
        });

        symbolsSubMenu.add(copyrightSymbolMenuItem);

        tradeSymbolMenuItem.setText("\u2122 - Trade Mark");
        tradeSymbolMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tradeSymbolMenuItemActionPerformed(evt);
            }
        });

        symbolsSubMenu.add(tradeSymbolMenuItem);

        hellipSymbolMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("hellipSymbolMenuItem"));
        hellipSymbolMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hellipSymbolMenuItemActionPerformed(evt);
            }
        });

        symbolsSubMenu.add(hellipSymbolMenuItem);

        editMenu.add(symbolsSubMenu);

        menuBar.add(editMenu);

        formatMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("menuFormat"));
        boldMenuItem.setAction(boldAction);
        formatMenu.add(boldMenuItem);

        italicsMenuItem.setAction(italicsAction);
        formatMenu.add(italicsMenuItem);

        underscoreMenuItem.setAction(underscoreAction);
        formatMenu.add(underscoreMenuItem);

        strikeMenuItem.setAction(strikeAction);
        formatMenu.add(strikeMenuItem);

        formatMenu.add(jSeparator4);

        increaseFontMenuItem.setAction(fontIncreaseAction);
        formatMenu.add(increaseFontMenuItem);

        decreaseFontMenuItem.setAction(fontDecreaseAction);
        formatMenu.add(decreaseFontMenuItem);

        menuBar.add(formatMenu);

        accountMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("Journal"));
        fileConnectMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        fileConnectMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("fileConnectMenuItem"));
        fileConnectMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileConnectMenuItemActionPerformed(evt);
            }
        });

        accountMenu.add(fileConnectMenuItem);

        fileDisconnectMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        fileDisconnectMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("fileDisconnectMenuItem"));
        fileDisconnectMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileDisconnectMenuItemActionPerformed(evt);
            }
        });

        accountMenu.add(fileDisconnectMenuItem);

        accountMenu.add(jSeparator1);

        editLastEntryMenuItem.setAction(editLastPostAction);
        editLastEntryMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        editLastEntryMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        accountMenu.add(editLastEntryMenuItem);

        accountMenu.add(jSeparator2);

        addFriendMenuItem.setAction(addFriendAction);
        addFriendMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F, java.awt.event.InputEvent.ALT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        accountMenu.add(addFriendMenuItem);

        accountFriendsMenuItem.setAction(openFriendsWindowAction);
        accountMenu.add(accountFriendsMenuItem);

        historyMenuItem.setAction(historyWindowAction);
        historyMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                historyMenuItemActionPerformed(evt);
            }
        });

        accountMenu.add(historyMenuItem);

        accountMenu.add(jSeparator3);

        consoleMenuItem.setAction(consoleAction);
        accountMenu.add(consoleMenuItem);

        accountMenu.add(jSeparator5);

        webSubMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        webSubMenu.setText("Web");
        recentEntriesMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        recentEntriesMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("recentEntriesMenuItem"));
        recentEntriesMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recentEntriesMenuItemActionPerformed(evt);
            }
        });

        webSubMenu.add(recentEntriesMenuItem);

        calendarMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        calendarMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("calendarMenuItem"));
        calendarMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calendarMenuItemActionPerformed(evt);
            }
        });

        webSubMenu.add(calendarMenuItem);

        friendsMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        friendsMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("friendsMenuItem"));
        friendsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                friendsMenuItemActionPerformed(evt);
            }
        });

        webSubMenu.add(friendsMenuItem);

        accountMenu.add(webSubMenu);

        menuBar.add(accountMenu);

        toolsMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("menuTools"));
        toolsOptionsMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/options.gif")));
        toolsOptionsMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("optionsMenuItem"));
        toolsOptionsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                toolsOptionsMenuItemActionPerformed(evt);
            }
        });

        toolsMenu.add(toolsOptionsMenuItem);

        menuBar.add(toolsMenu);

        windowMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("menuWindow"));
        windowMenu.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent evt) {
            }
            public void menuDeselected(javax.swing.event.MenuEvent evt) {
            }
            public void menuSelected(javax.swing.event.MenuEvent evt) {
                windowMenuMenuSelected(evt);
            }
        });

        windowCloseMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.CTRL_MASK));
        windowCloseMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/noicon.gif")));
        windowCloseMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("windowCloseMenuItem"));
        windowCloseMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                windowCloseMenuItemActionPerformed(evt);
            }
        });

        windowMenu.add(windowCloseMenuItem);

        windowMenu.add(windowListSeparator);

        menuBar.add(windowMenu);

        helpMenu.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("menuHelp"));
        helpAboutMenuItem.setAction(aboutAction);
        helpMenu.add(helpAboutMenuItem);

        helpLicenseMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/license.gif")));
        helpLicenseMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("License"));
        helpLicenseMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpLicenseMenuItemActionPerformed(evt);
            }
        });

        helpMenu.add(helpLicenseMenuItem);

        helpMenu.add(jSeparator6);

        homePageMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        homePageMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("homePageMenuItem"));
        homePageMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homePageMenuItemActionPerformed(evt);
            }
        });

        helpMenu.add(homePageMenuItem);

        communityMenuItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/earth.gif")));
        communityMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("communityMenuItem"));
        communityMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                communityMenuItemActionPerformed(evt);
            }
        });

        helpMenu.add(communityMenuItem);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-687)/2, (screenSize.height-533)/2, 687, 533);
    }// </editor-fold>//GEN-END:initComponents

    private void englishSingleQuotesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishSingleQuotesMenuItemActionPerformed
        onFormatTag("&lsquo;", "&rsquo;");
    }//GEN-LAST:event_englishSingleQuotesMenuItemActionPerformed

    private void hellipSymbolMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hellipSymbolMenuItemActionPerformed
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onEllipsysSymbol();
        }
    }//GEN-LAST:event_hellipSymbolMenuItemActionPerformed

    private void tradeSymbolMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tradeSymbolMenuItemActionPerformed
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onTradeSymbol();
        }
    }//GEN-LAST:event_tradeSymbolMenuItemActionPerformed

    private void copyrightSymbolMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_copyrightSymbolMenuItemActionPerformed
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onCopyrightSymbol();
        }                
    }//GEN-LAST:event_copyrightSymbolMenuItemActionPerformed

    private void englishQuotesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishQuotesMenuItemActionPerformed
        onFormatTag("&ldquo;", "&rdquo;");
    }//GEN-LAST:event_englishQuotesMenuItemActionPerformed

    private void frenchQuotesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_frenchQuotesMenuItemActionPerformed
        onFormatTag("&laquo;", "&raquo;");
    }//GEN-LAST:event_frenchQuotesMenuItemActionPerformed

    private void russianQuotesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_russianQuotesMenuItemActionPerformed
        onFormatTag("&bdquo;", "&rdquo;");
    }//GEN-LAST:event_russianQuotesMenuItemActionPerformed

    private void communityMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_communityMenuItemActionPerformed
        Utils.runBrowser("http://javaljwindow.livejournal.com/");
    }//GEN-LAST:event_communityMenuItemActionPerformed

    private void homePageMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homePageMenuItemActionPerformed
        // TODO make this configurable
        Utils.runBrowser("http://ljwindow.sourceforge.net/");
    }//GEN-LAST:event_homePageMenuItemActionPerformed

    private void friendsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_friendsMenuItemActionPerformed
        openAccountLink("friends");
    }//GEN-LAST:event_friendsMenuItemActionPerformed

    private void calendarMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calendarMenuItemActionPerformed
        openAccountLink("calendar");
    }//GEN-LAST:event_calendarMenuItemActionPerformed

    private void recentEntriesMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recentEntriesMenuItemActionPerformed
        openAccountLink("");
    }//GEN-LAST:event_recentEntriesMenuItemActionPerformed

    private void insertImageReferenceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertImageReferenceMenuItemActionPerformed
        onInsertImageReference();
    }//GEN-LAST:event_insertImageReferenceMenuItemActionPerformed

    private void insertAdvUserReferenceMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertAdvUserReferenceMenuItemActionPerformed
        onInsertAdvancedUserReference();
    }//GEN-LAST:event_insertAdvUserReferenceMenuItemActionPerformed
    
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        onExit();
    }//GEN-LAST:event_formWindowClosing

    private void onHistoryWindow() {
        HistoryWindow wnd = HistoryWindow.getHistoryWindow(this, desktopPane, m_account);
        wnd.bringToTop();
    }
    
    private void historyMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_historyMenuItemActionPerformed
        onHistoryWindow();
    }//GEN-LAST:event_historyMenuItemActionPerformed

    private void onInsertReference() {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onInsertReference();
        }
    }
    
    private void onInsertAdvancedUserReference() {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onInsertAdvancedUserReference();
        }
    }
    
    private void onInsertImageReference() {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onInsertImageReference();
        }
    }
    
    
    private void windowMenuMenuSelected(javax.swing.event.MenuEvent evt) {//GEN-FIRST:event_windowMenuMenuSelected
        JInternalFrame frame = desktopPane.getSelectedFrame();
        boolean hasFrame = frame != null;
        
        windowCloseMenuItem.setEnabled(hasFrame);
        
        // calculate position of the windowListSeparator
        int startIndex = 0;
        for (java.awt.Component comp : windowMenu.getMenuComponents()) {
            if (comp == windowListSeparator) {
                break;
            }
            
            startIndex++;
        }
        
        // remove all menus after windowListSeparator
        int count = windowMenu.getItemCount();
        for (int index = count - 1; index > startIndex; index--) {
            windowMenu.remove(index);
        }
        
        JInternalFrame[] frs = desktopPane.getAllFrames();
        if (frs.length == 0) {
            windowListSeparator.setVisible(false);
        } else {
            windowListSeparator.setVisible(true);
            for (JInternalFrame f : frs) {
                if (f instanceof MDIChildWindow) {
                    JMenuItem item = ((MDIChildWindow)f).getFrameMenuItem();
                    windowMenu.add(item);
                    item.setSelected(f == frame);
                }
            }
        }
    }//GEN-LAST:event_windowMenuMenuSelected

    private void windowCloseMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_windowCloseMenuItemActionPerformed
        JInternalFrame frame = desktopPane.getSelectedFrame();
        if (frame != null) {
            try {
                frame.setClosed(true);
            }
            catch (java.beans.PropertyVetoException e) {
                frame.dispose();
            }
        }
    }//GEN-LAST:event_windowCloseMenuItemActionPerformed

    private void onFormatTag(String tag) {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onFormatTag(tag);
        }
    }
    
    private void onFormatTag(String open, String close) {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onFormatTag(open, close);
        }
    }
    
    private void onBold() {
        onFormatTag("b");
    }

    private void onItalics() {
        onFormatTag("i");
    }

    private void onUnderscore() {
        onFormatTag("u");
    }
    
    private void onStrike() {
        onFormatTag("strike");
    }
    
    private void onFontIncrease() {
        onFormatTag("<font size='+1'>", "</font>");
    }

    private void onFontDecrease() {
        onFormatTag("<font size='-1'>", "</font>");
    }
    
    private void ljcutSurroundMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ljcutSurroundMenuItemActionPerformed
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onLJCutSurround();
        }
    }//GEN-LAST:event_ljcutSurroundMenuItemActionPerformed

    private void ljcutCloseMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ljcutCloseMenuItemActionPerformed
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onLJCutClose();
        }
    }//GEN-LAST:event_ljcutCloseMenuItemActionPerformed

    private void ljcutWithTextMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ljcutWithTextMenuItemActionPerformed
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            String text = JOptionPane.showInputDialog(this, "Text");
            if (text != null) {
                wnd.onLJCutOpen(text);
            }
        }        
    }//GEN-LAST:event_ljcutWithTextMenuItemActionPerformed

    private void ljcutOpenMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ljcutOpenMenuItemActionPerformed
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onLJCutOpen(null);
        }
    }//GEN-LAST:event_ljcutOpenMenuItemActionPerformed

    private void onAbout() {
        new AboutDialog(this).showDialog();
    }
    
    private void onAddFriend() {
        FriendsWindow wnd = FriendsWindow.getFriendsWindow();
        if (wnd != null) {
            wnd.onAddFriend();
        } else {
            FriendDialog dial = new FriendDialog(this, null, m_account.getGroups(), true);
            if (dial.showDialog()) {
                LJFriend f;
                /* Check if it's the same friend of */
                String newName = dial.getUserName();
                f = new LJFriend(dial.getUserName());
                f.setFg(dial.getFg());
                f.setBg(dial.getBg());
                f.setGroupMask(dial.getGroupMask());
                try {
                   m_account.addFriend(f);
                }
                catch (LJException e) {
                    handleException(e);
                }
            }                    
        }
    }
        
    private void onFriendsWindow() {
        FriendsWindow wnd = FriendsWindow.createFriendsWindow(this, desktopPane, m_account);
        wnd.bringToTop();
    }
    
    private void closeAllChildWindows() {
        for (JInternalFrame frame : desktopPane.getAllFrames()) {
            try {
                frame.setClosed(true);
            } catch (Exception e) {}
        }
    }
        
    private void fileDisconnectMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileDisconnectMenuItemActionPerformed
        closeAllChildWindows();        
        setTitle("LJ Window");
        connected = false;
        UserProfileManager.setCurrentProfile(null);
        updateMenuItems();
    }//GEN-LAST:event_fileDisconnectMenuItemActionPerformed

    public boolean isConnected() { return this.connected; }
    private void setConnected(boolean b) { this.connected = b; }
    
    public void postWindowActivated(boolean activated) {
        editMenu.setVisible(activated);
        formatMenu.setVisible(activated);
        
        for (AbstractAction a : m_postWindowActions) {
            a.setEnabled(activated);
        }
    }
    
    private void updateMenuItems() {
        
        boolean b = isConnected();
        
        this.addFriendAction.setEnabled(b);
        this.openFriendsWindowAction.setEnabled(b);
        this.newPostAction.setEnabled(b);
        this.editLastPostAction.setEnabled(b);
        this.consoleAction.setEnabled(b);
        this.historyWindowAction.setEnabled(b);
        
        openAction.setEnabled(b);
        saveAction.setEnabled(b);
        saveAsAction.setEnabled(b);
                
        this.fileConnectMenuItem.setEnabled(!isConnected());
        this.fileDisconnectMenuItem.setEnabled(isConnected());        
        
        webSubMenu.setEnabled(b);
    }
        
    private void onEditLastPost() {
        openPostWindow(-1, UserProfileManager.getCurrentProfile().getUserName());
    }
    
    private LJEvent loadEvent(int id, String useJournal) {
        m_event = null;
        m_id = id;
        m_useJournal = useJournal;
        
        try {
            m_event = m_account.loadEvent(m_id, m_useJournal);
        }
        catch (LJException e) {
            handleException(e);
        }
        
        return m_event;
    }
    
    private PostWindow findPostWindowForPost(int id, String useJournal) {
        for (JInternalFrame frame : desktopPane.getAllFrames()) {
            if (frame instanceof PostWindow) {
                PostWindow w = (PostWindow)frame;
                if ((w.getPostID() == id) && (w.getUseJournal().equals(useJournal))) {
                    return w;
                }
            }
        }
        
        return null;
    }
    
    public void closePostWindow(int id, String useJournal) {
        PostWindow w = findPostWindowForPost(id, useJournal);
        if (w != null) {
            w.dispose();
        }
    }
    
    public void openPostWindow(LJEvent event) {
        PostWindow wnd = new PostWindow(this, m_account, event);
        desktopPane.add(wnd);
        wnd.bringToTop();
    }
    
    public void openPostWindow(int id, String useJournal) {
        m_id = id;
        m_useJournal = useJournal;
        m_event = null;
        
        Thread thread = new Thread() {
            public void run() {
                pDial.asyncShowDialog();
                pDial.setMessage("Loading Post...");
                pDial.setIndeterminate(true);
                
                /* Handle last entry case */
                if (m_id == -1) {
                    m_event = loadEvent(m_id, m_useJournal);
                    if (m_event != null) {
                        m_id = m_event.getID();
                    }
                }

                if (m_id != -1) {
                    m_postWnd = findPostWindowForPost(m_id, m_useJournal);

                    if (m_postWnd == null) {
                        if (m_event == null) {
                            m_event = loadEvent(m_id, m_useJournal);
                        }

                        if (m_event != null) {
                            m_postWnd = new PostWindow(m_self, m_account, m_event);
                            desktopPane.add(m_postWnd);
                        }
                    }

                    SwingUtilities.invokeLater(new Runnable() {
                        public void run() {
                            m_postWnd.bringToTop();
                        }
                    });                    
                }
                
                pDial.asyncCloseDialog();
            }
        };

        pDial = new ProgressDialog(this);
        thread.start();
    }
    
    private void onNewPost() {
        PostWindow pw = new PostWindow(this, m_account, null);
        desktopPane.add(pw);
        pw.setVisible(true);
    }
    
    private void helpLicenseMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpLicenseMenuItemActionPerformed
        LicenseWindow wnd = LicenseWindow.getLicenseWindow(desktopPane);
        wnd.bringToTop();
    }//GEN-LAST:event_helpLicenseMenuItemActionPerformed

    private void toolsOptionsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_toolsOptionsMenuItemActionPerformed
        if (optDialog == null) {
            optDialog = new OptionsDialog(this);
        }
        
        if (optDialog.showDialog()) {
            UserProfileManager.saveProfiles();
            int lafIndex = optDialog.getLAFIndex();
            LAFManager.setLAF(lafIndex);
            SwingUtilities.updateComponentTreeUI(this);
            if (optDialog != null) {
                SwingUtilities.updateComponentTreeUI(optDialog);
            }
            SwingUtilities.updateComponentTreeUI(friendsMenu);
            SwingUtilities.updateComponentTreeUI(communitiesMenu);
            SwingUtilities.updateComponentTreeUI(tagsMenu);
            SwingUtilities.updateComponentTreeUI(ljcutPopupMenu);

        }
    }//GEN-LAST:event_toolsOptionsMenuItemActionPerformed

    private void onExit() {
        closeAllChildWindows();
        Options.saveMainFrameBounds(this);
        System.exit(0);
    }
    
    private void fileExitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileExitMenuItemActionPerformed
        onExit();
    }//GEN-LAST:event_fileExitMenuItemActionPerformed
        
    private void fileConnectMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileConnectMenuItemActionPerformed
        LoginDialog dialog = new LoginDialog(this);
        if (dialog.showDialog()) {
            loginName = dialog.getLogin();
            passwd = dialog.getPassword();
            storePasswd = dialog.getStorePasswd();
            
            prof = UserProfileManager.getProfile(loginName);
            if (prof != null) {
                UserProfileManager.setCurrentProfile(prof);
                
                if (prof.getStorePasswd()) {
                    String stored = prof.getHPasswd();
                    if (!stored.equals(passwd)) {
                        /* User entered password manually */
                        passwd = MD5.encode(passwd);
                    }
                } else {
                    passwd = MD5.encode(passwd);
                }
            } else {
                /* No loaded password anyway so encode */
                passwd = MD5.encode(passwd);
            }
                        
            if (passwd != null) {
                Thread thread = new Thread() {    
                    public void run() {
                        pDial.asyncShowDialog();
                        
                        
                        int maxMoodID = 0;
                        if (prof != null) {
                            pDial.setMessage("Load stored moods...");
                            Options.loadMoods(m_account.getMoods(), pDial);
                            maxMoodID = Options.getMaxMoodID();
                        }
                    
                        try {
                            pDial.setMessage("Sending request...");
                            pDial.setIndeterminate(true);
                            LJRawResult data = m_account.login(loginName, passwd, true, maxMoodID);
                            pDial.setIndeterminate(false);
                    
                            /* If we are here than success
                             * let's create a new profile if needed
                             */
                            if (prof == null) {
                                prof = new UserProfile();
                                prof.setUserName(loginName);

                                UserProfileManager.addProfile(prof);
                                UserProfileManager.setCurrentProfile(prof);
                            }

                            /* Update profile password as appropriate */
                            prof.setStorePasswd(storePasswd);
                            if (storePasswd) {
                                prof.setHPasswd(passwd);
                            } else {
                                prof.setHPasswd("");
                            }
                    
                            setTitle("LiveJournal - " + m_account.getFullName());

                            pDial.setMessage("Loading friends...");
                            Options.loadFriends(m_account.getFriendList());

                            pDial.setMessage("Loading userpics...");
                            IconManager.loadUserpics(m_account, pDial);
                            
                            pDial.setMessage("Loading tags...");
                            m_tags = m_account.getUserTags();
                            if (Options.loadUserTags(m_tags) == 0) {
                                m_tags = m_account.loadUserTags(pDial);
                                Options.saveUserTags(m_tags);                                
                            }
                            buildTagsMenu(m_tags);

                            Options.saveMoods(m_account.getMoods());                    
                            UserProfileManager.saveProfiles();

                            setConnected(true);
                            
                            SwingUtilities.invokeAndWait(new Runnable() {
                                public void run() {
                                    createFriendMenu();
                                    updateMenuItems();
                                    onNewPost();
                                }
                            });
                        }
                        catch (Exception e) {
                            UserProfileManager.setCurrentProfile(null);
                            handleException(e);
                        }
                        finally {
                            /* Thread ended, release UI */
                            pDial.asyncCloseDialog();
                        }                        
                    }
                };
    
                pDial = new ProgressDialog(this);
                thread.start();                
            }
        }        
    }//GEN-LAST:event_fileConnectMenuItemActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* testing */
//        String home = System.getProperty("user.home");
        
        Options.load();
        Options.setLocale();
        
        String lafClass = Options.getLAFClass();
        LAFManager.setLAF(lafClass);
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LJMainFrame().setVisible(true);
            }
        });
    }
    
    public void handleException(Exception e) {
        String msg = e.getMessage();
        String title = "Unknown Exception";
        
        if (e instanceof LJProgrammingException) {
            title = "Programming Error";
        }
        
        if (e instanceof LJJournalException) {
            title = "Journal Error";
        }
        
        if (e instanceof java.io.IOException) {
            title = "Input/Output Exception";
        }
        
        if (e instanceof java.net.MalformedURLException) {
            title = "Bad URL";
        }
        
        JOptionPane.showMessageDialog(this, msg, title, JOptionPane.ERROR_MESSAGE);
        
    }
    
    private void openAccountLink(String suffix) {
        UserProfile prof = UserProfileManager.getCurrentProfile();
        if (prof != null) {
            // TODO: Use some option from the API instead of hardcoded address
            StringBuilder b = new StringBuilder("http://www.livejournal.com/users/");
            b.append(prof.getUserName());
            b.append("/");
            b.append(suffix);
            Utils.runBrowser(b.toString());
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem accountFriendsMenuItem;
    private javax.swing.JMenu accountMenu;
    private javax.swing.JMenuItem addFriendMenuItem;
    private javax.swing.JMenuItem boldMenuItem;
    private javax.swing.JMenuItem calendarMenuItem;
    private javax.swing.JMenuItem communityMenuItem;
    private javax.swing.JMenuItem consoleMenuItem;
    private javax.swing.JMenuItem copyrightSymbolMenuItem;
    private javax.swing.JMenuItem decreaseFontMenuItem;
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenuItem editLastEntryMenuItem;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem englishQuotesMenuItem;
    private javax.swing.JMenuItem englishSingleQuotesMenuItem;
    private javax.swing.JMenuItem fileConnectMenuItem;
    private javax.swing.JMenuItem fileDisconnectMenuItem;
    private javax.swing.JMenuItem fileExitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenuItem fileNewPostMenuItem;
    private javax.swing.JMenu formatMenu;
    private javax.swing.JMenuItem frenchQuotesMenuItem;
    private javax.swing.JMenuItem friendsMenuItem;
    private javax.swing.JMenuItem hellipSymbolMenuItem;
    private javax.swing.JMenuItem helpAboutMenuItem;
    private javax.swing.JMenuItem helpLicenseMenuItem;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuItem historyMenuItem;
    private javax.swing.JMenuItem homePageMenuItem;
    private javax.swing.JMenuItem increaseFontMenuItem;
    private javax.swing.JMenuItem insertAdvUserReferenceMenuItem;
    private javax.swing.JMenuItem insertImageReferenceMenuItem;
    private javax.swing.JMenuItem insertReferenceMenuItem;
    private javax.swing.JMenuItem italicsMenuItem;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JMenuItem ljcutCloseMenuItem;
    private javax.swing.JMenuItem ljcutOpenMenuItem;
    private javax.swing.JPopupMenu ljcutPopupMenu;
    private javax.swing.JMenuItem ljcutSurroundMenuItem;
    private javax.swing.JMenuItem ljcutWithTextMenuItem;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JMenu quotesSubMenu;
    private javax.swing.JMenuItem recentEntriesMenuItem;
    private javax.swing.JMenuItem russianQuotesMenuItem;
    private javax.swing.JMenuItem saveAsMenuItem;
    private javax.swing.JMenuItem saveMenuItem;
    private javax.swing.JMenuItem strikeMenuItem;
    private javax.swing.JMenu symbolsSubMenu;
    private javax.swing.JToolBar toolBar;
    private javax.swing.JMenu toolsMenu;
    private javax.swing.JMenuItem toolsOptionsMenuItem;
    private javax.swing.JMenuItem tradeSymbolMenuItem;
    private javax.swing.JMenuItem underscoreMenuItem;
    private javax.swing.JMenu webSubMenu;
    private javax.swing.JMenuItem windowCloseMenuItem;
    private javax.swing.JSeparator windowListSeparator;
    private javax.swing.JMenu windowMenu;
    // End of variables declaration//GEN-END:variables

    private PostWindow getCurrentPostWindow() {
        JInternalFrame frame = desktopPane.getSelectedFrame();
        
        if ((frame != null) && (frame instanceof PostWindow) && frame.isVisible())
            return (PostWindow)frame;
        else
            return null;        
    }
    
    private void onFriendsMenuItemSelected(String name) {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onInsertFriend(name);
        }
    }
    
    private void onTagsMenuItemSelected(String name) {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onInsertTag(name);
        }
    }
    
    private void onCommunityMenuItemSelected(String name) {
        PostWindow wnd = getCurrentPostWindow();
        if (wnd != null) {
            wnd.onInsertCommunity(name);
        }
    }
    
    public void loadUserTags(LJProgressCallback ph) throws LJException {
        ArrayList<LJTag> tags = m_account.loadUserTags(ph);
        buildTagsMenu(tags);
        Options.saveUserTags(tags);
    }
    
    public void buildTagsMenu(ArrayList<LJTag> tags) throws LJException {
        // build menu
        tagsMenu.removeAll();
        
        String lastLtr = "";
        JMenu menu = null;
        JMenuItem lastItem = null;
                
        for (LJTag t : tags) {
            /* Just in case */
            if (t.getName().length() == 0) {
                continue;
            }
            
            int index;
            
            JMenuItem item = new JMenuItem(t.getName());
            item.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    onTagsMenuItemSelected(e.getActionCommand());
                }                
            });
            
            String ltr = t.getName().substring(0, 1);
            
            if (ltr.equals(lastLtr)) {
                if (lastItem != null) {
                    menu = new JMenu(ltr);
                    tagsMenu.remove(lastItem);
                    tagsMenu.add(menu);
                    menu.add(lastItem);
                    lastItem = null;
                }
                
                menu.add(item);
                
            } else {
                lastItem = item;
                lastLtr = ltr;
                tagsMenu.add(item);
            }
        }            
        
        tagsMenu.setEnabled(true);        
    }

    private void onSaveAs() {
        PostWindow pw = getCurrentPostWindow();
        if (pw != null) {
            pw.onSaveAs();
        }
    }

    private void onSave() {
        PostWindow pw = getCurrentPostWindow();
        if (pw != null) {
            pw.onSave();
        }
    }

    private void onOpen() {
        try {
            JFileChooser dial = new JFileChooser();
            dial.addChoosableFileFilter(new XMLFileFilter());
            dial.setAcceptAllFileFilterUsed(false);
            
            if (dial.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                File f = dial.getSelectedFile();
                javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                org.w3c.dom.Document doc = builder.parse(f);
                
                LJEvent event = new LJEvent();
                event.fromXML(doc);
                
                openPostWindow(event);
            }
        }
        catch (Exception e) {
            handleException(e);
        }
    }
    
    public void createFriendMenu() {
        friendsMenu.removeAll();
        communitiesMenu.removeAll();
        
        ArrayList<LJFriend> friends = m_account.getFriendList().getFriendArrayClone();
        Collections.sort(friends, new LJFriendAlphabeticalComparator());
        
        String[] lastLtr = new String[] {"", ""};        
        JMenu[] menu = new JMenu[2];
        JMenuItem[] lastItem = new JMenuItem[2];
        JMenu targetMenu;
                
        for (LJFriend f : friends) {
            int index;
            
            JMenuItem item = new JMenuItem(f.getUserName());
            
            if (f.isCommunity()) {
                index = 1;
                item.setIcon(IconManager.getIcon(IconManager.COMMUNITY_ICON));
                item.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        onCommunityMenuItemSelected(e.getActionCommand());
                    }                
                });
                targetMenu = communitiesMenu;
            } else {
                index = 0;
                item.setIcon(IconManager.getIcon(IconManager.FRIEND_HEAD_ICON));
                item.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        onFriendsMenuItemSelected(e.getActionCommand());
                    }                
                });
                targetMenu = friendsMenu;
            }
            
            
            String ltr = f.getUserName().substring(0, 1);
            
            if (ltr.equals(lastLtr[index])) {
                if (lastItem[index] != null) {
                    menu[index] = new JMenu(ltr);
                    targetMenu.remove(lastItem[index]);
                    targetMenu.add(menu[index]);
                    menu[index].add(lastItem[index]);
                    lastItem[index] = null;
                }
                
                menu[index].add(item);
                
            } else {
                lastItem[index] = item;
                lastLtr[index] = ltr;
                targetMenu.add(item);
            }
        }            
            
            
        
        friendsMenu.setEnabled(true);
        communitiesMenu.setEnabled(true);
    }
    
    public void handleEvent(ApplicationInternalEvent event) {
        
    }

    public static JMenu getFriendsMenu() { return friendsMenu; }
    public static JMenu getCommunitiesMenu() { return communitiesMenu; }
    public static JMenu getTagsMenu() { return tagsMenu; }
    
    /* Controls created manually */    
    private JButton insertFriendToolbarButton;
    /*****************************/
    /* Actions */
    private AbstractAction addFriendAction;
    private AbstractAction openFriendsWindowAction;
    private AbstractAction newPostAction;
    private AbstractAction editLastPostAction;
    private AbstractAction underscoreAction;
    private AbstractAction strikeAction;
    private AbstractAction boldAction;
    private AbstractAction italicsAction;
    private AbstractAction aboutAction;
    private AbstractAction insertFriendAction;
    private AbstractAction friendsMenuAction;
    private AbstractAction insertCommunityAction;
    private AbstractAction communitiesMenuAction;
    private AbstractAction consoleAction;
    private AbstractAction ljCutAction;
    private AbstractAction ljCutMenuAction;
    private AbstractAction editInsertReferenceAction;
    private AbstractAction historyWindowAction;
    private AbstractAction fontIncreaseAction;
    private AbstractAction fontDecreaseAction;
    private AbstractAction saveAction;
    private AbstractAction saveAsAction;
    private AbstractAction openAction;
    
    static {
        friendsMenu = new JMenu();
        communitiesMenu = new JMenu();
        tagsMenu = new JMenu();
    }
    
}
