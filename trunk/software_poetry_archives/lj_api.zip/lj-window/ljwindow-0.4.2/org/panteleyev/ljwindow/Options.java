/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.prefs.*;
import javax.swing.*;
import org.panteleyev.ljapi.*;
import org.panteleyev.tools.*;

final class Options {
    private static final String ROOT            = "/org/panteleyev/ljwindow";
    private static final String FRIENDS         = "friends";
    private static final String PROFILES        = "profiles";
    private static final String USERPICS        = "userpics";
    private static final String MOODS           = "moods";
    private static final String TAGS            = "tags";
    
    private static final String PROXY_SERVER_PREF       = "proxy_server";
    private static final String PROXY_PORT_PREF         = "proxy_port";
    private static final String PROXY_ENABLED_PREF      = "proxy_enabled";
    private static final String PROXY_USER_PREF         = "proxy_user";
    private static final String PROXY_AUTH_PREF         = "proxy_auth";
    private static final String PROXY_PASSWD_PREF       = "proxy_passwd";    
    private static final String STORE_CREDENTIALS_PREF  = "store_credentials";
    private static final String AUTOLOGIN_PREF          = "auto_login";
    private static final String USERNAME_PREF           = "user_name";
    private static final String PASSWORD_PREF           = "password";
    private static final String LAF_CLASS_PREF          = "laf_class";
    private static final String BROWSER_PREF            = "external_browser_command";
    private static final String LOCALE_PREF             = "locale";
    private static final String FRIEND_SORT_COLUMN      = "friend_sort_column";
    private static final String FRIEND_SORT_ORDER       = "friend_sort_order";
    private static final String EXTERNAL_PREVIEW_PREF   = "external_preview";
    
    private static Preferences root = null;
    private static Preferences node = null;
    private static Preferences moodsNode = null;
    private static Preferences friendsNode = null;
    private static Preferences profilesNode = null;
    private static Preferences userpicsNode = null;
    private static Preferences tagsNode = null;
    
    /* Global options */
    
    private static String proxyServer;
    private static int proxyPort;
    private static String proxyUserName;
    private static String proxyPasswd;
    private static boolean proxyEnabled;
    private static boolean proxyAuth;
    private static boolean storeCredentials;
    private static boolean autoLogin;
    private static String userName;
    private static String password;
    private static String externalBrowserCommand;
    private static int localeIndex;
    private static String lafClass;
    private static boolean useExternalPreview;
    
    /* Main frame dimensions */
    private static int mFrameX;
    private static int mFrameY;
    private static int mFrameW;
    private static int mFrameH;
    
    private static ResourceBundle bundle;
    
    private static String[] langs = {"", "en", "ru"};
    
    private static int friendSortColumn;
    private static int friendSortOrder;
    
    /* Getters */
    public static String getProxyServer() { return proxyServer; }
    public static int getProxyPort() { return proxyPort; }
    public static boolean isProxyEnabled() { return proxyEnabled; }
    public static boolean getProxyAuth() { return proxyAuth; }
    public static String getProxyUser() { return proxyUserName; }
    public static String getProxyPasswd() { return proxyPasswd; }
    public static boolean isStoreCredentialsEnabled() { return storeCredentials; }
    public static boolean isAutologinEnabled() { return autoLogin; }
    public static String getUserName() { return userName; }
    public static String getPassword() { return password; }
    public static ResourceBundle getResourceBundle() { return bundle; }
    public static String getExternalBrowserCommand() { return externalBrowserCommand; }    
    public static int getFriendSortColumn() { return friendSortColumn; }
    public static int getFriendSortOrder() { return friendSortOrder; }
    public static String getLAFClass() { return lafClass; }
    public static boolean getUseExternalPreview() { return useExternalPreview; }
    
    
    /* Setters */    
    public static void setExternalBrowserCommand(String cmd) {
        externalBrowserCommand = cmd;
        node.put(BROWSER_PREF, cmd);
    }
    
    public static void setProxyServer(String addr) {
        proxyServer = addr;
        node.put(PROXY_SERVER_PREF, proxyServer);
    }
    
    public static void setProxyPort(int port) {
        proxyPort = port;
        node.putInt(PROXY_PORT_PREF, proxyPort);
    }
    
    public static void setProxyUser(String name) {
        proxyUserName = name;
        node.put(PROXY_USER_PREF, proxyUserName);
    }

    public static void setProxyPasswd(String passwd) {
        proxyPasswd = passwd;
        node.put(PROXY_PASSWD_PREF, proxyPasswd);
    }
    
    public static void setProxyEnabled(boolean enabled) {
        proxyEnabled = enabled;
        node.putBoolean(PROXY_ENABLED_PREF, proxyEnabled);
    }
    
    public static void setProxyAuth(boolean auth) {
        proxyAuth = auth;
        node.putBoolean(PROXY_AUTH_PREF, proxyAuth);
    }
    
    public static void setStoreCredentialsEnabled(boolean enabled) {
        storeCredentials = enabled;
        node.putBoolean(STORE_CREDENTIALS_PREF, storeCredentials);
    }
    
    public static void setLAFClass(int index) {
        String className = LAFManager.getClassName(index);
        if (className != null) {
            node.put(LAF_CLASS_PREF, className);
            lafClass = className;
        }
    }
    
    public static void setFriendSortColumn(int column) {
        friendSortColumn = column;
        node.putInt(FRIEND_SORT_COLUMN, friendSortColumn);
    }
    
    public static void setFriendSortOrder(int order) {
        friendSortOrder = order;
        node.putInt(FRIEND_SORT_ORDER, friendSortOrder);
    }
    
    public static void setUseExternalPreview(boolean use) {
        useExternalPreview = use;
        node.putBoolean(EXTERNAL_PREVIEW_PREF, useExternalPreview);
    }
    
    
    public static void setSystemProxySettings() {        
        if (proxyEnabled) {
            System.setProperty("http.proxyHost", proxyServer);
            System.setProperty("http.proxyPort", Integer.toString(proxyPort));
            if (proxyAuth) {
                System.setProperty("http.proxyUserName", proxyUserName);
                System.setProperty("http.proxyPassword", proxyPasswd);
            } else {
                System.clearProperty("http.proxyUserName");
                System.clearProperty("http.proxyPassword");
            }
        } else {
            System.clearProperty("http.proxyHost");
        }
    }
    
    public static void setAutologinEnabled(boolean enabled) {
        autoLogin = enabled;
        node.putBoolean(AUTOLOGIN_PREF, autoLogin);
    }
    
    public static void setUserName(String uName) {
        userName = uName;
        node.put(USERNAME_PREF, userName);  
    }
    
    public static void setPassword(String passwd) {
        password = passwd;
        node.put(PASSWORD_PREF, password);
    }
        
    public static void storeFriends(LJFriendList fList) {
        UserProfile prof = UserProfileManager.getCurrentProfile();
        if ((prof == null) || (!prof.getCacheFriends())) {
            return;
        }
        
        ArrayList<LJFriend> friends = fList.getFriendArray();
        
        Preferences fNode = friendsNode.node(prof.getUserName());
        
        try {
            fNode.removeNode();
        }
        catch (Exception e) {
        }
         
        fNode = friendsNode.node(prof.getUserName());
        
        fNode.putInt("total_count", friends.size());
                
        for (int i = 0; i < friends.size(); i++) {
            Preferences fn = fNode.node(Integer.toString(i));
            LJFriend f = friends.get(i);
            
            fn.put("username", f.getUserName());
            fn.put("fullname", f.getFullName());
            fn.putInt("groupmask", f.getGroupMask());
            fn.putInt("relation", f.getRelation());
            fn.putInt("type", f.getType());
            fn.putInt("status", f.getStatus());
            fn.putInt("bg", f.getBg());
            fn.putInt("fg", f.getFg());
            fn.put("birthday", f.getBirthday());
        }
        
        try {
            fNode.flush();
        }
        catch (Exception e) {            
        }        
    }

    public static void loadFriends(LJFriendList fList) {
        UserProfile prof = UserProfileManager.getCurrentProfile();
        if ((prof == null) || (!prof.getCacheFriends())) {
            return;
        }

        fList.clear();

        Preferences fNode = friendsNode.node(prof.getUserName());
        
        int total_count = fNode.getInt("total_count", 0);
   
        for (int i = 0; i < total_count; i++) {
            Preferences fn = fNode.node(Integer.toString(i));
            
            String username = fn.get("username", "");
            if (username.length() != 0) {
                LJFriend f = new LJFriend(username);
                
                f.setFullName(fn.get("fullname", ""));
                f.setGroupMask(fn.getInt("groupmask", 0));
                f.setRelation(fn.getInt("relation", LJFriend.RELATION_FRIEND));
                f.setType(fn.getInt("type", 0));
                f.setStatus(fn.getInt("status", 0));
                f.setBg(fn.getInt("bg", 0xFFFFFF));
                f.setFg(fn.getInt("fg", 0));
                f.setBirthday(fn.get("birthday", ""));            
                fList.restoreFriend(f);
            }
            
        }
    }
               
    public static void storeUserpic(String key, URL url, java.awt.image.BufferedImage bim) {
        UserProfile prof = UserProfileManager.getCurrentProfile();
        if ((prof == null) || (!prof.getCacheUserpics())) {
            return;
        }

        Preferences fNode = userpicsNode.node(prof.getUserName());        
        
        ByteArrayOutputStream bas = new ByteArrayOutputStream();
        try {
            if (!javax.imageio.ImageIO.write(bim, "png", bas)) {
                return;
            }
            byte[] data = bas.toByteArray();
            Preferences pn = fNode.node(key);
            pn.put("url", url.toString());
            
            int length = data.length;
            pn.putInt("length", length);
            
            int chunkLength = Preferences.MAX_VALUE_LENGTH * 3 / 4 - 1;
            byte[] buf = new byte[chunkLength];
            
            int fullChunks = length / chunkLength;
            
            int pos = 0;
            int index;
            for (index = 0; index < fullChunks; index++) {
                System.arraycopy(data, pos, buf, 0, chunkLength);
                pn.putByteArray("bytes" + Integer.toString(index), buf);
                pos += chunkLength;
            }
            int rest = length - pos;
            if (rest != 0) {
                buf = new byte[rest];
                System.arraycopy(data, pos, buf, 0, rest);
                pn.putByteArray("bytes" + Integer.toString(index), buf);
                fullChunks += 1;
            }
            pn.putInt("chunks", fullChunks);
        }
        catch (Exception e) {
            
        }
    }

    public static LJUserpic loadUserpic(String key, URL url) {
        UserProfile prof = UserProfileManager.getCurrentProfile();
        if ((prof == null) || (!prof.getCacheUserpics())) {
            return null;
        }

        Preferences fNode = userpicsNode.node(prof.getUserName());
        Preferences pn = fNode.node(key);
        
        String u = pn.get("url", "");
        if (!u.equals(url.toString())) {
            return null;
        }
        
        int length = pn.getInt("length", 0);
        if (length == 0) {
            return null;
        }
        
        int chunks = pn.getInt("chunks", 0);
        if (chunks == 0) {
            return null;
        }
        
        byte[] data = new byte[length];
        
        int pos = 0;
        for (int index = 0; index < chunks; index++) {
            byte[] buf = pn.getByteArray("bytes" + Integer.toString(index), null);
            if (buf == null) {
                return null;
            }
            System.arraycopy(buf, 0, data, pos, buf.length);
            pos += buf.length;
        }
        
        return new LJUserpic(data, url.toString());
    }

    public static void saveUserTags(ArrayList<LJTag> tags) {
        int count = tags.size();
        Preferences node = tagsNode.node(UserProfileManager.getCurrentProfile().getUserName());
        
        node.putInt("count", count);
        for (int i = 0; i < count; i++) {
            String suff = Integer.toString(i);
            LJTag t = tags.get(i);
            node.put("name" + suff, t.getName());
        }
    }
    
    public static int loadUserTags(ArrayList<LJTag> tags) {
        tags.clear();
        Preferences node = tagsNode.node(UserProfileManager.getCurrentProfile().getUserName());
        
        int count = node.getInt("count", 0);
        for (int i = 0; i < count; i++) {
            String suff = Integer.toString(i);
            String name = node.get("name" + suff, null);
            if (name != null) {
                tags.add(new LJTag(name));
            }
        }
        
        return count;
    }
    
    public static void saveMoods(ArrayList<LJMood> moods) {
        int count = moods.size();
        Preferences moodNode = moodsNode.node(UserProfileManager.getCurrentProfile().getUserName());
        
        moodNode.putInt("count", count);
        LJMood mood = null;
        for (int i = 0; i < count; i++) {
            String suff = Integer.toString(i);
            mood = moods.get(i);
            moodNode.putInt("id" + suff, mood.getID());
            moodNode.put("name" + suff, mood.getName());            
        }
        
        moodNode.putInt("max_id", (mood == null)? 0 : mood.getID());
    }
    
    public static void loadMoods(ArrayList<LJMood> moods, LJProgressCallback ph) {
        moods.clear();
        Preferences moodNode = moodsNode.node(UserProfileManager.getCurrentProfile().getUserName());
        
        int count = moodNode.getInt("count", 0);
        moods.ensureCapacity(count);
        ph.setMinimum(0);
        ph.setMaximum(count);
        for (int i = 0; i < count; i++) {
            String suff = Integer.toString(i);
            int id = moodNode.getInt("id" + suff, 0);
            String name = moodNode.get("name" + suff, "");
            
            moods.add(new LJMood(id, name));
            ph.setValue(i);
        }
    }
    
    public static void setLocale() {
        if ((localeIndex > 0) && (localeIndex < langs.length)) {
            Locale.setDefault(new Locale(langs[localeIndex]));
        }
        
        bundle = ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization");        
    }
    
    public static int getLocaleIndex() {
        return localeIndex;
    }
    
    public static void setLocaleIndex(int index) {
        localeIndex = index;
        node.putInt(LOCALE_PREF, localeIndex);
    }

    public static void load() {
        friendsNode = node.node(FRIENDS);
        
        proxyServer = node.get(PROXY_SERVER_PREF, "");
        proxyPort = node.getInt(PROXY_PORT_PREF, 0);
        proxyEnabled = node.getBoolean(PROXY_ENABLED_PREF, false);
        proxyAuth = node.getBoolean(PROXY_AUTH_PREF, false);
        proxyUserName = node.get(PROXY_USER_PREF, "");
        proxyPasswd = node.get(PROXY_PASSWD_PREF, "");
        storeCredentials = node.getBoolean(STORE_CREDENTIALS_PREF, false);
        autoLogin = node.getBoolean(AUTOLOGIN_PREF, false);
        userName = node.get(USERNAME_PREF, "");
        password = node.get(PASSWORD_PREF, "");
        externalBrowserCommand = node.get(BROWSER_PREF, "");        
        lafClass = node.get(LAF_CLASS_PREF, "");
        friendSortColumn = node.getInt(FRIEND_SORT_COLUMN, 0);
        friendSortOrder = node.getInt(FRIEND_SORT_ORDER, 1);
        useExternalPreview = node.getBoolean(EXTERNAL_PREVIEW_PREF, false);
        
        localeIndex = node.getInt(LOCALE_PREF, 0);
        if ((localeIndex < 0) || (localeIndex >= langs.length)) {
            setLocaleIndex(0);
        }
    }
    
    public static void saveBounds(java.awt.Component w) {
        String name = w.getClass().getName();
        
        node.putInt(name + "_x", w.getX());
        node.putInt(name + "_y", w.getY());
        node.putInt(name + "_w", w.getWidth());
        node.putInt(name + "_h", w.getHeight());        
    }
    
    public static void saveMainFrameBounds(JFrame f) {
        String name = f.getClass().getName();
        int state = f.getExtendedState();
        boolean maximized = (state & java.awt.Frame.MAXIMIZED_BOTH) != 0;
        node.putBoolean(name + "_max", maximized);
        if (!maximized) {
            saveBounds(f);
        }
    }
    
    public static void loadMainFrameBounds(JFrame f) {
        String name = f.getClass().getName();
        boolean maximized = node.getBoolean(name + "_max", false);
        loadBounds(f);
        if (maximized) {
            f.setExtendedState(f.getExtendedState() | java.awt.Frame.MAXIMIZED_BOTH);
        }
    }
    
    public static void loadBounds(java.awt.Component win) {
        String name = win.getClass().getName();
        
        int x = node.getInt(name + "_x", 10);
        int y = node.getInt(name + "_y", 10);
        int w = node.getInt(name + "_w", 700);
        int h = node.getInt(name + "_h", 500);
        
        win.setBounds(x, y, w, h);        
    }
    
    public static int getMaxMoodID() {
        Preferences moodNode = moodsNode.node(UserProfileManager.getCurrentProfile().getUserName());
        return moodNode.getInt("max_id", 0);
    }
    
    public static void deleteCachedData(String profName) {
        Preferences rNode = null;
        
        try {
            rNode = friendsNode.node(profName);
            rNode.removeNode();
        }
        catch (Exception e) {}

        try {
            rNode = moodsNode.node(profName);
            rNode.removeNode();
        }
        catch (Exception e) {}
            
        try {
            rNode = userpicsNode.node(profName);
            rNode.removeNode();
        }
        catch (Exception e) {}
        
        try {
            rNode = tagsNode.node(profName);
            rNode.removeNode();
        }
        catch (Exception e) {}
        
    }
    
    static {
        root = Preferences.userRoot();
        node = root.node(ROOT);
        moodsNode = node.node(MOODS);
        profilesNode = node.node(PROFILES);
        userpicsNode = node.node(USERPICS);
        tagsNode = node.node(TAGS);        
    }
}
