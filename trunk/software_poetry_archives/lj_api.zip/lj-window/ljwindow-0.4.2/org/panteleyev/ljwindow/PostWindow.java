/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import java.util.*;
import javax.swing.*;
import javax.swing.text.*;
import java.io.*;
import org.w3c.dom.*;
import org.panteleyev.ljapi.*;
import org.panteleyev.tools.*;

public class PostWindow extends MDIChildWindow {
    private LJAccount m_account;
    private DefaultComboBoxModel userpicDropDownModel;
    private SimpleComboBoxModel moodDropDownModel;
    private LJEvent m_post;
    
    private static String[] securityTypes;
    private static String[] screenTypes;
    private boolean internalAccessChange;
    
    private InsertReferenceDialog m_refDialog;
    private AdvancedUserReferenceDialog m_userRefDialog;
    private ImageReferenceDialog m_imageRefDialog;
    
    private JTextComponent m_focusedText;
    
    private File m_saveAsFile;
    
    /* Variables for separate thread */
    ProgressDialog m_progressDialog = null;
    /**********************************/
    
    /** Creates new form PostWindow */
    public PostWindow(JFrame mainFrame, LJAccount account, LJEvent post) {
        super(mainFrame);
        
        this.m_account = account;
        
        m_post = (post == null)? new LJEvent() : post;
        initComponents();
        
        createListModels();

        if ((post == null) || (post.getUserpic() == null)) {
            userpicDropDownActionPerformed(null);
        } else {
            this.userpicDropDown.setSelectedItem(post.getUserpic());
        }
        
        setupAccessLevelComboBox();
        timeSpinner.setModel(new SpinnerDateModel());
        
        subjectEdit.setText(m_post.getSubject());
        plainEditor.setText(m_post.getBody());
        tagsEdit.setText(m_post.getTagList());
        musicEdit.setText(m_post.getMusic());
        locationEdit.setText(m_post.getLocation());
        
        moodDropDown.setSelectedIndex(m_post.getMoodID());
        if (m_post.getMoodText() != null) {
            moodDropDown.setSelectedItem(m_post.getMoodText());
        }
        
        noCommentsCheck.setSelected(m_post.getNoComments());
        noAutoFormatCheck.setSelected(m_post.getNoAutoFormat());
        noEmailCheck.setSelected(m_post.getNoEmail());
        backdateCheck.setSelected(m_post.getBackdate());
        
        timeSpinner.setValue(m_post.getDate());
        if (post != null) {
            manualDateCheck.setSelected(true);
            timeSpinner.setEnabled(true);
        }
        
        sharedJournalsComboBox.setModel(new DefaultComboBoxModel(new Vector(account.getSharedJournals())));
        if (post != null) {
            sharedJournalsComboBox.setSelectedItem(post.getJournal());
        }
        
        idStatusField.setText(Integer.toString(m_post.getID()));
        
        String title;
        if (m_post.getID() != -1) {
            sharedJournalsComboBox.setEnabled(false);
            postToManyMenuItem.setEnabled(false);
            title = Options.getResourceBundle().getString("postwindow_TitleEditPost");            
        } else {
            postToManyMenuItem.setEnabled(true);
            deleteButton.setVisible(false);
            title = Options.getResourceBundle().getString("postwindow_TitleNewPost");
            setFrameIcon(IconManager.getIcon(IconManager.NEW_POST));
        }                
        setTitle(title);
        
        screenComboBox.setSelectedIndex(m_post.getScreeningType());
        // TODO: The rest!!
        
    }
    
    private void createListModels() {
        userpicDropDownModel = new SimpleComboBoxModel(new Vector(this.m_account.getUserpicKeys()));
        userpicDropDown.setModel(userpicDropDownModel);
        
        moodDropDownModel = new SimpleComboBoxModel() {
            public int getSize() { return m_account.getMoods().size(); }
            public Object getElementAt(int index) { return m_account.getMoods().get(index).getName(); }            
        };        
        moodDropDown.setModel(moodDropDownModel);
        
        accessComboBox.setModel(new DefaultComboBoxModel(securityTypes));
        screenComboBox.setModel(new DefaultComboBoxModel(screenTypes));        
    }
    
    public int getPostID() { return (m_post == null)? -1 : m_post.getID(); }
    public String getUseJournal() { return (m_post == null)? null : m_post.getJournal(); }
       
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        postPopupMenu = new javax.swing.JPopupMenu();
        postAndContinueMenuItem = new javax.swing.JMenuItem();
        postToManyMenuItem = new javax.swing.JMenuItem();
        editTab = new javax.swing.JPanel();
        subjectPanel = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        subjectEdit = new javax.swing.JTextField();
        postButtonAndContinue = new javax.swing.JButton();
        sharedJournalsComboBox = new javax.swing.JComboBox();
        deleteButton = new javax.swing.JButton();
        previewButton = new javax.swing.JButton();
        postMenuButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        plainEditor = new javax.swing.JEditorPane();
        optionsPanel = new javax.swing.JPanel();
        userpicPanel = new javax.swing.JPanel();
        userpicShowLabel = new javax.swing.JLabel();
        userpicDropDown = new javax.swing.JComboBox();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        attributesPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        moodDropDown = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        musicEdit = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        locationEdit = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tagsEdit = new javax.swing.JTextField();
        tagsButton = new javax.swing.JButton();
        tagsUpdateButton = new javax.swing.JButton();
        securityTab = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        accessComboBox = new javax.swing.JComboBox();
        screenComboBox = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        securityLevelButton = new javax.swing.JButton();
        optionsTab = new javax.swing.JPanel();
        noAutoFormatCheck = new javax.swing.JCheckBox();
        noCommentsCheck = new javax.swing.JCheckBox();
        noEmailCheck = new javax.swing.JCheckBox();
        backdateCheck = new javax.swing.JCheckBox();
        manualDateCheck = new javax.swing.JCheckBox();
        timeSpinner = new javax.swing.JSpinner();
        statusPanel = new javax.swing.JPanel();
        idStatusField = new javax.swing.JTextField();
        fileNameField = new javax.swing.JTextField();

        postAndContinueMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postAndContinueMenuItem"));
        postAndContinueMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                postAndContinueMenuItemActionPerformed(evt);
            }
        });

        postPopupMenu.add(postAndContinueMenuItem);

        postToManyMenuItem.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_postToManyMenuItem"));
        postToManyMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                postToManyMenuItemActionPerformed(evt);
            }
        });

        postPopupMenu.add(postToManyMenuItem);

        getContentPane().setLayout(new java.awt.GridBagLayout());

        setClosable(true);
        setResizable(true);
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameActivated(evt);
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameDeactivated(evt);
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        editTab.setLayout(new java.awt.GridBagLayout());

        subjectPanel.setLayout(new java.awt.GridBagLayout());

        jLabel4.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_Subject"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 0);
        subjectPanel.add(jLabel4, gridBagConstraints);

        subjectEdit.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                subjectEditFocusGained(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 3, 5, 0);
        subjectPanel.add(subjectEdit, gridBagConstraints);

        postButtonAndContinue.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_PostButton"));
        postButtonAndContinue.setFocusPainted(false);
        postButtonAndContinue.setFocusable(false);
        postButtonAndContinue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                postButtonAndContinueActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 0);
        subjectPanel.add(postButtonAndContinue, gridBagConstraints);

        sharedJournalsComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        sharedJournalsComboBox.setFocusable(false);
        sharedJournalsComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sharedJournalsComboBoxActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        subjectPanel.add(sharedJournalsComboBox, gridBagConstraints);

        deleteButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_deleteButton"));
        deleteButton.setFocusPainted(false);
        deleteButton.setFocusable(false);
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        subjectPanel.add(deleteButton, gridBagConstraints);

        previewButton.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postWindow_preview"));
        previewButton.setFocusPainted(false);
        previewButton.setFocusable(false);
        previewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previewButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        subjectPanel.add(previewButton, gridBagConstraints);

        postMenuButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/panteleyev/ljwindow/resources/down.gif")));
        postMenuButton.setFocusPainted(false);
        postMenuButton.setFocusable(false);
        postMenuButton.setIconTextGap(1);
        postMenuButton.setMargin(new java.awt.Insets(1, 1, 1, 1));
        postMenuButton.setMinimumSize(new java.awt.Dimension(11, 25));
        postMenuButton.setPreferredSize(new java.awt.Dimension(11, 25));
        postMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                postMenuButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.VERTICAL;
        gridBagConstraints.insets = new java.awt.Insets(5, 0, 5, 5);
        subjectPanel.add(postMenuButton, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        editTab.add(subjectPanel, gridBagConstraints);

        plainEditor.setEditorKit(new javax.swing.text.StyledEditorKit());
        plainEditor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                plainEditorFocusGained(evt);
            }
        });

        jScrollPane1.setViewportView(plainEditor);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        editTab.add(jScrollPane1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        getContentPane().add(editTab, gridBagConstraints);

        optionsPanel.setLayout(new java.awt.GridBagLayout());

        userpicPanel.setLayout(new java.awt.GridBagLayout());

        userpicShowLabel.setMaximumSize(new java.awt.Dimension(100, 100));
        userpicShowLabel.setMinimumSize(new java.awt.Dimension(100, 100));
        userpicShowLabel.setPreferredSize(new java.awt.Dimension(100, 100));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 5);
        userpicPanel.add(userpicShowLabel, gridBagConstraints);

        userpicDropDown.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        userpicDropDown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userpicDropDownActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 5, 5);
        userpicPanel.add(userpicDropDown, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 5, 5);
        optionsPanel.add(userpicPanel, gridBagConstraints);

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);
        attributesPanel.setLayout(new java.awt.GridBagLayout());

        jLabel1.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_Mood"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 0);
        attributesPanel.add(jLabel1, gridBagConstraints);

        moodDropDown.setEditable(true);
        moodDropDown.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 3, 0, 5);
        attributesPanel.add(moodDropDown, gridBagConstraints);

        jLabel2.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_Music"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 0);
        attributesPanel.add(jLabel2, gridBagConstraints);

        musicEdit.setColumns(15);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 0, 5);
        attributesPanel.add(musicEdit, gridBagConstraints);

        jLabel7.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_Location"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 0);
        attributesPanel.add(jLabel7, gridBagConstraints);

        locationEdit.setColumns(15);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 0, 5);
        attributesPanel.add(locationEdit, gridBagConstraints);

        jLabel8.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_Tags"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 5, 0);
        attributesPanel.add(jLabel8, gridBagConstraints);

        tagsEdit.setColumns(15);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 5, 3);
        attributesPanel.add(tagsEdit, gridBagConstraints);

        tagsButton.setText(">");
        tagsButton.setToolTipText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_SelectToolTip"));
        tagsButton.setFocusPainted(false);
        tagsButton.setFocusable(false);
        tagsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tagsButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 0, 5, 2);
        attributesPanel.add(tagsButton, gridBagConstraints);

        tagsUpdateButton.setText("*");
        tagsUpdateButton.setToolTipText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_UpdateToolTip"));
        tagsUpdateButton.setFocusPainted(false);
        tagsUpdateButton.setFocusable(false);
        tagsUpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tagsUpdateButtonActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.insets = new java.awt.Insets(3, 0, 5, 5);
        attributesPanel.add(tagsUpdateButton, gridBagConstraints);

        jTabbedPane1.addTab(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_Attributes"), attributesPanel);

        securityTab.setLayout(new java.awt.GridBagLayout());

        jLabel5.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_AccessLevel"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 0);
        securityTab.add(jLabel5, gridBagConstraints);

        accessComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        accessComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                accessComboBoxActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 2, 0, 5);
        securityTab.add(accessComboBox, gridBagConstraints);

        screenComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        screenComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                screenComboBoxActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 3, 5, 5);
        securityTab.add(screenComboBox, gridBagConstraints);

        jLabel6.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_ScreenComments"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 5, 0);
        securityTab.add(jLabel6, gridBagConstraints);

        securityLevelButton.setText("...");
        securityLevelButton.setFocusPainted(false);
        securityLevelButton.setFocusable(false);
        securityLevelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                securityLevelButtonActionPerformed(evt);
            }
        });

        securityTab.add(securityLevelButton, new java.awt.GridBagConstraints());

        jTabbedPane1.addTab(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_Security"), securityTab);

        optionsTab.setLayout(new java.awt.GridBagLayout());

        noAutoFormatCheck.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postWindow_noAutoFormatCheck"));
        noAutoFormatCheck.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        noAutoFormatCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
        noAutoFormatCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noAutoFormatCheckActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        optionsTab.add(noAutoFormatCheck, gridBagConstraints);

        noCommentsCheck.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postWindow_noCommentsCheck"));
        noCommentsCheck.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        noCommentsCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
        noCommentsCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noCommentsCheckActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        optionsTab.add(noCommentsCheck, gridBagConstraints);

        noEmailCheck.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postWindow_noEmailCheck"));
        noEmailCheck.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        noEmailCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
        noEmailCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noEmailCheckActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        optionsTab.add(noEmailCheck, gridBagConstraints);

        backdateCheck.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_BackdateEntry"));
        backdateCheck.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        backdateCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
        backdateCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backdateCheckActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        optionsTab.add(backdateCheck, gridBagConstraints);

        manualDateCheck.setText(java.util.ResourceBundle.getBundle("org/panteleyev/ljwindow/Localization").getString("postwindow_ManualDate"));
        manualDateCheck.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        manualDateCheck.setMargin(new java.awt.Insets(0, 0, 0, 0));
        manualDateCheck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                manualDateCheckActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 0, 5);
        optionsTab.add(manualDateCheck, gridBagConstraints);

        timeSpinner.setEnabled(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 0, 5);
        optionsTab.add(timeSpinner, gridBagConstraints);

        jTabbedPane1.addTab("Options", optionsTab);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        optionsPanel.add(jTabbedPane1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.weightx = 1.0;
        getContentPane().add(optionsPanel, gridBagConstraints);

        statusPanel.setLayout(new java.awt.GridBagLayout());

        statusPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        idStatusField.setColumns(5);
        idStatusField.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        statusPanel.add(idStatusField, gridBagConstraints);

        fileNameField.setEditable(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        statusPanel.add(fileNameField, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 1.0;
        getContentPane().add(statusPanel, gridBagConstraints);

        setBounds(0, 0, 779, 494);
    }// </editor-fold>//GEN-END:initComponents

    private void formInternalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameDeactivated
        ((LJMainFrame)getMainFrame()).postWindowActivated(false);
    }//GEN-LAST:event_formInternalFrameDeactivated

    private void formInternalFrameActivated(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameActivated
        ((LJMainFrame)getMainFrame()).postWindowActivated(true);
    }//GEN-LAST:event_formInternalFrameActivated

    private void postToManyMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_postToManyMenuItemActionPerformed
        SharedJournalSelectionDialog dial = new SharedJournalSelectionDialog(getMainFrame(), m_account.getSharedJournals());
        if (dial.showDialog()) {
            onPost(true, dial.getSelectedJournals());
        }
    }//GEN-LAST:event_postToManyMenuItemActionPerformed

    private void postAndContinueMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_postAndContinueMenuItemActionPerformed
        onPost(false, null);
    }//GEN-LAST:event_postAndContinueMenuItemActionPerformed

    private void postMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_postMenuButtonActionPerformed
        JButton btn = (JButton)evt.getSource();
        int x = btn.getX();
        int y = btn.getY() + btn.getHeight();
        postPopupMenu.show(subjectPanel, x, y);        
    }//GEN-LAST:event_postMenuButtonActionPerformed

    private void tagsUpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tagsUpdateButtonActionPerformed
        Thread thread = new Thread() {
            public void run() {
                m_progressDialog.asyncShowDialog();
                m_progressDialog.setMessage("Load tags...");
                try {
                    ((LJMainFrame)getMainFrame()).loadUserTags(m_progressDialog);
                }
                catch (LJException e) {
                    ((LJMainFrame)getMainFrame()).handleException(e);
                }
                finally {
                    m_progressDialog.asyncCloseDialog();
                }
            }
        };

        m_progressDialog = new ProgressDialog(getMainFrame());        
        thread.start();        
    }//GEN-LAST:event_tagsUpdateButtonActionPerformed

    private void tagsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tagsButtonActionPerformed
        JMenu menu = LJMainFrame.getTagsMenu();
        int x = this.tagsButton.getX();
        int y = this.tagsButton.getY();
        menu.getPopupMenu().show(this.tagsButton.getParent(), x, y);
    }//GEN-LAST:event_tagsButtonActionPerformed

    private void plainEditorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_plainEditorFocusGained
        m_focusedText = plainEditor;
    }//GEN-LAST:event_plainEditorFocusGained

    private void subjectEditFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_subjectEditFocusGained
        m_focusedText = subjectEdit;
    }//GEN-LAST:event_subjectEditFocusGained
    
    private void setEventObject() {
        m_post.setSubject(subjectEdit.getText());
        m_post.setBody(plainEditor.getText());
        m_post.setMusic(musicEdit.getText());
        m_post.setLocation(locationEdit.getText());
        
        if (timeSpinner.isEnabled()) {
            m_post.setDate((Date)timeSpinner.getValue());
        } else {
            m_post.setDate(null);
        }
        
        int selIndex = this.userpicDropDown.getSelectedIndex();
        if (selIndex > 0) {
            m_post.setUserpic(this.m_account.getUserpicKeys().get(selIndex));
        } else {
            m_post.setUserpic(null);
        }              
        
        int moodIndex = this.moodDropDown.getSelectedIndex();
        String moodText = (String)this.moodDropDown.getSelectedItem();
        int moodID = -1;
        if (moodIndex != -1) {
            LJMood mood = this.m_account.getMoods().get(moodIndex);
            if (mood != null) {
                moodID = mood.getID();
            }
        }
        m_post.setMood(moodID, moodText);
        
        m_post.setJournal((String)this.sharedJournalsComboBox.getSelectedItem());
        
        String tagList = tagsEdit.getText().trim();
        m_post.setTagList(tagList);
    }
    
    private void previewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previewButtonActionPerformed
        m_post.setSubject(subjectEdit.getText());
        m_post.setBody(plainEditor.getText());
        int selIndex = this.userpicDropDown.getSelectedIndex();
        if (selIndex > 0) {
            m_post.setUserpic(this.m_account.getUserpicKeys().get(selIndex));
        } else {
            m_post.setUserpic(null);
        }
        if (timeSpinner.isEnabled()) {
            m_post.setDate((Date)timeSpinner.getValue());
        } else {
            m_post.setDate(new Date());
        }

        try {       
            Previewer previewer = new Previewer(m_account, m_post);
            
            if (Options.getUseExternalPreview()) {
                Utils.runBrowser(previewer.getCutFileURL().toString());
            } else {
                PreviewDialog d = new PreviewDialog(getMainFrame(), previewer.getCutFileURL(), previewer.getFullFileURL());
                if (d.showDialog()) {
                    onPost(true, null);
                }                
            }
        }
        catch (Exception e) {
            ((LJMainFrame)getMainFrame()).handleException(e);
        }        
    }//GEN-LAST:event_previewButtonActionPerformed

    private void sharedJournalsComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sharedJournalsComboBoxActionPerformed
        m_post.setJournal((String)sharedJournalsComboBox.getSelectedItem());
    }//GEN-LAST:event_sharedJournalsComboBoxActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        if (JOptionPane.showConfirmDialog(getMainFrame(), "Are you sure?", "", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                this.m_account.deleteEvent(m_post);
                setVisible(false);
            }
            catch (LJException e) {
                ((LJMainFrame)getMainFrame()).handleException(e);
            }
        }
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void noAutoFormatCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noAutoFormatCheckActionPerformed
        m_post.setNoAutoFormat(noAutoFormatCheck.isSelected());
    }//GEN-LAST:event_noAutoFormatCheckActionPerformed

    private void noCommentsCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noCommentsCheckActionPerformed
        m_post.setNoComments(noCommentsCheck.isSelected());
    }//GEN-LAST:event_noCommentsCheckActionPerformed

    private void noEmailCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noEmailCheckActionPerformed
        m_post.setNoEmail(noEmailCheck.isSelected());
    }//GEN-LAST:event_noEmailCheckActionPerformed

    private void backdateCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backdateCheckActionPerformed
        m_post.setBackdate(backdateCheck.isSelected());
    }//GEN-LAST:event_backdateCheckActionPerformed

    private void manualDateCheckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manualDateCheckActionPerformed
        timeSpinner.setEnabled(manualDateCheck.isSelected());
    }//GEN-LAST:event_manualDateCheckActionPerformed

    private void securityLevelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_securityLevelButtonActionPerformed
        onEditAccessLevel();
    }//GEN-LAST:event_securityLevelButtonActionPerformed

    private void screenComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_screenComboBoxActionPerformed
        m_post.setScreeningType(screenComboBox.getSelectedIndex());
    }//GEN-LAST:event_screenComboBoxActionPerformed

    private void accessComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_accessComboBoxActionPerformed
        if (internalAccessChange) {
            return;
        }
            
        int index = accessComboBox.getSelectedIndex();
        switch (index) {
            case 0:     // public
                m_post.setAccessLevel(LJEvent.ACCESS_PUBLIC);
                break;
            case 1:     // private
                m_post.setAccessLevel(LJEvent.ACCESS_PRIVATE);
                break;
            case 2:     // friends only
                m_post.setAccessLevel(LJEvent.ACCESS_FRIENDS);
                break;
            case 3:
                m_post.setAccessLevel(LJEvent.ACCESS_GROUPS);
                onEditAccessLevel();
                break;
        }
    }//GEN-LAST:event_accessComboBoxActionPerformed

    private void setupAccessLevelComboBox() {
        internalAccessChange = true;
        accessComboBox.setSelectedIndex(m_post.getAccessLevel());
        internalAccessChange = false;
    }
    
    private void onEditAccessLevel() {
        EventAccessLevelDialog dial = new EventAccessLevelDialog(getMainFrame(), m_post, this.m_account.getGroups());
        if (dial.showDialog()) {
            setupAccessLevelComboBox();
        }
    }
    
    private void onPost(boolean close, String[] journals) {
        m_post.setSubject(subjectEdit.getText());
        m_post.setBody(plainEditor.getText());
        m_post.setMusic(musicEdit.getText());
        m_post.setLocation(locationEdit.getText());
        
        if (timeSpinner.isEnabled()) {
            m_post.setDate((Date)timeSpinner.getValue());
        } else {
            m_post.setDate(null);
        }
        
        int selIndex = this.userpicDropDown.getSelectedIndex();
        if (selIndex > 0) {
            m_post.setUserpic(this.m_account.getUserpicKeys().get(selIndex));
        } else {
            m_post.setUserpic(null);
        }
              
        
        int moodIndex = this.moodDropDown.getSelectedIndex();
        String moodText = (String)this.moodDropDown.getSelectedItem();
        int moodID = -1;
        if (moodIndex != -1) {
            LJMood mood = this.m_account.getMoods().get(moodIndex);
            if (mood != null) {
                moodID = mood.getID();
            }
        }
        m_post.setMood(moodID, moodText);
        
        m_post.setJournal((String)this.sharedJournalsComboBox.getSelectedItem());
        
        String tagList = tagsEdit.getText().trim();
        m_post.setTagList(tagList);
        
        if (journals == null) {
            journals = new String[] { m_post.getJournal() };
        }
        
        
        try {
            for (String j : journals) {
                if (j != null) {
                    m_post.setJournal(j);
                    this.m_account.postEvent(m_post);
                    if (close) {
                        /* this is needed for another posting
                         * when posting to multiple journals the window is always closed
                         */
                        m_post.setID(-1);       
                    }
                }
            }
            
            if (tagList.length() != 0) {
                this.m_account.addLocalTags(tagList);
                Options.saveUserTags(this.m_account.getUserTags());
                ((LJMainFrame)getMainFrame()).buildTagsMenu(this.m_account.getUserTags());
            }
            if (close) {
                setClosed(true);
            }
        }
        catch (LJException e) {
            ((LJMainFrame)getMainFrame()).handleException(e);
        }
        catch (Exception e) {            
        }
    }
    
    private void postButtonAndContinueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_postButtonAndContinueActionPerformed
        onPost(true, null);
    }//GEN-LAST:event_postButtonAndContinueActionPerformed

    private void userpicDropDownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userpicDropDownActionPerformed
        int index = userpicDropDown.getSelectedIndex();
        if (index != -1) {
            String key = this.m_account.getUserpicKeys().get(index);
            ImageIcon icon = IconManager.getUserpic(key);
            userpicShowLabel.setIcon(icon);
        }
    }//GEN-LAST:event_userpicDropDownActionPerformed

    public void insertText(String text) {
        if (m_focusedText != null) {
            m_focusedText.replaceSelection(text);
            m_focusedText.requestFocus();
        }
    }
    
    public void onInsertFriend(String username) {
        if ((m_userRefDialog != null) && (m_userRefDialog.isVisible())) {
            m_userRefDialog.userMenuItemSelected(username);
        } else {
            if (username == null) {
                username = JOptionPane.showInputDialog(getMainFrame(), "Friend");
            }

            if (username != null) {
                StringBuilder b = new StringBuilder("<lj user=\"");            
                b.append(username);
                b.append("\">");

                insertText(b.toString());
            }
        }
    }

    public void onInsertCommunity(String username) {
        if ((m_userRefDialog != null) && (m_userRefDialog.isVisible())) {
            m_userRefDialog.userMenuItemSelected(username);
        } else {
            if (username == null) {
                username = JOptionPane.showInputDialog(getMainFrame(), "Community");
            }

            if (username != null) {
                StringBuilder b = new StringBuilder("<lj comm=\"");
                b.append(username);
                b.append("\">");

                insertText(b.toString());
            }
        }
    }
    
    
    public void onLJCutOpen(String text) {
        StringBuilder b = new StringBuilder("<lj-cut");
        
        if (text == null) {
            String sel = plainEditor.getSelectedText();
            text = sel;
        }
        
        if (text != null) {
            b.append(" text=\"");
            b.append(text);
            b.append("\"");
        }
        b.append(">");
            
        insertText(b.toString());
    }
    
    public void onLJCutClose() {
        plainEditor.replaceSelection("</lj-cut>");
        plainEditor.requestFocus();
    }
    
    public void onLJCutSurround() {
        String sel = plainEditor.getSelectedText();
        StringBuilder b = new StringBuilder("<lj-cut>");
        if (sel != null) {
            b.append(sel);
        }
        b.append("</lj-cut>");
        insertText(b.toString());
    }
    
    public void onFormatTag(String tag) {
        String sel = plainEditor.getSelectedText();
        StringBuilder b = new StringBuilder("<");
        b.append(tag);
        b.append(">");
                
        if (sel != null) {
            b.append(sel);
        }
        b.append("</");
        b.append(tag);
        b.append(">");
        insertText(b.toString());        
    }
    
    public void onFormatTag(String open, String close) {
        String sel = plainEditor.getSelectedText();
        StringBuilder b = new StringBuilder(open);
        if (sel != null) {
            b.append(sel);
        }
        b.append(close);                
        insertText(b.toString());        
    }
    
    public void onEllipsysSymbol() {
        insertText("&hellip;");
    }
    
    public void onTradeSymbol() {
        insertText("&trade;");
    }
    
    public void onCopyrightSymbol() {
        insertText("&copy;");
    }
    
    public void onInsertReference() {
        if (m_refDialog == null) {
            m_refDialog = new InsertReferenceDialog(getMainFrame());
        }
        
        try {
            String clipText = ClipboardUtil.getAsString();
            if ((clipText != null) && 
                 (clipText.startsWith("http://") || clipText.startsWith("https://"))
                 ) {
                m_refDialog.setURL(clipText);
            }
            
            m_refDialog.setReferenceText(plainEditor.getSelectedText());
        
            if (m_refDialog.showDialog()) {
                insertText(m_refDialog.getReference());
            }
        }
        catch (Exception e) {
            ((LJMainFrame)getMainFrame()).handleException(e);            
        }
    }
    
    public void onInsertAdvancedUserReference() {
        if (m_userRefDialog == null) {
            m_userRefDialog = new AdvancedUserReferenceDialog(getMainFrame(), m_account);
        }
        
        if (m_userRefDialog.showDialog()) {
            insertText(m_userRefDialog.getReference());
        }
    }
    
    public void onInsertImageReference() {
        if (m_imageRefDialog == null) {
            m_imageRefDialog = new ImageReferenceDialog(getMainFrame());
        }
        
        if (m_imageRefDialog.showDialog()) {
            insertText(m_imageRefDialog.getReference());
        }
    }
    
    public void onInsertTag(String name) {
        String tStr = tagsEdit.getText();

        int pos = tStr.indexOf(name);
        if (pos != -1) {
            // remove all such tags
            tStr = tStr.replace(name, "").replaceAll(" +,|, *$|^(, *)*", "");
        } else {
            // add tag
            if (tStr.length() == 0) {
                tStr = name;
            } else {
                tStr += ", " + name;
            }
        }
        
        tagsEdit.setText(tStr);
    }
    
    public void onSave() {
        if (m_saveAsFile == null) {
            onSaveAs();
        } else {
            try {
                setEventObject();
                javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
                javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
                org.w3c.dom.Document doc = builder.newDocument();

                m_post.toXML(doc);
                javax.xml.transform.Transformer t = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
                t.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(new FileOutputStream(m_saveAsFile)));                
            }
            catch (Exception e) {
                ((LJMainFrame)getMainFrame()).handleException(e);            
            }
        }
    }
    
    public void onSaveAs() {
        setEventObject();
        
        try {
            javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
            javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
            org.w3c.dom.Document doc = builder.newDocument();
            
            m_post.toXML(doc);
            
            JFileChooser dial = new JFileChooser();
            dial.addChoosableFileFilter(new XMLFileFilter());
            dial.setAcceptAllFileFilterUsed(false);
            if (dial.showSaveDialog(getMainFrame()) == JFileChooser.APPROVE_OPTION) {
                m_saveAsFile = dial.getSelectedFile();
                javax.xml.transform.Transformer t = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
                t.transform(new javax.xml.transform.dom.DOMSource(doc), new javax.xml.transform.stream.StreamResult(new FileOutputStream(m_saveAsFile)));
                fileNameField.setText(m_saveAsFile.getAbsolutePath());
            }    
        }
        catch (Exception e) {
            ((LJMainFrame)getMainFrame()).handleException(e);            
        }
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox accessComboBox;
    private javax.swing.JPanel attributesPanel;
    private javax.swing.JCheckBox backdateCheck;
    private javax.swing.JButton deleteButton;
    private javax.swing.JPanel editTab;
    private javax.swing.JTextField fileNameField;
    private javax.swing.JTextField idStatusField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField locationEdit;
    private javax.swing.JCheckBox manualDateCheck;
    private javax.swing.JComboBox moodDropDown;
    private javax.swing.JTextField musicEdit;
    private javax.swing.JCheckBox noAutoFormatCheck;
    private javax.swing.JCheckBox noCommentsCheck;
    private javax.swing.JCheckBox noEmailCheck;
    private javax.swing.JPanel optionsPanel;
    private javax.swing.JPanel optionsTab;
    private javax.swing.JEditorPane plainEditor;
    private javax.swing.JMenuItem postAndContinueMenuItem;
    private javax.swing.JButton postButtonAndContinue;
    private javax.swing.JButton postMenuButton;
    private javax.swing.JPopupMenu postPopupMenu;
    private javax.swing.JMenuItem postToManyMenuItem;
    private javax.swing.JButton previewButton;
    private javax.swing.JComboBox screenComboBox;
    private javax.swing.JButton securityLevelButton;
    private javax.swing.JPanel securityTab;
    private javax.swing.JComboBox sharedJournalsComboBox;
    private javax.swing.JPanel statusPanel;
    private javax.swing.JTextField subjectEdit;
    private javax.swing.JPanel subjectPanel;
    private javax.swing.JButton tagsButton;
    private javax.swing.JTextField tagsEdit;
    private javax.swing.JButton tagsUpdateButton;
    private javax.swing.JSpinner timeSpinner;
    private javax.swing.JComboBox userpicDropDown;
    private javax.swing.JPanel userpicPanel;
    private javax.swing.JLabel userpicShowLabel;
    // End of variables declaration//GEN-END:variables
 
    static {
        ResourceBundle bundle = Options.getResourceBundle();

        securityTypes = new String[4];
        securityTypes[0] = bundle.getString("stPublic");
        securityTypes[1] = bundle.getString("stPrivate");
        securityTypes[2] = bundle.getString("stFriends");
        securityTypes[3] = bundle.getString("stCustom");
        
        screenTypes = new String[5];
        screenTypes[0] = bundle.getString("scDefault");
        screenTypes[1] = bundle.getString("scNo");
        screenTypes[2] = bundle.getString("scAnonymous");
        screenTypes[3] = bundle.getString("scNonFriends");
        screenTypes[4] = bundle.getString("scAll");
    }
}
