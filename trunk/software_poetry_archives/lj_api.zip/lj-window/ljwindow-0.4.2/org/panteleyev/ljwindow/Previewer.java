/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import java.io.*;
import java.net.*;
import org.panteleyev.ljapi.*;

/**
 *
 * @author peterp
 */
public class Previewer {
    private StringBuffer m_fullText;
    private StringBuffer m_cutText;
    private StringBuffer m_subjectText;
    
    private File m_fullFile;
    private File m_cutFile;
    private String m_fullFileName;
    
    public URL getCutFileURL() throws MalformedURLException { 
        return m_cutFile.toURL(); 
    }
    public URL getFullFileURL() throws MalformedURLException { 
        return m_fullFile.toURL(); 
    }
    
    /** Creates a new instance of Previewer */
    public Previewer(LJAccount account, LJEvent post) throws IOException {
        /* Open temporary files */
        m_fullFile = File.createTempFile("ljw", ".htm");
        m_fullFile.deleteOnExit();
        m_fullFileName = m_fullFile.toURL().toString();
        m_cutFile = File.createTempFile("ljw", ".htm");
        m_cutFile.deleteOnExit();
        
        /* Parse subject line */
        StringBuffer subjectText = new StringBuffer(post.getSubject());
        handleSimpleTags(subjectText);
        
        StringBuffer textBuffer = new StringBuffer(post.getBody());
        handleSimpleTags(textBuffer);
        
        handleLJRaw(textBuffer);
        
        m_fullText = new StringBuffer("<html><head>");
        
        /* Add some styles */
        StringBuffer st = new StringBuffer("<style type=\"text/css\">\n");
        st.append("a { text-decoration: none; }\n");
        st.append("body,table,tr,td,form {font-size: 12pt; font-family: Verdana,Verdana,Tahoma,Arial,sans-serif;}");
        st.append("</style>");
        
        m_fullText.append(st.toString());
        
        m_fullText.append("</head>");
        m_fullText.append("<body vlink=\"#500050\" text=\"#000000\" bgcolor=\"#FFFFFF\" alink=\"#FF00C0\" link=\"#000050\" style=\"WORD-WRAP: break-word\">");
        /* Show userpic and other attributes */
        m_fullText.append("<table border='0'><tr>");
        String upicKey = post.getUserpic();
        if (upicKey == null) {
            upicKey = "(default)";
        }
        LJUserpic upic = IconManager.getUserpic(upicKey);
        if (upic != null) {
            m_fullText.append("<td><img src='");
            m_fullText.append(upic.getUrlString());
            m_fullText.append("'>");
        }
        m_fullText.append("<td>");
        m_fullText.append(account.getFullName());
        m_fullText.append(" (");
        m_fullText.append(buildUserReference(account.getLoginName()));
        m_fullText.append(") wrote on<br>");
        m_fullText.append(post.getDate().toString());
        m_fullText.append("</table><p><p>");
        /* Show subject */
        m_fullText.append("<font color='blue'><b>");
        m_fullText.append(subjectText.toString());
        m_fullText.append("</b></font>");
        m_fullText.append("<p>");
        /* Show the main body */
        m_fullText.append(textBuffer.toString().replace("\n", "<br>"));
        m_fullText.append("</body></html>");

///        this.m_cutText = new StringBuffer(m_fullText);
///        handleLJCuts(m_cutText);
        handleLJCuts();
        
        PrintWriter pr = new PrintWriter(m_cutFile);
        pr.print(m_cutText);
        pr.close();
        
        pr = new PrintWriter(m_fullFile);
        pr.print(m_fullText);
        pr.close();
    }

    private String extractValue(String tag) {
        int start = tag.indexOf('\"');
        int end = tag.lastIndexOf('\"');
        return tag.substring(start + 1, end);
    }

    private void handleSimpleTags(StringBuffer b) {
        int pos = 0;
        
        while ((pos = b.indexOf("<lj", pos)) != -1) {
            int endTag = b.indexOf(">", pos);
            if (endTag == -1) {
                // TODO: Insert syntax exception here
                return;
            }

            String tag = b.substring(pos, endTag + 1);

            if (tag.matches("<lj\\s*user\\s*=\\s*\"\\w*\"\\s*>")) {
                b.replace(pos, endTag + 1, buildUserReference(extractValue(tag)));
            } else {
                if (tag.matches("<lj\\s*comm\\s*=\\s*\"\\w*\"\\s*>")) {
                    b.replace(pos, endTag + 1, buildCommReference(extractValue(tag)));
                } else {
                    pos = endTag + 1;
                }
            }
        }
    }
    
    private void handleLJCuts() {
        m_cutText = new StringBuffer();
        
        int posStart = 0;
        int appendFrom = 0;
        int cutIndex = 0;
        
        while ((posStart = m_fullText.indexOf("<lj-cut", posStart)) != -1) {
            int tagEndPos = m_fullText.indexOf(">", posStart);
            if (tagEndPos == -1) {
                // TODO: Insert syntax exception here
                break;
            }
            
            // append text before tag to cutText
            m_cutText.append(m_fullText.substring(appendFrom, posStart));
            
            String cutTitle = "Read more";
            String tag = m_fullText.substring(posStart, tagEndPos + 1);
            if (tag.matches("<lj-cut\\s*text\\s*=\\s*\"[\\p{L}\\s\\d\\p{Punct}]*\"\\s*>")) {
                cutTitle = extractValue(tag);
            }
            
            String anchor = "#ljcut" + Integer.toString(cutIndex);

            // Form anchor text for full text
            StringBuffer anchorText = new StringBuffer("<a name='");
            anchorText.append(anchor);
            anchorText.append("'>");

            // replace starting tag by anchor
            m_fullText.replace(posStart, tagEndPos + 1, anchorText.toString());
            
            int endTagStart = m_fullText.indexOf("</lj-cut>", posStart);
            int posEnd = -1;
            if (endTagStart == -1) {
                endTagStart = m_fullText.length();
                posEnd = m_fullText.length();
            }
            
            if (posEnd != m_fullText.length()) {
                posEnd = endTagStart + 9;
            }
            
            // Remove </lj-cut>
            m_fullText.replace(endTagStart, posEnd, "");
            posEnd = endTagStart;
            
            
            m_cutText.append("<a href=\"");
            m_cutText.append(m_fullFileName);
            m_cutText.append(anchor);
            m_cutText.append("\">( ");
            m_cutText.append(cutTitle);
            m_cutText.append(" )</a>");
            
                
            posStart = posEnd;
            appendFrom = posStart;
            
            cutIndex++;
        }
        
        // Add the rest of the text
        m_cutText.append(m_fullText.substring(appendFrom, m_fullText.length()));
    }
    
    private void handleLJRaw(StringBuffer b) {
        int posStart = 0;
        int posEnd;
        
        while (true) {
            posStart = b.indexOf("<lj-raw>", posStart);
            if (posStart == -1) {
                break;
            }
            
            posEnd = b.indexOf("</lj-raw>", posStart);
            if (posEnd == -1) {
                posEnd = b.length();
            }
            
            String sub = b.substring(posStart + 8, posEnd - 1);
            sub = sub.replaceAll("[\r\n]", "");
            if (posEnd != b.length()) {
                posEnd += 9;
            }
            
            b.replace(posStart, posEnd, sub);
            
        }
    }
    
    private String buildUserReference(String userName) {
        StringBuffer b = new StringBuffer("<span class='ljuser' style='white-space: nowrap;'><a href='http://");
        b.append(userName.replace("_", "-"));
        b.append(".livejournal.com/profile'><img src='http://stat.livejournal.com/img/userinfo.gif' ");
        b.append("alt='[info]' width='17' height='17' border='0' valign='middle'></a><a href='http://");
        b.append(userName.replace("_", "-"));
        b.append(".livejournal.com/'><b>");
        b.append(userName);
        b.append("</b></a></span>");
        return b.toString();
    }

    private String buildCommReference(String userName) {
        StringBuffer b = new StringBuffer("<span class='ljuser' style='white-space: nowrap;'><a href='http://");
        b.append(userName.replace("_", "-"));
        b.append(".livejournal.com/profile'><img src='http://stat.livejournal.com/img/community.gif' ");
        b.append("alt='[info]' width='17' height='17' border='0' valign='middle'></a><a href='http://");
        b.append(userName.replace("_", "-"));
        b.append(".livejournal.com/'><b>");
        b.append(userName);
        b.append("</b></a></span>");
        return b.toString();
    }
    
}
