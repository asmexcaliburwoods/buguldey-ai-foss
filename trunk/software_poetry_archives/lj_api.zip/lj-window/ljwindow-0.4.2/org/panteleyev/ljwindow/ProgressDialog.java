/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import javax.swing.*;
import org.panteleyev.tools.*;
import org.panteleyev.ljapi.*;

public class ProgressDialog extends BasicDialog implements LJProgressCallback {
    private String m_message;
    private int m_intValue;
    private int m_minValue;
    private int m_maxValue;
    private boolean m_boolValue;
    
    /** Creates new form ProgressDialog */
    public ProgressDialog(java.awt.Frame owner) {
        super(owner);
        initComponents();
    }

    /** Creates new form ProgressDialog */
    public ProgressDialog(java.awt.Dialog owner) {
        super(owner);
        initComponents();
    }
    
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        progressBar = new javax.swing.JProgressBar();
        messageLabel = new javax.swing.JLabel();

        getContentPane().setLayout(new java.awt.GridBagLayout());

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setModal(true);
        setResizable(false);
        setUndecorated(true);
        jPanel1.setLayout(new java.awt.GridBagLayout());

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(7, 7, 7, 7);
        jPanel1.add(progressBar, gridBagConstraints);

        messageLabel.setText("jLabel1");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(7, 7, 7, 7);
        jPanel1.add(messageLabel, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        getContentPane().add(jPanel1, gridBagConstraints);

        pack();
    }

    public void asyncShowDialog() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                showDialog();
            }
        });        
    }

    public void asyncCloseDialog() {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                setVisible(false);
            }
        });        
    }
    
    public void setMessage(String msg) {
        m_message = msg;
        
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    messageLabel.setText(m_message);
                    pack();
                }
            });
        }
        catch (Exception e) {            
        }
    }
    
    public void setIndeterminate(boolean b) {
        m_boolValue = b;
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    progressBar.setIndeterminate(m_boolValue);
                }
            });
        }
        catch (Exception e) {            
        }
    }
    
    public void setMinimum(int x) {
        m_minValue = x;
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    progressBar.setMinimum(m_minValue);
                }
            });
        }
        catch (Exception e) {            
        }
    }

    public void setMaximum(int x) {
        m_maxValue = x;
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    progressBar.setMaximum(m_maxValue);
                }
            });
        }
        catch (Exception e) {            
        }
    }
    
    public void setValue(int x) {
        m_intValue = x;
        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    progressBar.setValue(m_intValue);
                }
            });
        }
        catch (Exception e) {            
        }
    }
    
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel messageLabel;
    private javax.swing.JProgressBar progressBar;
}
