/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.ljwindow;

import java.util.*;
import java.util.prefs.*;

final class UserProfileManager {
    private static final String PROFILES_INDEX  = "index";
    private static final String PROFILES_DATA   = "data";
    private static final String PROFILE_COUNT_PREF      = "count";
    private static final String PROFILE_DEFAULT_PREF    = "default";

    private static HashMap<String, UserProfile> profiles;
    private static UserProfile defaultProfile;
    private static UserProfile currentProfile;
    
    public static void loadProfiles() {
        profiles.clear();
        
        Preferences profNode = PrefStorage.getProfilesNode();
        
        Preferences profIndex = profNode.node(PROFILES_INDEX);
        Preferences profData = profNode.node(PROFILES_DATA);

        int profileCount = profNode.getInt(PROFILE_COUNT_PREF, 0);
        String defaultProfileName = profNode.get(PROFILE_DEFAULT_PREF, "");       
        
        for (int i = 0; i < profileCount; i++) {            
            String userName = profIndex.get("profile" + Integer.toString(i), "");
            if (userName.length() != 0) {
                UserProfile prof = new UserProfile();
                prof.setUserName(userName);
                Preferences pn = profData.node(userName);
                prof.setHPasswd(pn.get("hpasswd", ""));
                prof.setCacheFriends(pn.getBoolean("cache_friends", true));
                prof.setCacheUserpics(pn.getBoolean("cache_userpics", true));
                prof.setStorePasswd(pn.getBoolean("store_passwd", true));                
                profiles.put(userName, prof);
            }
        }
        
        defaultProfile = profiles.get(defaultProfileName);
    }
    
    public static void saveProfiles() {
        ArrayList<UserProfile> v = new ArrayList<UserProfile>(profiles.values());
        
        int profileCount = v.size();

        Preferences profNode = PrefStorage.getProfilesNode();
        
        Preferences profIndex = profNode.node(PROFILES_INDEX);
        Preferences profData = profNode.node(PROFILES_DATA);
        
        profNode.putInt(PROFILE_COUNT_PREF, profileCount);
        profNode.put(PROFILE_DEFAULT_PREF, getDefaultProfileName());
        
        try {
            profIndex.removeNode();
            profData.removeNode();
        }
        catch (Exception e) {            
        }
        profIndex = profNode.node(PROFILES_INDEX);
        profData = profNode.node(PROFILES_DATA);
        
        for (int i = 0; i < profileCount; i++) {
            UserProfile prof = v.get(i);
            profIndex.put("profile" + Integer.toString(i), prof.getUserName());
            
            Preferences pn = profData.node(prof.getUserName());
            
            pn.put("hpasswd", prof.getHPasswd());
            pn.putBoolean("cache_friends", prof.getCacheFriends());
            pn.putBoolean("cache_userpics", prof.getCacheUserpics());
            pn.putBoolean("store_passwd", prof.getStorePasswd());
        }
    }
    
    public static int getProfileCount() { return profiles.size(); }
    
    public static UserProfile getProfile(String name) {
        return profiles.get(name);
    }
    
    public static void deleteProfile(UserProfile prof) {
        if (prof == defaultProfile) {
            setDefaultProfile(null);
        }
        Options.deleteCachedData(prof.getUserName());
        profiles.remove(prof.getUserName());
        saveProfiles();
    }
    
    public static ArrayList<String> getProfileNames() {
        return new ArrayList<String>(profiles.keySet());
    }
    
    public static ArrayList<UserProfile> getProfiles() {
        return new ArrayList<UserProfile>(profiles.values());
    }
    
    public static UserProfile getDefaultProfile() { return defaultProfile; }
    public static void setDefaultProfile(UserProfile prof) { defaultProfile = prof; }
    
    public static String getDefaultProfileName() { 
        return (defaultProfile == null)? "" : defaultProfile.getUserName(); 
    }
    
    public static UserProfile getCurrentProfile() { return currentProfile; }
    public static void setCurrentProfile(UserProfile prof) { currentProfile = prof; }
    public static String getCurrentProfileName() { 
        return (currentProfile == null)? "" : currentProfile.getUserName();
    }
    
    public static void addProfile(UserProfile prof) { 
        profiles.put(prof.getUserName(), prof);
    }

    static {
        profiles = new HashMap<String, UserProfile>();
    }
}
