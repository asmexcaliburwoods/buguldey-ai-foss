/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.tools;

import javax.swing.*;

public class BasicDialog extends JDialog {
    private boolean ok;
    
    /** Creates a new instance of BasicDialog */
    public BasicDialog(java.awt.Frame parent) {
        super(parent, true);
        this.ok = false;
    }
    
    public BasicDialog(java.awt.Dialog owner) {
        super(owner, true);
        this.ok = false;
    }
        
    public boolean isOK() { return this.ok; }
    
    public boolean showDialog() {
        this.ok = false;
        center();
        super.setVisible(true);
        return this.ok;
    }
    
    protected void onOk() {
        this.ok = true;
        setVisible(false);
    }

    protected void onCancel() {
        this.ok = false;
        setVisible(false);       
    }
    
    public void center() {
        java.awt.Window owner = getOwner();
        if (owner == null) {
            return;
        }

        java.awt.Rectangle ownerBounds = owner.getBounds();
        java.awt.Rectangle myBounds = getBounds();
        setBounds(ownerBounds.x + (ownerBounds.width - myBounds.width)/2,
                ownerBounds.y + (ownerBounds.height - myBounds.height)/2,
                myBounds.width,
                myBounds.height);
    }
    
    protected int parseInt(javax.swing.JTextField edit) {
        String text = edit.getText();
        if ((text == null) || (text.length() == 0)) {
            return 0;
        } else {
            try {
                return Integer.parseInt(text);
            }
            catch (NumberFormatException e) {
                return 0;
            }
        }
    }
}
