/**
 * Copyright (c) 2006, Petr Panteleyev
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 *    1. Redistributions of source code must retain the above copyright notice, 
 *       this list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice, 
 *       this list of conditions and the following disclaimer in the documentation 
 *       and/or other materials provided with the distribution.
 *    3. The name of the author may not be used to endorse or promote products 
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY 
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN 
 * IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 **/

package org.panteleyev.tools;

import javax.swing.*;
import javax.swing.table.*;
import java.text.*;
import java.util.*;

public class TableUtil {
    public static void adjustTableColumnSizes(JTable table) {
        TableColumn column = null;
        java.awt.Component comp = null;

        TableModel model = table.getModel();
        if (model == null) {
            return;                     // No model - no service
        }
        
        for (int col = 0; col < model.getColumnCount(); col++) {
            int headerWidth = 0;
            
            column = table.getColumnModel().getColumn(col);
            if (column == null) {
                continue;               // should not be
            }

            try {
                TableCellRenderer renderer = column.getHeaderRenderer();
                if (renderer == null) {
                    JTableHeader header = table.getTableHeader();
                    renderer = header.getDefaultRenderer();
                }
                comp = renderer.getTableCellRendererComponent(
                                     null, column.getHeaderValue(), 
                                     false, false, 0, 0);
                
                headerWidth = comp.getPreferredSize().width;
            } catch (NullPointerException e) {
                System.err.println("Failed twice, need something more useful!");
            }

            int cellWidth = 0;
            for (int row = 0; row < model.getRowCount(); row++) {
                TableCellRenderer renderer = table.getCellRenderer(row, col);
                if (renderer == null) {
                    renderer = table.getDefaultRenderer(model.getColumnClass(col));
                }
                comp = renderer.getTableCellRendererComponent(
                                     table, model.getValueAt(row, col),
                                     false, false, row, col);
                cellWidth = Math.max(comp.getPreferredSize().width, cellWidth);
            }

            column.setPreferredWidth(Math.max(headerWidth, cellWidth) + 10);
        }
    }

    public static void adjustTableRowSizes(JTable table) {
        TableColumn column = null;
        java.awt.Component comp = null;

        TableModel model = table.getModel();
        if (model == null) {
            return;                     // No model - no service
        }
        
        for (int row = 0; row < model.getRowCount(); row++) {           
            int cellHeight = 0;
            for (int col = 0; col < model.getColumnCount(); col++) {
                column = table.getColumnModel().getColumn(col);
                TableCellRenderer renderer = table.getCellRenderer(row, col);
                if (renderer == null) {
                    renderer = table.getDefaultRenderer(model.getColumnClass(col));
                }
                comp = renderer.getTableCellRendererComponent(
                                     table, model.getValueAt(row, col),
                                     false, false, row, col);
                cellHeight = Math.max(comp.getPreferredSize().height, cellHeight);
            }
            
            table.setRowHeight(row, cellHeight);
        }
    }
}
