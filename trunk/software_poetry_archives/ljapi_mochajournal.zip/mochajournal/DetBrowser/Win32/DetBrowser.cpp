// DetBrowser.cpp : Defines the entry point for the DLL application.

//



#include "stdafx.h"

#include "DetBrowser.h"

#include "JavaNativeSystem.h"

#include <TCHAR.H>

#include <winreg.h>





BOOL APIENTRY DllMain( HANDLE hModule, 

                       DWORD  ul_reason_for_call, 

                       LPVOID lpReserved

					 )

{

    switch (ul_reason_for_call)

	{

		case DLL_PROCESS_ATTACH:

		case DLL_THREAD_ATTACH:

		case DLL_THREAD_DETACH:

		case DLL_PROCESS_DETACH:

			break;

    }

    return TRUE;

}



JNIEXPORT jobjectArray JNICALL Java_org_homedns_krolain_util_NativeSystem_OSDetectBrowser__

 (JNIEnv *environment, jobject instance)

{

	DWORD dwType;

	char *szIEPath = new char[MAX_PATH];

	char *szIEName = new char[MAX_PATH];

	DWORD dwSize = MAX_PATH;

	BOOL bResult = FALSE;

	jobjectArray browsers = NULL;

	jstring jIE = NULL;



    HKEY hKey;

	// Locate the registry where the install path of IE is.

	if (RegOpenKeyEx(HKEY_CLASSES_ROOT,"Applications\\iexplore.exe\\shell\\open\\command",0,KEY_READ,&hKey) == ERROR_SUCCESS)

	{

		if (RegQueryValueEx(hKey,NULL,0,&dwType,(LPBYTE)szIEPath,&dwSize) == ERROR_SUCCESS)

		{

			// Make sure it's of a string format.

			if (dwType != REG_SZ)

			{

				szIEPath[0] = '\0'; // NULL the string if it's of the wrong format.

			}

		}

		RegCloseKey(hKey);

	}



	// Locate the registry where the name of IE is.

	if (RegOpenKeyEx(HKEY_CLASSES_ROOT,"InternetExplorer.Application",0,KEY_READ,&hKey) == ERROR_SUCCESS)

	{

		if (RegQueryValueEx(hKey,NULL,0,&dwType,(LPBYTE)szIEName,&dwSize) == ERROR_SUCCESS)

		{

			// Make sure it's of a string format.

			if (dwType != REG_SZ)

			{

				szIEName[0] = '\0'; // NULL the string if it's of the wrong format.

			}

		}

		RegCloseKey(hKey);

	}



	if ((strlen(szIEPath) > 0) && (strlen(szIEName) > 0))

	{

		char *szIEResult = new char[strlen(szIEPath) + strlen(szIEName) + 2]; // Extra two is for the delimiter and the terminating null

		strcpy(szIEResult,szIEPath);

		szIEResult[strlen(szIEPath)]='|';

		strcpy(szIEResult+strlen(szIEPath)+1,szIEName);

		szIEResult[strlen(szIEPath)+strlen(szIEPath)+1] = '\0';

		WCHAR *wcIE = new WCHAR[strlen(szIEResult)+1];

		int len2 = MultiByteToWideChar(CP_ACP,0,szIEResult,strlen(szIEResult),wcIE,strlen(szIEResult)+1);

		jIE = environment->NewString(wcIE,len2);

		delete wcIE;

		delete szIEResult;

	}



	if (jIE != NULL)

	{

		browsers = environment->NewObjectArray(1,environment->FindClass("java/lang/String"),NULL);

		environment->SetObjectArrayElement(browsers,0,jIE);

	}





	delete szIEName;

	delete szIEPath;



	return browsers;

}

