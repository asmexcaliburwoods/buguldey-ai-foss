// DetMusic.cpp : Defines the entry point for the DLL application.
//

#include <jni.h>
#include "stdafx.h"
#include "DetMusic.h"
#include "JavaDetectMusic.h"
#include <TCHAR.H>
#include <winreg.h>

// This is the filename of Winamp 2
#define KSZWINAMP "\\winamp.exe"

int g_iWinAmpVer = 0; // Indicates the version number of the installed WinAmp app (if any)

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


/* ***************************************
 * Java Function: jboolean DetectMusic(JNIEnv *environment, jobject instance)
 * Description:  This function returns the title of the music currently being played by WinAmp
 * Parameters:  JNIEnv *environment:  JNI Environment setup
 *			    jobject instance:  ???
 * Returns:  jobject - jsting object is returned containing the title of the music being played, if WinAmp is running.
 *				     If WinAmp is not running, then it returns NULL;
 * Created by:  Jason Smith
 * History:  Sept. 3, 2002 - Initial creation
 ******************************************
 */
JNIEXPORT jobject JNICALL Java_org_homedns_krolain_MochaJournal_Panels_EntryPanel_DetectMusic__
 (JNIEnv *environment, jobject instance)
{
	WCHAR *cResult = NULL;
	HWND hWnd;
	char *cMusic = NULL;
	int iMusicLen = 0;
	
	// Find the WinAmp window
	if (g_iWinAmpVer < 2) return NULL;
	if (g_iWinAmpVer == 2)
		hWnd = FindWindow("Winamp v1.x",NULL);
	else
		hWnd = FindWindow("STUDIO",NULL);

	if (hWnd == NULL) return NULL;
	
	// Get the Window title if the WinAmp window
	char *cText = new char[255];
	int len = GetWindowText(hWnd,cText,255);
	if (len == 0) return NULL;
	
	// Extract the music part of the title
	if (g_iWinAmpVer == 2)
	{
		char *cEnd = strrchr(cText,'-');
		if (cEnd == NULL) return NULL;
		int iEnd = cEnd - cText + 1; // This points to the actual position of the '-'
		iEnd --; // Now we point to the space before the '-';
		iMusicLen = iEnd - 3; // We drop the first three characters of the title, which include the track number, '.' and space.
		cMusic = new char[iMusicLen]; 
		strncpy(cMusic,cText+3,iMusicLen-1); //
		cMusic[iMusicLen-1] = '\0';
	}
	else if (g_iWinAmpVer == 3)
	{
		char *cEnd = strrchr(cText,'('); // Ignore the playing state
		cText[cEnd-cText] = '\0';
		cEnd = strrchr(cText,'('); // Ignore the time stamp.
		if (cEnd == NULL) return NULL;
		int iEnd = cEnd - cText + 1; // This points to the actual position of the '('
		iEnd --; // Now we point to the space before the '(';
		iMusicLen = iEnd - 3; // We drop the first three characters of the title, which include the track number, '.' and space.
		cMusic = new char[iMusicLen]; 
		strncpy(cMusic,cText+3,iMusicLen-1);
		cMusic[iMusicLen-1] = '\0';
	}

	// Convert the string to Unicode and create a Java String
	cResult = new WCHAR[255];
	int len2 = MultiByteToWideChar(CP_ACP,0,cMusic,iMusicLen-1,cResult,255);
	jstring szResult = environment->NewString(cResult,len2);

	// Free the memory
	delete cMusic;
	delete cText;
	delete cResult;

	return szResult;
}

/* ***************************************
 * Function: BOOL checkWinAmp2(void)
 * Description:  This function tries to locate if WinAmp2 is installed on the system
 * Parameters:  None
 * Returns:  BOOL - TRUE if WinAmp3 is installed and the appropriate executable exists on the computer,
 *				     else it returns FALSE
 * Created by:  Jason Smith
 * History:  Sept. 3, 2002 - Initial creation
 ******************************************
 */
BOOL checkWinAmp2()
{
	DWORD dwType;
	char *szPath = new char[MAX_PATH];
	DWORD dwSize = MAX_PATH;
	BOOL bResult = FALSE;

    HKEY hKey;
	// Locate the registry where the install path of WinAmp2 is.
	if (RegOpenKeyEx(HKEY_CURRENT_USER,"Software\\Winamp",0,KEY_READ,&hKey) == ERROR_SUCCESS)
	{
		if (RegQueryValueEx(hKey,NULL,0,&dwType,(LPBYTE)szPath,&dwSize) == ERROR_SUCCESS)
		{
			// Make sure it's of a string format.
			if (dwType == REG_SZ)
			{
				// Find the executible file.
				char *szFile = new char[dwSize+sizeof(KSZWINAMP)];
				strncpy(szFile,szPath,dwSize-1);
				strncpy(szFile+dwSize-1,KSZWINAMP,sizeof(KSZWINAMP));
				szFile[dwSize+sizeof(KSZWINAMP)-1] = '\0';
				FILE *file = fopen(szFile,"rb");
				if (file != NULL)
				{
					g_iWinAmpVer = 2;
					bResult = TRUE;
					fclose(file);
				}
				delete szFile;
			}
		}
		RegCloseKey(hKey);
	}

	delete szPath;
	return bResult;
}

/* ***************************************
 * Function: BOOL checkWinAmp3(void)
 * Description:  This function tries to locate if WinAmp3 is installed on the system
 * Parameters:  None
 * Returns:  BOOL - TRUE if WinAmp3 is installed and the appropriate executable exists on the computer,
 *				     else it returns FALSE
 * Created by:  Jason Smith
 * History:  Sept. 3, 2002 - Initial creation
 ******************************************
 */
BOOL checkWinAmp3()
{
	DWORD dwType;
	char *szPath = new char[MAX_PATH];
	DWORD dwSize = MAX_PATH;
	BOOL bResult = FALSE;

    HKEY hKey;
	// Locate the registry where the install path of WinAmp3 is.
	if (RegOpenKeyEx(HKEY_CLASSES_ROOT,"Winamp3.File\\shell\\open\\command",0,KEY_READ,&hKey) == ERROR_SUCCESS)
	{
		if (RegQueryValueEx(hKey,NULL,0,&dwType,(LPBYTE)szPath,&dwSize) == ERROR_SUCCESS)
		{
			// Make sure it's of a string format.
			if (dwType == REG_SZ)
			{
				// Find the executible file.
				char *szFile = new char[dwSize];
				char *cQuote = strpbrk(szPath+1,"\"");
				int iQuote = cQuote - szPath + 1;
				
				strncpy(szFile,szPath+1,iQuote-1);
				szFile[iQuote-2] = '\0';
				FILE *file = fopen(szFile,"rb");
				if (file != NULL)
				{
					g_iWinAmpVer = 3;
					bResult = TRUE;
					fclose(file);
				}
				delete szFile;
			}
		}
		RegCloseKey(hKey);
	}

	delete szPath;
	return bResult;
}

/* ***************************************
 * Java Function: jboolean CanDetectMusic(JNIEnv *environment, jobject instance)
 * Description:  This function tries to locate if any version of WinAmp is installed on the system
 * Parameters:  JNIEnv *environment:  JNI Environment setup
 *			    jobject instance:  ???
 * Returns:  jboolean - JNI_TRUE if WinAmp 2 or 3 is installed and the appropriate executable exists on the computer,
 *				     else it returns JNI_FALSE
 * Created by:  Jason Smith
 * History:  Sept. 3, 2002 - Initial creation
 ******************************************
 */
JNIEXPORT jboolean JNICALL Java_org_homedns_krolain_MochaJournal_Panels_EntryPanel_CanDetectMusic__
 (JNIEnv *environment, jobject instance)
{
	BOOL bResult = FALSE;
	bResult = checkWinAmp2();
	bResult = bResult || checkWinAmp3();
	return bResult?JNI_TRUE:JNI_FALSE;
}
