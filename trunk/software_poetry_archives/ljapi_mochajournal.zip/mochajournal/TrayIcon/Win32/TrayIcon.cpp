// TrayIcon.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "TrayIcon.h"
#include "JTrayIcon.h"
#include <windows.h>
#include <shellapi.h>

#define JTRAYICON 0x1449
#define JTRAY_NOTIFICATION (WM_USER+100)


HWND g_hMainWnd = NULL;
TCHAR g_szClassName[] = "JTrayIcon";
HANDLE g_hThread = NULL;
DWORD g_dwThreadID = 1;
HINSTANCE g_hModule = NULL;
jobject g_clsCallBack = 0;
JavaVM *g_pJavaVM = NULL;
TCHAR g_szMEvents[3][8] = {"BUTTON1","BUTTON2","BUTTON3"};
jint g_JavaMEvents[3];
JNIEnv *g_JNIEnv = NULL;

HMENU g_hMenu = NULL;
HMENU g_MenuStack[10]; // Assume a ten level deep menu system.
int g_MenuLevel = -1;
BOOL g_bIconVisible = FALSE;
HICON g_hIcon = NULL;

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);


BOOL APIENTRY DllMain( HINSTANCE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	g_hModule = hModule;
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


DWORD WINAPI ThreadFunc( LPVOID lpParam ) 
{ 
	MSG msg;

	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= g_hModule;
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;
	wcex.hbrBackground	= NULL;
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= g_szClassName;
	wcex.hIconSm		= NULL;
	
	RegisterClassEx(&wcex);

	g_hMainWnd = CreateWindow(g_szClassName, "", WS_OVERLAPPEDWINDOW | CS_DBLCLKS , CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, g_hModule, NULL);

	ShowWindow(g_hMainWnd, SW_HIDE);
	UpdateWindow(g_hMainWnd);

	
	g_pJavaVM->AttachCurrentThread((void **)&g_JNIEnv,NULL);

	while (GetMessage(&msg, NULL, 0, 0))
	{
        TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	if (g_hMenu != NULL)
	{
		DestroyMenu(g_hMenu);
		g_hMenu = NULL;
	}
	g_MenuLevel = -1;

	UnregisterClass(g_szClassName,g_hModule);

	g_JNIEnv->DeleteGlobalRef(g_clsCallBack);
	g_pJavaVM->DetachCurrentThread();
	if (g_hIcon != NULL)
	{
		DestroyIcon(g_hIcon);
		g_hIcon = NULL;
	}
	g_clsCallBack = 0;
	g_JNIEnv = NULL;
	g_hMainWnd = NULL;
	return 0;
} 


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	POINT mouse;
	int wmId, wmEvent;

	if (g_clsCallBack == 0) return DefWindowProc(hWnd, message, wParam, lParam);

	switch (message)
	{
		case WM_COMMAND:
			if (g_JNIEnv != NULL)			
			{
				wmId    = LOWORD(wParam);
				wmEvent = HIWORD(wParam);
				if (wmId != 0xFF)
				{
					jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
					jmethodID method = g_JNIEnv->GetMethodID(cls,"menuClicked","(I)V");
					if (method != 0)
						g_JNIEnv->CallVoidMethod(g_clsCallBack,method,wmId);
				}
			}
			break;

        case JTRAY_NOTIFICATION:
			switch (lParam)
			{
				case WM_MBUTTONDBLCLK:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mouseClicked","(IIIIZ)V");
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[2],mouse.x,mouse.y,2,JNI_FALSE);
					}
				case WM_MBUTTONDOWN:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mousePressed","(IIIIZ)V");
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[2],mouse.x,mouse.y,0,JNI_FALSE);
					}
					break;

				case WM_MBUTTONUP:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mouseReleased","(IIIIZ)V");
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[2],mouse.x,mouse.y,1,JNI_FALSE);
						method = g_JNIEnv->GetMethodID(cls,"mouseClicked","(IIIIZ)V");
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[2],mouse.x,mouse.y,1,JNI_FALSE);
					}
					break;

				case WM_RBUTTONDBLCLK:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mouseClicked","(IIIIZ)V");
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[1],mouse.x,mouse.y,2,JNI_FALSE);
					}
				case WM_RBUTTONDOWN:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mousePressed","(IIIIZ)V");
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[1],mouse.x,mouse.y,0,JNI_FALSE);
					}
					break;

				case WM_RBUTTONUP:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mouseReleased","(IIIIZ)V");
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[1],mouse.x,mouse.y,1,JNI_FALSE);
						method = g_JNIEnv->GetMethodID(cls,"mouseClicked","(IIIIZ)V");
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[1],mouse.x,mouse.y,1,JNI_FALSE);
					}
					break;

				case WM_LBUTTONDBLCLK:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mouseClicked","(IIIIZ)V");
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[0],mouse.x,mouse.y,2,JNI_FALSE);
					}
				case WM_LBUTTONDOWN:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mousePressed","(IIIIZ)V");
			            SetForegroundWindow(g_hMainWnd);
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[0],mouse.x,mouse.y,0,JNI_FALSE);
					}
					break;
				case WM_LBUTTONUP:
					if (g_JNIEnv != NULL)
					{
						jclass cls = g_JNIEnv->GetObjectClass(g_clsCallBack);
						jmethodID method = g_JNIEnv->GetMethodID(cls,"mouseReleased","(IIIIZ)V");
			            SetForegroundWindow(g_hMainWnd);
		                GetCursorPos(&mouse);
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[0],mouse.x,mouse.y,1,JNI_FALSE);
						method = g_JNIEnv->GetMethodID(cls,"mouseClicked","(IIIIZ)V");
						if (method != 0)
							g_JNIEnv->CallVoidMethod(g_clsCallBack,method,g_JavaMEvents[0],mouse.x,mouse.y,1,JNI_FALSE);
					}
					break;
			}
			break;
		case WM_DESTROY:
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}


JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_initTrayIcon(JNIEnv *env, jobject obj)
{

	if (g_hThread != NULL) return; // Only do this once!

	jclass MouseEventCls = env->FindClass("org/homedns/krolain/plaf/event/TrayIconEvent");
	if (MouseEventCls != 0)
	{
		for (int i = 0; i < 3; i++)
		{
			jfieldID fid = env->GetStaticFieldID(MouseEventCls,(TCHAR *)g_szMEvents[i],"I");
			if (fid != 0)
				g_JavaMEvents[i] = env->GetStaticIntField(MouseEventCls,fid);
		}
	}

	g_clsCallBack = env->NewGlobalRef(obj);
	env->GetJavaVM(&g_pJavaVM);

	g_hThread = CreateThread( 
        NULL,                        // no security attributes 
        0,                           // use default stack size  
        ThreadFunc,                  // thread function 
        &g_hThread,                // argument to thread function 
        0,                           // use default creation flags 
        &g_dwThreadID);                // returns the thread identifier 
}


JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_showTrayIcon(JNIEnv *env, jobject obj, jboolean bShow)
{
    NOTIFYICONDATA tnd;
    tnd.cbSize		= sizeof(NOTIFYICONDATA);
    tnd.hWnd		= g_hMainWnd;
    tnd.uID			= JTRAYICON;
	BOOL bResult;
	
	if ((BOOL)bShow)
	{
		tnd.uFlags		= NIF_MESSAGE;
		tnd.uFlags		|= (g_hIcon != NULL)?NIF_ICON:0;
		tnd.uCallbackMessage	= JTRAY_NOTIFICATION;
		if (g_hIcon != NULL)
			tnd.hIcon		= g_hIcon;

		bResult = Shell_NotifyIcon(NIM_ADD, &tnd);
		bResult = Shell_NotifyIcon(NIM_MODIFY, &tnd);

		if (g_hIcon)
		{
			DestroyIcon(g_hIcon);
			g_hIcon = NULL;
		}

		g_bIconVisible = TRUE;
	}
	else
	{
		bResult = Shell_NotifyIcon(NIM_DELETE, &tnd);
		g_bIconVisible = FALSE;
		
	}
}

JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_removeTrayIcon(JNIEnv *env, jobject obj)
{
	if (g_hMainWnd != NULL)
	{
		Java_org_homedns_krolain_plaf_TrayIcon_showTrayIcon(env,obj,JNI_FALSE);
		PostMessage(g_hMainWnd,WM_CLOSE,NULL,NULL);
	}
}

JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_showNativeMenu(JNIEnv *env, jobject obj, jint x, jint y)
{
	if (g_hMenu != NULL)
	{
        SetForegroundWindow(g_hMainWnd);
		TrackPopupMenu(g_hMenu,0,x,y,0,g_hMainWnd,NULL);
	}
}

JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_setNativeMenuState(JNIEnv *env, jobject obj, jint iMenuID, jint iStates)
{
	MENUITEMINFO menuInfo;
	memset(&menuInfo,0,sizeof(MENUITEMINFO));
	menuInfo.cbSize = sizeof(MENUITEMINFO);

	if (GetMenuItemInfo(g_hMenu,iMenuID,FALSE,&menuInfo))
	{
		menuInfo.fMask |= MIIM_STATE;

		if ((iStates & TrayIcon_STATE_CHECK) == TrayIcon_STATE_CHECK)
			menuInfo.fState |= MFS_CHECKED;
		if ((iStates & TrayIcon_STATE_ENABLE) == TrayIcon_STATE_ENABLE)
			menuInfo.fState |= MFS_ENABLED;
		if ((iStates & TrayIcon_STATE_UNCHECK) == TrayIcon_STATE_UNCHECK)
			menuInfo.fState |= MFS_UNCHECKED;
		if ((iStates & TrayIcon_STATE_GRAYED) == TrayIcon_STATE_GRAYED)
			menuInfo.fState |= MFS_GRAYED;

		SetMenuItemInfo(g_hMenu,iMenuID,FALSE,&menuInfo);
	}

}


JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_createNativeMenu(JNIEnv *env, jobject obj)
{
	if (g_hMenu != NULL) 
	{
		int iSize = GetMenuItemCount(g_hMenu);
		for (int i = 0; i < iSize; i++)
			DeleteMenu(g_hMenu,0,MF_BYPOSITION);
	}
	else
	{
		g_hMenu = CreatePopupMenu();
		g_MenuStack[0] = g_hMenu;
	}

	g_MenuLevel = 0;
}

JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_addNativeMenuItem(JNIEnv *env, jobject obj, jstring szLabel, jint MenuID, jint menuType)
{
	if (g_MenuLevel == -1) return;

	MENUITEMINFO menuInfo;
	UINT uItem = MenuID;
	BOOL bByPos = FALSE;
	char *szString = NULL;

	if (szLabel != NULL)
	{
		jsize len = env->GetStringLength(szLabel);
		const jchar *bytes = env->GetStringChars(szLabel,NULL);
		int iSize = WideCharToMultiByte(CP_ACP,0,bytes,len,NULL,0,NULL,NULL);
		szString = new char[iSize+1];
		WideCharToMultiByte(CP_ACP,0,bytes,len,szString,iSize+1,NULL,NULL);
		szString[iSize] = '\0';
	}
	else
	{
		szString = new char[1];
		szString[0] = '\0';
	}

	memset(&menuInfo,0,sizeof(MENUITEMINFO));
	menuInfo.cbSize = sizeof(MENUITEMINFO);
	menuInfo.fMask = MIIM_TYPE | MIIM_ID;
	switch (menuType)
	{
		case -1: // Indicates a submenu
			menuInfo.fMask |= MIIM_SUBMENU;
			menuInfo.fType = MFT_STRING;
			menuInfo.dwTypeData = szString;
			menuInfo.wID = 0xFF;
			bByPos = TRUE;
			uItem = -1;
			menuInfo.hSubMenu = g_MenuStack[g_MenuLevel+1];
			break;
		case TrayIcon_MENU_ITEM:
		case TrayIcon_MENU_CHECK:
			menuInfo.fType = MFT_STRING;
			menuInfo.dwTypeData = szString;
			menuInfo.wID = MenuID;
			break;
		case TrayIcon_MENU_SEPARATOR:
			menuInfo.fType = MFT_SEPARATOR;
			menuInfo.wID = 0xFF;
			break;
		case TrayIcon_MENU_RADIO:
			menuInfo.fType = MFT_STRING | MFT_RADIOCHECK;
			menuInfo.dwTypeData = szString;
			menuInfo.wID = MenuID;
			break;
	}

	InsertMenuItem(g_MenuStack[g_MenuLevel],uItem,bByPos,&menuInfo);
}

JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_startNativeSubMenu(JNIEnv *env, jobject obj, jstring jszLabel)
{
	if (g_MenuLevel == -1) return;

	if (g_MenuLevel < 9)
	{
		g_MenuStack[g_MenuLevel+1] = CreateMenu();

		Java_org_homedns_krolain_plaf_TrayIcon_addNativeMenuItem(env,obj,jszLabel,-1,-1);
		g_MenuLevel ++;
	}
}

JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_endNativeSubMenu(JNIEnv *env, jobject obj)
{
	if (g_MenuLevel == -1) return;

	if (g_MenuLevel > 0)
		g_MenuLevel --;
}

JNIEXPORT void JNICALL Java_org_homedns_krolain_plaf_TrayIcon_setTrayIcon(JNIEnv *env, jobject obj, jintArray pixels, jint width, jint height)
{
	BOOL bResult = FALSE;

	HBITMAP hBitmapXOR = NULL;	// Colors
	HBITMAP	hBitmapAND = NULL;	// Transparancy info

	if (width > 0 && height > 0) {
	    // Set up the header for creating our 24 bit colour bitmap
	   	BITMAPINFOHEADER bih;
	    bih.biSize          = sizeof(BITMAPINFOHEADER);
	   	bih.biWidth         = width;
	    bih.biHeight        = height;
	    bih.biPlanes        = 1;
	   	bih.biBitCount      = 24;
	   	bih.biCompression   = BI_RGB;
	   	bih.biSizeImage     = 0;
	   	bih.biXPelsPerMeter = 0;
	   	bih.biYPelsPerMeter = 0;
	   	bih.biClrUsed       = 0;
	   	bih.biClrImportant  = 0;

		jint * iPixels = env->GetIntArrayElements(pixels,NULL);

	   	// Create memory DC
	   	HDC hdc = CreateCompatibleDC(NULL);
	   	// Make the 24-bit DIB
	   	hBitmapXOR = CreateDIBSection(hdc, (LPBITMAPINFO)&bih, DIB_RGB_COLORS, (LPVOID *)NULL, NULL, 0);
	   	// Select it into the DC so we can draw onto it
	   	SelectObject(hdc, hBitmapXOR);

		long size = (width*height/8)+1;
	   	unsigned char *andMask = new unsigned char[size];

		if (andMask != NULL) {
			for (int i = 0; i < size; i++) andMask[i] = 0;
			// Loop through the given pixels and draw onto the colour and mono bitmaps
			unsigned long pixel;
	        unsigned char red, green, blue, alpha;
	        for (int row = 0; row < height; row++) {
    			for (int col = 0; col < width; col++) {
	       			pixel = iPixels[(row*width)+col];
	           		alpha = (unsigned char)((pixel >> 24) & 0x000000ff);
	           		red   = (unsigned char)((pixel >> 16) & 0x000000ff);
	                green = (unsigned char)((pixel >>  8) & 0x000000ff);
	                blue  = (unsigned char)( pixel        & 0x000000ff);
	      		    if (alpha == 0xFF) {
						// Pixel is not transparent - update xor bitmap
					    SetPixel(hdc, col, row, RGB(red, green, blue));
					} else {
						// Pixel is transparent - update and mask
						int p = (row*width) + col;
						andMask[p/8] |= 1 << (7-(p%8));
						SetPixel(hdc, col, row, RGB(0, 0, 0));
					}
				}
			}
			// Create the monochrome bitmask with transparency info
			hBitmapAND = CreateBitmap(width, height, 1, 1, andMask);
			// Free memory
			delete andMask;
		}
		// Release the memory DC
		DeleteDC(hdc);
	}

	if ((hBitmapXOR != NULL) && (hBitmapAND != NULL))
	{
        ICONINFO ii;
        ii.fIcon    = TRUE;
        ii.xHotspot = 0;
        ii.yHotspot = 0;
        ii.hbmMask  = hBitmapAND;
        ii.hbmColor = hBitmapXOR;
        g_hIcon = CreateIconIndirect(&ii);

		if ((g_hIcon != NULL) && g_bIconVisible)
		{
			NOTIFYICONDATA tnd;
			tnd.cbSize		= sizeof(NOTIFYICONDATA);
			tnd.hWnd		= g_hMainWnd;
			tnd.uID			= JTRAYICON;

			tnd.uFlags		= NIF_ICON;
			tnd.hIcon		= g_hIcon;

			bResult = Shell_NotifyIcon(NIM_MODIFY, &tnd);

			DestroyIcon(g_hIcon);
			g_hIcon = NULL;
		}
	}
	if (hBitmapAND != NULL) DeleteObject(hBitmapAND);
	if (hBitmapXOR != NULL) DeleteObject(hBitmapXOR);
}
