/*
 * JLJ.java
 *
 * Created on June 24, 2002, 9:53 PM
 */

/**
 *
 * @author  krolain
 */
package org.homedns.krolain.MochaJournal;
import org.homedns.krolain.MochaJournal.LJData.*;
import org.homedns.krolain.MochaJournal.LJData.LJFriends.Birthday;
import org.homedns.krolain.MochaJournal.Panels.LJPanel;
import org.homedns.krolain.MochaJournal.Panels.HistPanel.HistPanel;
import org.homedns.krolain.MochaJournal.Protocol.*;
import org.homedns.krolain.swing.*;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.LookAndFeel;
import com.oyoaha.swing.plaf.oyoaha.*;
import org.homedns.krolain.MochaJournal.FriendGroupDlg.PrivacyDialog;
import com.l2fprod.gui.plaf.skin.*;
import javax.swing.JRootPane;
import javax.swing.*;
import javax.swing.plaf.metal.MetalLookAndFeel;
import java.awt.event.KeyEvent;
import org.homedns.krolain.util.InstallInfo;
import org.homedns.krolain.swing.JCheckUpdate;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import org.homedns.krolain.plaf.*;
import org.homedns.krolain.plaf.event.TrayIconEvent;
import org.homedns.krolain.MochaJournal.Panels.*;
import java.util.*;
import javax.swing.JOptionPane;

public class EntryFrame extends javax.swing.JFrame implements Cloneable, TrayIconListener, LoginListener {

    private static final String m_szHelpFile = "intro.htm";
    private static final String m_szContentFile = "help.cnt";
    
    public static boolean m_bOnline = true;
    
    javax.swing.JMenu m_WebMenu = null;
    LogoutListener m_LogListen = null;
    java.util.Timer m_Timer = null;
    JLJSettings m_Settings = null;
    boolean m_bShown = false;
    int m_iInterval = 0;
    XMLProtocol m_Prot_Timer = null;
    XMLProtocol m_Prot = null;
    javax.swing.Icon m_NewPostU = null;
    javax.swing.Icon m_NewPostX = null;
    javax.swing.Icon m_BirthdayU = null;
    javax.swing.Icon m_BirthdayX = null;
    Object m_szLastUpdate = null;
    boolean m_bNewFriendEntries = false;
    LJGroups m_Groups = null;
    LJFriends m_Friends = null;
    Birthday[] m_Birthdays = null;
    public TrayIcon m_Tray = null;
    private javax.swing.JMenu m_WebTray = null;
    boolean m_bTrayHidden;
    LJeventsTable m_EventItems = null;
    LoginDlg loginDlg = null;
    boolean m_bConnected = false;
    XMLlogin m_LoginInfo = null;
    
    
    public ImageIcon[] m_PicKWIcon = null; // We store the LJ user icons here since they only need to be loaded once per session.
    File[] m_PicKWCaheFile = null;
    
    class CheckFriendTimerTask extends java.util.TimerTask
    {
        EntryFrame m_Frame = null;

        public CheckFriendTimerTask(EntryFrame frame)
        {
            m_Frame = frame;
        }

        public void run() {
            XMLcheckfriends check = m_Prot_Timer.checkFriends(m_Frame.m_szLastUpdate,-1);
            if (check.m_bSentOK)
            {
                m_Frame.m_szLastUpdate = check.m_lastupdate;
                if (check.m_new.intValue() == 1)
                {
                    if (m_Frame.m_Timer != null)
                    {
                        m_Frame.m_Timer.cancel();
                        m_Frame.m_Timer = null;
                    }
                    m_Frame.jNewPost.setIcon(m_NewPostU);
                    m_Frame.jNewPost.setToolTipText(InstallInfo.getString("tooltip.new.post"));
                    m_Frame.m_bNewFriendEntries = true;
                }
                else
                {
                    if (m_Frame.m_Timer == null)
                    {
                        m_Frame.m_Timer = new java.util.Timer(true);
                        m_Frame.m_iInterval = check.m_interval.intValue() * 1000;
                        m_Frame.m_Timer.scheduleAtFixedRate(new CheckFriendTimerTask(m_Frame),m_Frame.m_iInterval,m_Frame.m_iInterval);
                    }
                    m_Frame.jNewPost.setIcon(m_NewPostX);
                    m_Frame.jNewPost.setToolTipText(InstallInfo.getString("tooltip.no.post"));
                    m_Frame.m_bNewFriendEntries = false;
                }
            }
        }
    }
    
    /** Creates new form JLJ */    
    public EntryFrame() {
        m_Settings = JLJSettings.GetSettings();
        m_NewPostU = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/new_post_u.gif"));
        m_NewPostX = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/new_post_x.gif"));
        m_BirthdayU = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/birthday_u.gif"));
        m_BirthdayX = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/birthday_x.gif"));
        getRootPane().setWindowDecorationStyle(javax.swing.JRootPane.FRAME);
        initComponents();
        
        setSize(m_Settings.m_MainWndRect.width,m_Settings.m_MainWndRect.height);
        setLocation(m_Settings.m_MainWndRect.x,m_Settings.m_MainWndRect.y);

        ImageIcon ico = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/mochapen16.gif"));
        try
        {
            m_Tray = new TrayIcon(InstallInfo.getInstallPath()+"Library");
            m_Tray.setIcon(ico.getImage(), ico.getIconWidth(),ico.getIconHeight());
        } catch (java.lang.UnsatisfiedLinkError e) { System.out.println(e);}

        setIconImage(ico.getImage());
        m_bTrayHidden = false;
    }

    public Object clone()
    {
        EntryFrame frame = new EntryFrame();
        frame.m_WebMenu = m_WebMenu;
        frame.m_LogListen = m_LogListen;
        frame.m_bShown = m_bShown;
        frame.m_iInterval = m_iInterval;
        frame.m_Prot_Timer = m_Prot_Timer;
        frame.m_Prot = m_Prot;
        frame.m_szLastUpdate = m_szLastUpdate;
        frame.m_bNewFriendEntries = m_bNewFriendEntries;
        frame.setGroups(m_Groups);
        frame.m_Friends = m_Friends;
        frame.m_Birthdays = m_Birthdays;
        frame.m_PicKWIcon = m_PicKWIcon;
        frame.m_bTrayHidden = m_bTrayHidden;
        frame.m_WebTray = m_WebTray;
        frame.m_Tray = m_Tray;
        frame.m_bConnected = m_bConnected;
        frame.m_LoginInfo = m_LoginInfo;
        frame.loginDlg = loginDlg;
        
        if (frame.m_LoginInfo != null)
            frame.handleLogin(frame.m_LoginInfo);

        if (frame.m_Tray != null)
            frame.m_Tray.addTrayListner(frame);

        if (m_Timer != null)
        {
            m_Timer.cancel();
            m_Timer = null;
        }
        if ((m_Settings.m_bPolling) && (frame.m_Prot_Timer != null))
        {
            if (frame.m_iInterval == 0)
            {
                java.util.Timer timer = new java.util.Timer(false);
                timer.schedule(new CheckFriendTimerTask(frame),50);
            }
            else
            {
                frame.m_Timer = new java.util.Timer(true);
                frame.m_Timer.scheduleAtFixedRate(new CheckFriendTimerTask(frame),frame.m_iInterval,frame.m_iInterval);
            }
        }
        
        return frame;
    }
    
    public boolean isTrayHidden()
    {
        return m_bTrayHidden;
    }
    
    public void setProtocol (XMLProtocol prot)
    {
        m_Prot = prot;
    }
    
    public void addLogoutListener(LogoutListener logListen)
    {
        m_LogListen = logListen;
    }
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        java.awt.GridBagConstraints gridBagConstraints;
        javax.swing.JSeparator jSeparator1;
        javax.swing.JSeparator jSeparator3;
        javax.swing.JSeparator jSeparator4;
        javax.swing.JSeparator jSeparator5;

        jHelpMenu = new javax.swing.JMenu();
        jContentItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jAboutItem = new javax.swing.JMenuItem();
        jToolMenu = new javax.swing.JMenu();
        jOptionItem = new javax.swing.JMenuItem();
        jPrivateItem = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JSeparator();
        jArchive = new javax.swing.JMenuItem();
        jExport = new javax.swing.JMenuItem();
        jDelCookie = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JSeparator();
        jUpdate = new javax.swing.JMenuItem();
        jTrayMenu = new javax.swing.JMenu();
        jOptionITray = new javax.swing.JMenuItem();
        jPrivateTray = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        jUpdateTray = new javax.swing.JMenuItem();
        jLogoutTray = new javax.swing.JMenuItem();
        jExitTray = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jStatusField = new javax.swing.JTextField();
        jBday = new javax.swing.JLabel();
        jNewPost = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jFileMenu = new javax.swing.JMenu();
        jSeparator2 = new javax.swing.JSeparator();
        jLogoutItem = new javax.swing.JMenuItem();
        jOfflineItem = new javax.swing.JCheckBoxMenuItem();
        jExitItem = new javax.swing.JMenuItem();

        jHelpMenu.setMnemonic(KeyEvent.VK_H);
        jHelpMenu.setText(InstallInfo.getString("menu.help"));
        jHelpMenu.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        jContentItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        jContentItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/help.gif")));
        jContentItem.setMnemonic(KeyEvent.VK_C);
        jContentItem.setText(InstallInfo.getString("menu.content"));
        jContentItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jContentItemActionPerformed(evt);
            }
        });

        jHelpMenu.add(jContentItem);

        jHelpMenu.add(jSeparator1);

        jAboutItem.setMnemonic(KeyEvent.VK_A);
        jAboutItem.setText(InstallInfo.getString("menu.about"));
        jAboutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAboutItemActionPerformed(evt);
            }
        });

        jHelpMenu.add(jAboutItem);

        jToolMenu.setMnemonic(KeyEvent.VK_T);
        jToolMenu.setText(InstallInfo.getString("menu.tool"));
        jOptionItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.ALT_MASK));
        jOptionItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/setup.gif")));
        jOptionItem.setMnemonic(KeyEvent.VK_O);
        jOptionItem.setText(InstallInfo.getString("menu.options"));
        jOptionItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOptionItemActionPerformed(evt);
            }
        });

        jToolMenu.add(jOptionItem);

        jPrivateItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        jPrivateItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/moduser.gif")));
        jPrivateItem.setMnemonic(KeyEvent.VK_M);
        jPrivateItem.setText(InstallInfo.getString("menu.private"));
        jPrivateItem.setEnabled(false);
        jPrivateItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPrivateItemActionPerformed(evt);
            }
        });

        jToolMenu.add(jPrivateItem);

        jToolMenu.add(jSeparator5);

        jArchive.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/backup.gif")));
        jArchive.setMnemonic(KeyEvent.VK_B);
        jArchive.setText(InstallInfo.getString("menu.archive"));
        jArchive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jArchiveActionPerformed(evt);
            }
        });

        jToolMenu.add(jArchive);

        jExport.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/export.gif")));
        jExport.setMnemonic(KeyEvent.VK_E);
        jExport.setText(InstallInfo.getString("menu.export"));
        jExport.setEnabled(false);
        jExport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jExportActionPerformed(evt);
            }
        });

        jToolMenu.add(jExport);

        jDelCookie.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/offline.gif")));
        jDelCookie.setText("Expire All Cookies");
        jDelCookie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDelCookieActionPerformed(evt);
            }
        });

        jToolMenu.add(jDelCookie);

        jToolMenu.add(jSeparator4);

        jUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/update.gif")));
        jUpdate.setMnemonic(KeyEvent.VK_C);
        jUpdate.setText(InstallInfo.getString("menu.update"));
        jUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUpdateActionPerformed(evt);
            }
        });

        jToolMenu.add(jUpdate);

        jTrayMenu.setMnemonic(KeyEvent.VK_T);
        jTrayMenu.setText(InstallInfo.getString("menu.tool"));
        jOptionITray.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.ALT_MASK));
        jOptionITray.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/setup.gif")));
        jOptionITray.setMnemonic(KeyEvent.VK_O);
        jOptionITray.setText(InstallInfo.getString("menu.options"));
        jOptionITray.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOptionItemActionPerformed(evt);
            }
        });

        jTrayMenu.add(jOptionITray);

        jPrivateTray.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        jPrivateTray.setMnemonic(KeyEvent.VK_M);
        jPrivateTray.setText(InstallInfo.getString("menu.private"));
        jPrivateTray.setEnabled(false);
        jPrivateTray.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPrivateItemActionPerformed(evt);
            }
        });

        jTrayMenu.add(jPrivateTray);

        jTrayMenu.add(jSeparator3);

        jUpdateTray.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/update.gif")));
        jUpdateTray.setText(InstallInfo.getString("menu.update"));
        jUpdateTray.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUpdateActionPerformed(evt);
            }
        });

        jTrayMenu.add(jUpdateTray);

        jLogoutTray.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/logout.gif")));
        jLogoutTray.setMnemonic(KeyEvent.VK_L);
        jLogoutTray.setText(InstallInfo.getString("menu.logout"));
        jLogoutTray.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLogoutItemActionPerformed(evt);
            }
        });

        jTrayMenu.add(jLogoutTray);

        jExitTray.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        jExitTray.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/exit.gif")));
        jExitTray.setMnemonic(KeyEvent.VK_E);
        jExitTray.setText(InstallInfo.getString("menu.exit"));
        jExitTray.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jExitItemActionPerformed(evt);
            }
        });

        jTrayMenu.add(jExitTray);

        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                formComponentMoved(evt);
            }
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jPanel1.setLayout(new java.awt.GridBagLayout());

        jStatusField.setEditable(false);
        jStatusField.setBorder(new javax.swing.border.EtchedBorder());
        jStatusField.setOpaque(false);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jPanel1.add(jStatusField, gridBagConstraints);

        jBday.setIcon(m_BirthdayX);
        jBday.setBorder(new javax.swing.border.EtchedBorder());
        jBday.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBdayMouseClicked(evt);
            }
        });

        jPanel1.add(jBday, new java.awt.GridBagConstraints());

        jNewPost.setIcon(m_NewPostX);
        jNewPost.setToolTipText(InstallInfo.getString("tooltip.no.post"));
        jNewPost.setBorder(new javax.swing.border.EtchedBorder());
        jNewPost.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jNewPostMouseClicked(evt);
            }
        });

        jPanel1.add(jNewPost, new java.awt.GridBagConstraints());

        getContentPane().add(jPanel1, java.awt.BorderLayout.SOUTH);

        getContentPane().add(jTabbedPane1, java.awt.BorderLayout.CENTER);

        jFileMenu.setMnemonic(KeyEvent.VK_F);
        jFileMenu.setText(InstallInfo.getString("menu.file"));
        jFileMenu.add(jSeparator2);

        jLogoutItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, java.awt.event.InputEvent.ALT_MASK));
        jLogoutItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/logout.gif")));
        jLogoutItem.setMnemonic(KeyEvent.VK_L);
        jLogoutItem.setText(InstallInfo.getString("menu.logout"));
        jLogoutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLogoutItemActionPerformed(evt);
            }
        });

        jFileMenu.add(jLogoutItem);

        jOfflineItem.setText("Work Offline");
        jOfflineItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOfflineItemActionPerformed(evt);
            }
        });

        jFileMenu.add(jOfflineItem);

        jExitItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        jExitItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/exit.gif")));
        jExitItem.setMnemonic(KeyEvent.VK_E);
        jExitItem.setText(InstallInfo.getString("menu.exit"));
        jExitItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jExitItemActionPerformed(evt);
            }
        });

        jFileMenu.add(jExitItem);

        jMenuBar1.add(jFileMenu);

        setJMenuBar(jMenuBar1);

    }//GEN-END:initComponents

    private void jDelCookieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDelCookieActionPerformed
        XMLsessionexp exp = m_Prot.Sessionexpire(null,true);
    }//GEN-LAST:event_jDelCookieActionPerformed

    private void jOfflineItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOfflineItemActionPerformed
        m_bOnline = !jOfflineItem.isSelected();

        JLJSettings settings = JLJSettings.GetSettings();
        String unamepwd[];
        unamepwd = loginDlg.getLoginInfo();

        if (m_bOnline)
        {
            if (unamepwd[1].length() < 1)
            {
                javax.swing.JPasswordField pf = new javax.swing.JPasswordField();
                JOptionPane pane = new JOptionPane(pf, JOptionPane.PLAIN_MESSAGE,JOptionPane.OK_CANCEL_OPTION);
                JDialog dlg = pane.createDialog(this, "Enter your password for: "+m_Prot.getUserName());
                dlg.show();
                Object obj = pane.getValue();
                if (obj == null) 
                {
                    m_bOnline = false;
                    jOfflineItem.setSelected(true);
                    return;
                }
                if (obj instanceof Integer)
                {
                    int iVal = ((Integer)obj).intValue();
                    if (iVal == pane.CANCEL_OPTION) 
                    {
                        m_bOnline = false;
                        jOfflineItem.setSelected(true);
                        return;
                    }
                        
                }
                else
                {
                    m_bOnline = false;
                    jOfflineItem.setSelected(true);
                    return;
                }
                unamepwd[1] = new String(pf.getPassword());
            }
        }
        
        XMLlogin login = m_Prot.LogIn(unamepwd[0],unamepwd[1],(settings.m_Moods == null)?0:settings.m_Moods.getMaxMoodID());

        if (login != null)
            handleLogin(login);
        else
        {
            javax.swing.JOptionPane.showMessageDialog(this,InstallInfo.getString("string.error.no.connect"),InstallInfo.getString("app.title"),javax.swing.JOptionPane.INFORMATION_MESSAGE);
            m_bConnected = false;
            m_bOnline = false;
        }

        jUpdate.setEnabled(m_bOnline);
        jArchive.setEnabled(m_bOnline);
        jPrivateTray.setEnabled(m_bOnline);
        jUpdateTray.setEnabled(m_bOnline);

        if (m_bOnline)
        {
            m_Friends = m_Prot.getFriends().getFriends(); // No need to do this until we need it during login.
            m_Birthdays = m_Friends.getBDayList();
            checkBirthdays();
            
            if (m_WebTray != null)
            {
                jTrayMenu.add(m_WebTray,2);
                jTrayMenu.add(new javax.swing.JSeparator(),2);
            }
        }
        else
        {
            jTrayMenu.remove(2);
            jTrayMenu.remove(2);
            m_Friends = m_Prot.loadFriends();
            if (m_Friends != null)
                m_Birthdays = m_Friends.getBDayList();
            else
                m_Birthdays = null;
            checkBirthdays();
            jNewPost.setIcon(m_NewPostX);
            m_bNewFriendEntries = false;
            
        }
        if (m_Tray != null)
            m_Tray.setMenu(jTrayMenu);


        
        
        if (m_Settings.m_bPolling && m_bOnline)
        {
            if (m_Timer == null)
            {
                if (m_iInterval > 0)
                {
                    m_Timer = new java.util.Timer(true);
                    m_Timer.scheduleAtFixedRate(new CheckFriendTimerTask(this),m_iInterval,m_iInterval);
                }
                else
                {
                    java.util.Timer timer = new java.util.Timer(false);
                    timer.schedule(new CheckFriendTimerTask(this),50);
                }
            }
        }
        else
        {
            if (m_Timer != null)
            {
                m_Timer.cancel();
                m_Timer = null;
            }
        }
        
    }//GEN-LAST:event_jOfflineItemActionPerformed

    private void jExportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jExportActionPerformed
        String szUname = null;
        szUname = m_Prot.getUserName();
        if (m_EventItems == null)
        {
            String szPath = System.getProperty("user.home");
            szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+szUname+System.getProperty("file.separator")+"backup.xml";
            File backup = new File(szPath);
            if (backup.exists())
            {
                try
                {
                    java.beans.XMLDecoder decode = new java.beans.XMLDecoder(new java.io.FileInputStream(backup));
                    m_EventItems = (LJeventsTable) decode.readObject();
                    decode.close();
                } catch (java.io.FileNotFoundException e) { System.err.println(e); }
                catch (java.io.IOException e) { System.err.println(e); }
                catch (java.lang.Exception e) { System.err.println(e); }
            }
        }
        if (m_EventItems != null)
        {
            m_EventItems.exportEvents(szUname,new HTMLExport(true,this),this);
        }

    }//GEN-LAST:event_jExportActionPerformed

    private void jArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jArchiveActionPerformed
        if (!m_bOnline)
        { // This is for testing purposes only.
            m_EventItems = new LJeventsTable();
            OldEventInfo nfo = new OldEventInfo();
            nfo.m_iItemID = 1;
            nfo.m_szEvent = "This is only a test";
            m_EventItems.addItem(nfo);
            nfo = new OldEventInfo();
            nfo.m_iItemID = 2;
            nfo.m_szEvent = "This is only a test also";
            m_EventItems.addItem(nfo);
            String szPath = System.getProperty("user.home");
            szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Prot.getUserName();//+System.getProperty("file.separator")+"Draft";
            File file = new File(szPath);
            file.mkdirs();
            java.io.File backup = new File(file,"backup.xml");

            try
            {
                if (!backup.exists()) backup.createNewFile();
                java.beans.XMLEncoder encode = new java.beans.XMLEncoder(new java.io.FileOutputStream(backup));
                encode.writeObject(m_EventItems);
                encode.flush();
                encode.close();
            } catch (java.io.FileNotFoundException e) { System.err.println(e); }
              catch (java.io.IOException e) { System.err.println(e); }
        }
        else
        {
            if (m_EventItems == null)
            {
                String szPath = System.getProperty("user.home");
                szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Prot.getUserName()+System.getProperty("file.separator")+"backup.xml";
                File backup = new File(szPath);
                if (backup.exists())
                {
                    try
                    {
                        java.beans.XMLDecoder decode = new java.beans.XMLDecoder(new java.io.FileInputStream(backup));
                        m_EventItems = (LJeventsTable) decode.readObject();
                        decode.close();
                    } catch (java.io.FileNotFoundException e) { System.err.println(e); }
                        catch (java.io.IOException e) { System.err.println(e); }
                    catch (java.lang.Exception e) { System.err.println(e); }
                }
                else
                    m_EventItems = new LJeventsTable();
            }
            String szLastSync = null;
            szLastSync = m_EventItems.getLastEntryDate();
            LJsyncTable syncTable = new LJsyncTable();
            boolean bGotAll = false;
            while (!bGotAll)
            {
                XMLsyncItems syncItems = m_Prot.XMLsyncItems(szLastSync);
                syncTable.addAllSyncItems(syncItems);
                szLastSync = syncTable.syncFrom();
                bGotAll = (syncItems.m_count.intValue() == syncItems.m_total.intValue());
            }
            syncTable.sort();
            while (syncTable.hasMoreUpdates())
            {
                XMLgetEvents events = m_Prot.XMLdnldEntries(syncTable.downloadFrom(), null);
                m_EventItems.addItems(events.getList());
                syncTable.updateItems(events.getList());
            }
            
            XMLsessiongen gen = m_Prot.genSession("long", false);
            if (gen.m_bSentOK)
            {
                XMLcomments meta,comment;
                meta = m_Prot.getComments(0,gen.m_ljsession,null,"meta");
                while (meta.m_iMaxMetaID != meta.m_iMaxMetaIDSent)
                    m_Prot.getComments(meta.m_iMaxMetaIDSent+1, gen.m_ljsession,meta,"meta");

                m_EventItems.addCommentPosters(meta.m_userMap);
                m_EventItems.updateComments(meta.m_Comment);
                
                if (m_EventItems.getCommentID() != meta.m_iMaxMetaID)
                {
                    int iStartID = m_EventItems.getCommentID()+1;
                    comment = m_Prot.getComments(m_EventItems.getCommentID()+1,gen.m_ljsession,null,"body");
                    
                    while ((comment.m_iMaxMetaIDSent != meta.m_iMaxMetaID) ||
                           ((iStartID == comment.m_iMaxMetaIDSent) && (iStartID + 1000 < meta.m_iMaxMetaID)))
                    {
                        iStartID = comment.m_iMaxMetaIDSent;
                        m_Prot.getComments(comment.m_iMaxMetaIDSent+1,gen.m_ljsession,comment,"body");
                    }
                    m_EventItems.addComments(comment.m_Comment);
                }

                String[] cookie = new String[1];
                cookie[0] = gen.m_ljsession;
                XMLsessionexp exp = m_Prot.Sessionexpire(cookie,false);
            }
            
            String szPath = System.getProperty("user.home");
            szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Prot.getUserName();
            File file = new File(szPath);
            file.mkdirs();
            java.io.File backup = new File(file,"backup.xml");
            try
            {
                if (!backup.exists()) backup.createNewFile();
                java.beans.XMLEncoder encode = new java.beans.XMLEncoder(new java.io.FileOutputStream(backup));
                encode.writeObject(m_EventItems);
                encode.close();
                jExport.setEnabled(true);
            } catch (java.io.FileNotFoundException e) { System.err.println(e); }
              catch (java.io.IOException e) { System.err.println(e); }
             catch (java.lang.Exception e) { System.err.println(e) ; }
        }
        
    }//GEN-LAST:event_jArchiveActionPerformed

    private void jUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jUpdateActionPerformed
        JCheckUpdate.CheckUpdate(this,"http://mochajournal.sourceforge.net/",LJMenus.getBrowser());
    }//GEN-LAST:event_jUpdateActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        if (m_Tray != null)
            m_Tray.removeTrayListner(this);
        if (m_WebTray != null)
        {
            jTrayMenu.remove(2);
            jTrayMenu.remove(2);
            m_WebTray = null;
        }
    }//GEN-LAST:event_formWindowClosed

    private void formComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentMoved
        m_Settings.m_MainWndRect.x = getLocation().x;
        m_Settings.m_MainWndRect.y = getLocation().y;
        
    }//GEN-LAST:event_formComponentMoved

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        m_Settings.m_MainWndRect.width = getSize().width;
        m_Settings.m_MainWndRect.height = getSize().height;
    }//GEN-LAST:event_formComponentResized

    private void jContentItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jContentItemActionPerformed
        showHelp(this);
    }//GEN-LAST:event_jContentItemActionPerformed

    private void jBdayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBdayMouseClicked
        if ((evt.getClickCount() == 2) && (m_Birthdays != null))
        {
            BDayDlg dlg = new BDayDlg(this, true,m_Birthdays);
            dlg.setLocationRelativeTo(this);
            dlg.show();
        }
    }//GEN-LAST:event_jBdayMouseClicked

    private void jPrivateItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPrivateItemActionPerformed
        PrivacyDialog.showDialog(this,m_Groups,m_Friends,m_Prot);
        m_Prot.saveGroups(m_Groups);
        m_Prot.saveFriends(m_Friends);
        m_Birthdays = m_Friends.getBDayList();
        checkBirthdays();
    }//GEN-LAST:event_jPrivateItemActionPerformed

    private void jNewPostMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jNewPostMouseClicked
        // Add your handling code here:
        if (LJMenus.isBrowserSet() && (evt.getClickCount() == 2) && m_bNewFriendEntries)
        {
            org.homedns.krolain.util.NativeSystem.launchBrowser(LJMenus.getBrowser(),"http://www.livejournal.com/users/"+m_Prot.getUserName()+"/friends/");
            jNewPost.setIcon(m_NewPostX);
            jNewPost.setToolTipText(InstallInfo.getString("tooltip.no.post"));
            m_bNewFriendEntries = false;
            if (m_Timer == null)
            {
                m_Timer = new java.util.Timer(true);
                m_Timer.scheduleAtFixedRate(new CheckFriendTimerTask(this),m_iInterval,m_iInterval);
            }
        }
    }//GEN-LAST:event_jNewPostMouseClicked

    public void showOption(java.awt.Frame frame)
    {
        SetupDlg dlg = new SetupDlg(frame,true);
        dlg.setPollingOn(m_Settings.m_bPolling);
        dlg.setBrowser(LJMenus.getBrowser());
        dlg.setLookFeelIndex(m_Settings.m_iLookFeelIdx);
        dlg.setSelectedLookFeel(m_Settings.m_szLookFeelFile);
        dlg.setProxySettings(m_Settings.m_Proxy);
        dlg.setPollUpdate(m_Settings.m_bPollUpdate);
        int iResult = dlg.showDialog();
        if (iResult == SetupDlg.OK)
        {
            LJMenus.setBrowser(dlg.getBrowser());
            if (m_WebMenu != null)
            {
                if (LJMenus.isBrowserSet())
                    m_WebMenu.setEnabled(true);
                else
                    m_WebMenu.setEnabled(false);
            }
            m_Settings.m_bPolling = dlg.getPollingOn();
            if (m_Settings.m_bPolling && m_bOnline)
            {
                if ((m_Timer == null) && (m_iInterval > 0))
                {
                    m_Timer = new java.util.Timer(true);
                    m_Timer.scheduleAtFixedRate(new CheckFriendTimerTask(this),m_iInterval,m_iInterval);
                }
            }
            else
            {
                if (m_Timer != null)
                {
                    m_Timer.cancel();
                    m_Timer = null;
                }
            }
            m_Prot.setProxySettings(m_Settings.m_Proxy = dlg.getProxySettings());
            m_Settings.m_iLookFeelIdx = dlg.getLookFeelIndex();
            m_Settings.m_szLookFeelFile = dlg.getSelectedLookFeel();
            m_Settings.m_bPollUpdate = dlg.getPollUpdate();
            if (m_LogListen != null) m_LogListen.Reset();
        }
    }
    
    private void jOptionItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOptionItemActionPerformed
        showOption(this);
    }//GEN-LAST:event_jOptionItemActionPerformed

    public void show()
    {
        super.show();

        String szUname = null;
        
        szUname = m_Prot.getUserName();
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+szUname+System.getProperty("file.separator")+"backup.xml";
        File backup = new File(szPath);
        if (backup.exists())
            jExport.setEnabled(true);
        else
            jExport.setEnabled(false);
        
        jUpdate.setEnabled(m_bOnline);
        jArchive.setEnabled(m_bOnline);
        jPrivateTray.setEnabled(m_bOnline);
        jUpdateTray.setEnabled(m_bOnline);
        jPrivateItem.setEnabled(m_bOnline);
        
        jOfflineItem.setSelected(!m_bOnline);
        
        if (!m_bShown)
        {
            m_Prot_Timer = (XMLProtocol)m_Prot.clone();
            m_Prot_Timer.setParent(null);
            if (m_bOnline)
            {
                LJFriends savedFriends = m_Prot.loadFriends();
                m_Friends = m_Prot.getFriends().getFriends(); // No need to do this until we need it during login.
                if ((savedFriends != null) && (m_Friends != null))
                {
                    LJFriends.LJFriend[][] result = m_Friends.compareFriendOf(savedFriends);
                    if ((result[0].length > 0) || (result[1].length > 0))
                    {
                        JFriendOfDlg dlg = new JFriendOfDlg(this, true, result[0],result[1]);
                        dlg.show();
                    }
                }
            }
            else
                m_Friends = m_Prot.loadFriends();
            
            if (m_Friends != null)
                m_Birthdays = m_Friends.getBDayList();
            else
                m_Birthdays = null;
            
            checkBirthdays();

            if (m_Settings.m_bPollUpdate && m_bOnline)
            {
                java.lang.Thread check = new java.lang.Thread(new JCheckUpdate(this,false,"http://mochajournal.sourceforge.net/",LJMenus.getBrowser()));
                check.start();
            }
            if (m_Settings.m_bPolling && m_bOnline)
            {
                java.util.Timer timer = new java.util.Timer(false);
                timer.schedule(new CheckFriendTimerTask(this),50);
            }
            if (m_WebTray != null)
            {
                jTrayMenu.add(m_WebTray,2);
                jTrayMenu.add(new javax.swing.JSeparator(),2);
            }
            if (m_Tray != null)
            {
                m_Tray.setMenu(jTrayMenu);
                m_Tray.addTrayListner(this);
                m_Tray.show(true);
            }
            
            if (m_bOnline)
                sendPendingEntries();
            
            m_bShown = true;
        }
    }
    
    private class pendingFilter implements java.io.FileFilter
    {
        
        public boolean accept(File pathname) {
            if (pathname.isFile() && pathname.getName().endsWith(".xml")) return true;
            else return false;
        }
        
    }

    private class OfflineThread implements java.lang.Runnable
    {
        public File[] files = null;
        public javax.swing.JProgressBar bar = null;
        JDialog dlg = null;
        public void run() {
            for (int i = 0; i < files.length; i++)
            {
                bar.setValue(i);
                try
                {
                    java.beans.XMLDecoder decode = new java.beans.XMLDecoder(new java.io.FileInputStream(files[i]));
                    PostEventInfo event = (PostEventInfo)decode.readObject();
                    decode.close();
                    XMLpostEvent response = m_Prot.postEvent(event);
                    if (response.m_bSentOK)
                        files[i].delete();
                    else
                        JOptionPane.showMessageDialog(dlg,"Could not post your entry.\nIt will be uploaded next time you connect.","Posting offline entries.",JOptionPane.ERROR_MESSAGE);
                } catch (java.io.FileNotFoundException e) { System.err.println(e); }
                  catch (java.io.IOException e) { System.err.println(e); }
                  catch (java.lang.ClassCastException e) { System.err.println(e); }
            }
            dlg.dispose();
        }
        
    }
    
    private void sendPendingEntries()
    {
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Prot.getUserName()+System.getProperty("file.separator")+"Outbox";
        File pendingDir = new File(szPath);

        if (!pendingDir.exists()) return;
        
        File[] files = pendingDir.listFiles(new pendingFilter());
        if ((files == null) || (files.length < 1)) return;
        
        m_Prot.setParent(null);
        javax.swing.JProgressBar bar = new javax.swing.JProgressBar(0,files.length-1);
        bar.setValue(0);
        JOptionPane pane = new JOptionPane(bar,JOptionPane.INFORMATION_MESSAGE,JOptionPane.DEFAULT_OPTION,null,null);
        JDialog dlg = pane.createDialog(this, "Posting your offline entries...");
        dlg.setModal(true);
        OfflineThread otd = new OfflineThread();
        Thread td = new Thread(otd);
        otd.files = files;
        otd.bar = bar;
        otd.dlg = dlg;
        td.start();
        dlg.show();
        m_Prot.setParent(this);
    }
    
    private void jLogoutItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLogoutItemActionPerformed
        // Add your handling code here:
        setVisible(false);
        resetTab();
        dispose();
        m_bShown = false;
        m_EventItems = null;
        m_bConnected = false;
        if (m_LogListen != null)
            m_LogListen.LoggedIn();
    }//GEN-LAST:event_jLogoutItemActionPerformed

    private void jAboutItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAboutItemActionPerformed
        new About(this,true).show();
    }//GEN-LAST:event_jAboutItemActionPerformed

    private void jExitItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jExitItemActionPerformed
        setVisible(false);
        m_bConnected = false;
        resetTab();
        dispose();
        m_bShown = false;
        if (m_LogListen != null)
        {
            m_LogListen.SaveInfo();
            m_LogListen.Exit();
        }
    }//GEN-LAST:event_jExitItemActionPerformed

    private javax.swing.JMenu parseMenu(javax.swing.JMenu origMenu)
    {
        javax.swing.JMenu newMenu = new javax.swing.JMenu(origMenu.getText());
        int iSize = origMenu.getMenuComponentCount();
        for (int i = 0; i < iSize; i++)
        {
            Component comp = origMenu.getMenuComponent(i);
            if (comp instanceof javax.swing.JSeparator)
                newMenu.add(new javax.swing.JSeparator());
            else if (comp instanceof javax.swing.JMenu)
                newMenu.add(parseMenu((javax.swing.JMenu)comp));
            else if (comp instanceof javax.swing.JMenuItem)
            {
                javax.swing.JMenuItem item = new javax.swing.JMenuItem();
                item.setAction(((javax.swing.JMenuItem)comp).getAction());
                newMenu.add(item);
            }
        }
        return newMenu;
    }
    
    public void populateMenu(javax.swing.JMenu menu)
    {
        m_WebMenu = menu;
        if (menu != null)
            m_WebTray = parseMenu(menu);
    }
  
    public void resetTab()
    {
        int iSize = jTabbedPane1.getComponentCount();
        for (int i = 0; i < iSize; i++)
        {
            Component comp = jTabbedPane1.getComponentAt(i);
            if (comp instanceof LJPanel)
            {
                LJPanel p = (LJPanel)comp;
                if (p.getFileMenuItems() != null)
                {
                    javax.swing.JMenuItem[] items = p.getFileMenuItems();
                    int iMenuSize = items.length;
                    for (int i2 = 0; i2 < iMenuSize; i2++)
                        jFileMenu.remove(items[i2]);
                }
            }
        }
        jTabbedPane1.removeAll();
    }
    
    public void addTab(javax.swing.JComponent panel,String szTitle)
    {
        panel.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent e)
            {
                panelChanged(e);
            }
        });

        if (panel instanceof LJPanel)
        {
            LJPanel p = (LJPanel) panel;
            if (p.getFileMenuItems() != null)
            {
                javax.swing.JMenuItem[] items = p.getFileMenuItems();
                int iSize = items.length;
                for (int i = iSize-1; i > -1; i--)
                    jFileMenu.add(items[i],0);
            }
            jTabbedPane1.addTab(szTitle,p.getTabIcon(),panel);
        }
        else
            jTabbedPane1.addTab(szTitle,panel);
    }
    
    public void panelChanged (java.awt.event.ComponentEvent e)
    {
        Object obj = e.getSource();
        javax.swing.JMenuBar newBar = new javax.swing.JMenuBar();
        newBar.add(jMenuBar1.getMenu(0));
        if (obj instanceof LJPanel)
        {
            javax.swing.JMenu[] menus = ((LJPanel)obj).getMenu();
            for (int i = 0; i < menus.length; i++)
                newBar.add(menus[i]);
        }
        if ((m_WebMenu != null) && m_bOnline)
            newBar.add(m_WebMenu);
        newBar.add(jToolMenu);
        newBar.add(jHelpMenu);
        jMenuBar1 = newBar;
        setJMenuBar(newBar);
        if (m_WebMenu != null)
        {
            if (LJMenus.isBrowserSet())
                m_WebMenu.setEnabled(true);
            else
                m_WebMenu.setEnabled(false);
        }
        validate();
    }
    
    public void addNewPost()
    {
        int iComps = jTabbedPane1.getComponentCount();
        for (int i = 0; i < iComps; i++)
        {
            Object obj = jTabbedPane1.getComponentAt(i);
            if (obj instanceof HistPanel)
            {
                ((HistPanel)obj).addNewPost();
                break;
            }
        }
    }
    
    public void setStatus (String szText)
    {
        jStatusField.setText(szText);
    }
    
    public void checkBirthdays()
    {
        if (m_Birthdays == null)
        {
            jBday.setIcon(m_BirthdayX);
            return;
        }

        java.util.Calendar today = java.util.Calendar.getInstance();
        java.util.Calendar bDay = java.util.Calendar.getInstance();
        int iIndex;
        boolean bFound = false;
        for (iIndex = 0; iIndex < m_Birthdays.length; iIndex++)
        {
            bDay.setTime(m_Birthdays[iIndex].getBirthday());
            bFound = false;
            if (today.get(today.MONTH) > bDay.get(bDay.MONTH))
                continue;
            if (today.get(today.MONTH) == bDay.get(bDay.MONTH))
                bFound = true;
            
            if (bFound)
            {
                if (today.get(today.DAY_OF_MONTH) > bDay.get(bDay.DAY_OF_MONTH))
                    continue;
            
                if (today.get(today.DAY_OF_MONTH) != bDay.get(bDay.DAY_OF_MONTH))
                    bFound = false;
            }
            
            break;
        }
        if (bFound)
            jBday.setIcon(m_BirthdayU);
        else
            jBday.setIcon(m_BirthdayX);
        
        if (iIndex == m_Birthdays.length) iIndex = 0;
        if (iIndex == 0) return;

        if (iIndex > m_Birthdays.length / 2)
        {
            for (int i = m_Birthdays.length-1; i >= iIndex; i--)
            {
                Birthday day = m_Birthdays[m_Birthdays.length-1];
                for (int i2 = m_Birthdays.length-2; i2 > -1; i2 --)
                    m_Birthdays[i2+1] = m_Birthdays[i2];
                m_Birthdays[0] = day;
            }
            
        }
        else
        {
            for (int i = 0; i < iIndex; i++)
            {
                Birthday day = m_Birthdays[0];
                for (int i2 = 1; i2 < m_Birthdays.length; i2++)
                    m_Birthdays[i2-1] = m_Birthdays[i2];
                m_Birthdays[m_Birthdays.length-1] = day;
            }
        }
    }

    public void setGroups(LJGroups groups)
    {
        m_Groups = groups;
        if (groups != null)
        {
            jPrivateTray.setEnabled(true);
            jPrivateItem.setEnabled(true);
            int iSize = jTabbedPane1.getComponentCount();
            for (int i = 0; i < iSize; i++)
            {
                Component comp = jTabbedPane1.getComponentAt(i);
                if (comp instanceof EntryPanel)
                    ((EntryPanel)comp).populatePrivacy(groups);
                else if (comp instanceof HistPanel)
                    ((HistPanel)comp).m_Edit.populatePrivacy(groups);
            }
        }
    }

    public void loadPicKWIcons(Object[] PicKWUrl,Object[] PicKW)
    {
        int iNumPic;
        if (PicKWUrl != null)
            iNumPic = PicKWUrl.length;
        else
            iNumPic = PicKW.length;
        m_PicKWIcon = new ImageIcon[iNumPic];
        m_PicKWCaheFile = new File[iNumPic];
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Prot.getUserName()+System.getProperty("file.separator")+"Cache";
        java.io.File file = new java.io.File(szPath);
        if (!file.exists())
            file.mkdirs();
        
        for (int i= 0; i <iNumPic; i++)
        {
            try
            {
                m_PicKWCaheFile[i] = new File(file,(String)PicKW[i]);
                if (!m_PicKWCaheFile[i].exists() && m_bOnline)
                {
                    InputStream input = new java.net.URL((String)PicKWUrl[i]).openConnection().getInputStream();
                    OutputStream output = new FileOutputStream(m_PicKWCaheFile[i]);
                    cashePicKWIcon(input,output);
                }
                if (m_PicKWCaheFile[i].exists())
                {
                    ImageIcon imgsrc =  new ImageIcon(m_PicKWCaheFile[i].toURL());
                    BufferedImage img = new BufferedImage(imgsrc.getIconWidth()/2,imgsrc.getIconHeight()/2,BufferedImage.TYPE_INT_ARGB);
                    Graphics2D g = img.createGraphics();
                    g.scale(0.5,0.5);
                    g.drawImage(imgsrc.getImage(),0,0,imgsrc.getIconWidth(),imgsrc.getIconHeight(),null);
                    m_PicKWIcon[i] = new ImageIcon(img);
                }
                else
                    m_PicKWIcon[i] = null;
            } catch (java.net.MalformedURLException e) {}
              catch (IOException e) {} 
        }
    }

    private void cashePicKWIcon(InputStream in, OutputStream out)
    {
        try
        {
            int bytesCopied = 0;
            byte[] buffer = new byte[4096];
            int bytes;

            try
            {
                while ( (bytes = in.read( buffer )) != -1 )
		{
                    out.write( buffer, 0, bytes );
                    bytesCopied += bytes;
		}
            }
            finally
            {
                in.close();
		out.close();
            }            
        }
        catch (IOException e) {}
    }
    
    public void clearCache()
    {
        if (m_PicKWCaheFile == null) return;
        for (int i = 0; i < m_PicKWCaheFile.length; i++)
            m_PicKWCaheFile[i].delete();
    }

    public static void showHelp(javax.swing.JFrame parent)
    {
        java.util.Locale loc = java.util.Locale.getDefault();
        java.io.File url = new java.io.File(InstallInfo.getInstallPath()+"Help"+java.io.File.separator+loc.getLanguage()+java.io.File.separator+m_szHelpFile);
        java.io.File content = new java.io.File(InstallInfo.getInstallPath()+"Help"+java.io.File.separator+loc.getLanguage()+java.io.File.separator+m_szContentFile);
        if (!url.exists() || !content.exists())
        {
            url = new java.io.File(InstallInfo.getInstallPath()+"Help"+java.io.File.separator+m_szHelpFile);
            content = new java.io.File(InstallInfo.getInstallPath()+"Help"+java.io.File.separator+m_szContentFile);
        }
        if (url.exists() && content.exists())
        {
            try
            {
                JHelpPane.showHelpDialog(parent,content.toURL().toString(),LJMenus.getBrowser());
            } catch (java.net.MalformedURLException e)
            {
                System.err.println(e);
                // Show an error!
                javax.swing.JOptionPane.showMessageDialog(parent,InstallInfo.getString("string.error.no.help"),InstallInfo.getString("app.title"),javax.swing.JOptionPane.ERROR_MESSAGE);
            }
        }
        else
        {
            // Show an error!
            javax.swing.JOptionPane.showMessageDialog(parent,InstallInfo.getString("string.error.no.help"),InstallInfo.getString("app.title"),javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void TrayClicked(TrayIconEvent e) {
        if ((e.getClickCount() > 1) && (e.getButton() == e.BUTTON1))
        {
            m_bTrayHidden = isVisible();
            setVisible(!m_bTrayHidden);
        }
        else if (e.getButton() == e.BUTTON2)
            m_Tray.showMenu(e.getX(),e.getY());
    }

    public EntryPanel createEntryPanel()
    {
        EntryPanel panel = new EntryPanel(m_Prot,this,EntryPanel.POST_MODE);
        addTab(panel,InstallInfo.getString("tab.entry"));
        
        return panel;
    }
    
    public HistPanel createHistPanel()
    {
        HistPanel panel = new HistPanel(m_Prot, this);
        addTab(panel,InstallInfo.getString("tab.history"));
        return panel;
    }
    
    public void TrayPressed(TrayIconEvent e) {
    }
    
    public void TrayReleased(TrayIconEvent e) {
    }

    public void logIn()
    {
        JLJSettings settings = JLJSettings.GetSettings();
        if (loginDlg != null)
        {
            loginDlg.dispose();
            loginDlg = null;
        }
        loginDlg = new LoginDlg(this);
        loginDlg.setTitle(InstallInfo.getString("app.title"));
        loginDlg.addLoginListener(this);
        
        loginDlg.putSavePwd(settings.m_bSavePwd);
        
        loginDlg.setData(settings.m_UsrList,settings.m_PwdList);
        loginDlg.setLastLogin(settings.m_iLastUserIdx);
        loginDlg.show();
    }

    private void handleLogin(XMLlogin login)
    {
        m_LoginInfo = login;
        if (login.m_bSentOK)
        {
            resetTab();
                JLJSettings settings = JLJSettings.GetSettings();
                m_bConnected = true;
                if (login.m_moods != null)
                {
                    int iSize = login.m_moods.size();
                    for (int i = 0; i < iSize; i++)
                    {
                        XMLlogin.XMLmood mood = (XMLlogin.XMLmood)login.m_moods.get(i);
                        settings.m_Moods.addMood(mood.m_id.intValue(),mood.m_name,mood.m_id.intValue());
                    }
                    settings.m_Moods.sort();
                }
                String szTitle = new String();
                szTitle = InstallInfo.getString("app.title");

                if (login.m_fullname != null)
                    szTitle+= " - "+login.m_fullname;
                else if (m_Prot.getUserName() != null)
                    szTitle+= " - "+m_Prot.getUserName();
                    
                setTitle(szTitle);
                
                EntryPanel panel = createEntryPanel();
                
                HistPanel panel2 = null;
                if (m_bOnline)
                    panel2 = createHistPanel();
                
                if (login.m_pickws != null) 
                {
                    if (login.m_defaultpicurl != null)
                    {
                        login.m_pickwurls.add(0, login.m_defaultpicurl);
                        login.m_pickws.add(0,InstallInfo.getString("string.default"));
                    }
                    
                    if (login.m_pickwurls != null)
                        loadPicKWIcons(login.m_pickwurls.toArray(),login.m_pickws.toArray());
                    else
                        loadPicKWIcons(null,login.m_pickws.toArray());
                    
                    panel.populatePicKW(login.m_pickws.toArray()); //,login.m_pickwurls.toArray());
                    if (panel2 != null)
                        panel2.m_Edit.populatePicKW(login.m_pickws.toArray()); //,login.m_pickwurls.toArray());
                }
                
                setGroups(login.getGroups());
                panel.populateMoods(settings.m_Moods);
                if (panel2 != null)
                    panel2.m_Edit.populateMoods(settings.m_Moods);

                if (login.m_usejournals != null)
                {
                    login.m_usejournals.add(0, InstallInfo.getString("string.yours"));
                    panel.populatePubLJ(login.m_usejournals.toArray());
                }
                
                LJMenus WebMenu = login.getMenu();
                if (WebMenu != null)
                    populateMenu(WebMenu.getMenu());
                setSize(settings.m_MainWndRect.width,settings.m_MainWndRect.height);
                show();
                if (login.m_message != null) // Show any possible messages during login.
                {
                    String szFmtString = "";
                    int idx = 0;
                    while (idx < login.m_message.length())
                    {
                        int iLen = java.lang.Math.min(login.m_message.length() - idx, 80);
                        if (iLen < 80)
                            szFmtString += login.m_message.substring(idx);
                        else
                        {
                            String szTmp = login.m_message.substring(idx, idx + 80);
                            int iTemp = szTmp.lastIndexOf(' ');
                            szFmtString += szTmp.substring(0,iTemp)+'\n';
                            iLen = iTemp+1;
                        }
                        idx += iLen;
                    }
                    javax.swing.JOptionPane.showMessageDialog(this,szFmtString,InstallInfo.getString("app.title"),javax.swing.JOptionPane.INFORMATION_MESSAGE);
                }
                
            }
        else
        {
            m_LogListen.LoggedIn();
            return;
        }
    }

    public void Restart()
    {
            if (m_bConnected)
            {
                if (m_Tray != null)
                {
                    m_Tray.setMenu(jTrayMenu);
                    m_Tray.addTrayListner(this);
                }
                
                if (!isTrayHidden())
                    show();
            }
            else
                m_LogListen.LoggedIn();
    }
    
    public void LogoutDlgClosed() {
        String unamepwd[];
        
        JLJSettings settings = JLJSettings.GetSettings();

        if (loginDlg.getLoggedInState())
        {
            settings.m_iLastUserIdx = loginDlg.getLastLogin();
            settings.m_bSavePwd = loginDlg.getSavePwd();
            unamepwd = loginDlg.getLoginInfo();
            if ((unamepwd[0].length() > 0) && (unamepwd[1].length() > 0))
            {
                XMLlogin login = m_Prot.LogIn(unamepwd[0],unamepwd[1],(settings.m_Moods == null)?0:settings.m_Moods.getMaxMoodID());
                if (login != null)
                    handleLogin(login);
                else
                {
                    javax.swing.JOptionPane.showMessageDialog(this,InstallInfo.getString("string.error.no.connect"),InstallInfo.getString("app.title"),javax.swing.JOptionPane.INFORMATION_MESSAGE);
                    m_bConnected = false;
                    resetTab();
                    m_LogListen.LoggedIn();
                }
            }
           loginDlg.dispose();
           loginDlg = null;
        }
        else
        {
/*            if (m_bOnline)
            {
                System.out.close();
                System.err.close();
            } */
            m_LogListen.SaveInfo();
           loginDlg.dispose();
           loginDlg = null;
            m_LogListen.Exit();
       }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem jAboutItem;
    private javax.swing.JMenuItem jArchive;
    private javax.swing.JLabel jBday;
    private javax.swing.JMenuItem jContentItem;
    private javax.swing.JMenuItem jDelCookie;
    private javax.swing.JMenuItem jExitItem;
    private javax.swing.JMenuItem jExitTray;
    private javax.swing.JMenuItem jExport;
    private javax.swing.JMenu jFileMenu;
    private javax.swing.JMenu jHelpMenu;
    private javax.swing.JMenuItem jLogoutItem;
    private javax.swing.JMenuItem jLogoutTray;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JLabel jNewPost;
    private javax.swing.JCheckBoxMenuItem jOfflineItem;
    private javax.swing.JMenuItem jOptionITray;
    private javax.swing.JMenuItem jOptionItem;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem jPrivateItem;
    private javax.swing.JMenuItem jPrivateTray;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField jStatusField;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JMenu jToolMenu;
    private javax.swing.JMenu jTrayMenu;
    private javax.swing.JMenuItem jUpdate;
    private javax.swing.JMenuItem jUpdateTray;
    // End of variables declaration//GEN-END:variables
    
}
