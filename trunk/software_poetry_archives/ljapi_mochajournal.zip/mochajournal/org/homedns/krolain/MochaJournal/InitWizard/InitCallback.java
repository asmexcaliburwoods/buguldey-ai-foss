/*
 * InitCallback.java
 *
 * Created on September 4, 2002, 10:32 PM
 */

package org.homedns.krolain.MochaJournal.InitWizard;

/**
 *
 * @author  krolain
 */
public interface InitCallback {
    public void InitDone();
}
