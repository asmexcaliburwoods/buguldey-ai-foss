/*
 * SaveData.java
 *
 * Created on September 4, 2002, 11:11 PM
 */

package org.homedns.krolain.MochaJournal.InitWizard;

/**
 *
 * @author  krolain
 */
public interface SaveData {
    public void SaveData();
}
