/*
 * LJComments.java
 *
 * Created on May 25, 2004, 8:47 PM
 */

package org.homedns.krolain.MochaJournal.LJData;

/**
 *
 * @author  Krolain
 */
public class LJComment implements java.io.Serializable {

    public int m_iID;
    public int m_iUserID;
    public String m_szBody;
    public String m_szSubject;
    public java.util.Date m_Date;
    java.util.Vector m_ChildComments;
    public int m_iState;
    
    public static final int ACTIVE = 0;
    public static final int DELETED = 1;
    public static final int SCREENED = 2;
    
    /** Creates a new instance of LJComments */
    public LJComment() {
        m_iID = -1;
        m_iUserID = -1;
        m_szBody = "";
        m_szSubject = "";
        m_Date = null;
        m_ChildComments = new java.util.Vector();
        m_iState = ACTIVE;
    }
    
    public void addComment(LJComment comment)
    {
        m_ChildComments.add(comment);
    }
    
    public int getID()
    {
        return m_iID;
    }
    public void setID(int iID)
    {
        m_iID = iID;
    }
    
    public int getUserID()
    {
        return m_iUserID;
    }
    public void setUserID(int i)
    {
        m_iUserID = i;
    }
    
    public String getSubject()
    {
        return m_szSubject;
    }
    public void setSubject(String subject)
    {
        m_szSubject = subject;
    }
    
    public String getBody()
    {
        return m_szBody;
    }
    public void setBody(String body)
    {
        m_szBody = body;
    }
    
    public java.util.Date getDate()
    {
        return m_Date;
    }
    public void setDate(java.util.Date date)
    {
        m_Date = date;
    }
    
    public int getState()
    {
        return m_iState;
    }
    public void setState(int i)
    {
        m_iState = i;
    }
    
    public LJComment[] getChildren()
    {
        LJComment[] childs = new LJComment[m_ChildComments.size()];
        m_ChildComments.toArray(childs);
        return childs;
    }
    public void setChildren(LJComment[] childs)
    {
        m_ChildComments.removeAllElements();
        m_ChildComments.addAll(java.util.Arrays.asList(childs));
    }
    
}
