/*
 * LJFriends.java
 *
 * Created on May 12, 2004, 12:17 PM
 */

package org.homedns.krolain.MochaJournal.LJData;

import org.homedns.krolain.MochaJournal.Protocol.XMLgetfriends.XMLfriend;
import org.homedns.krolain.util.InstallInfo;
import org.homedns.krolain.util.intBitSet;
import java.util.Vector;
/**
 *
 * @author  jsmith
 */
public class LJFriends extends java.util.Vector implements javax.swing.table.TableModel, javax.swing.table.TableCellRenderer, java.lang.Cloneable, java.io.Serializable {
    
    public static class LJFriend implements Cloneable
    {
        public static final int COMMUNITY = 0;
        public static final int USER = 1;
        public static final int SYNDICATED = 2;
        
        public static final int ACCOUNT_STATUS_ACTIVE = 0;
        public static final int ACCOUNT_STATUS_DELETED = 1;
        public static final int ACCOUNT_STATUS_PURGED = 2;
        public static final int ACCOUNT_STATUS_SUSPENDED = 3;
        
        public String m_szUsername;
        public String m_szFullname;
        public int m_iJournalType;
        public int m_iAccStatus;
        public java.awt.Color m_bgColor;
        public java.awt.Color m_fgColor;
        public intBitSet m_iGroupMask;
        public boolean m_bFriendOf;
        public boolean m_bUpdated;
        public java.util.Date m_Birthday;
        
        public String getName() { return m_szUsername; }
        public void setName(String s) { m_szUsername = s; }
        public String getFullName() { return m_szFullname; }
        public void setFullName(String s) { m_szFullname = s; }
        public int getJournalType() { return m_iJournalType; }
        public void setJournalType(int i) { m_iJournalType = i; }
        public int getAccStatus() { return m_iAccStatus; }
        public void setAccStatus(int i) { m_iAccStatus = i; }
        public java.awt.Color getFGColor() { return m_fgColor; }
        public void setFGColor(java.awt.Color c) { m_fgColor = c; }
        public java.awt.Color getBGColor() { return m_bgColor; }
        public void setBGColor(java.awt.Color c) { m_bgColor = c;}
        public int getGroupMask() { return m_iGroupMask.getIntValue(); }
        public void setGroupMask(int i) { m_iGroupMask.setIntValue(i); }
        public boolean getFriendOf() { return m_bFriendOf; }
        public void setFriendOf(boolean b) { m_bFriendOf = b;}
        public java.util.Date getBDay() { return m_Birthday; }
        public void setBDay(java.util.Date d) {m_Birthday = d; }
        
        
        public LJFriend()
        {
            m_szUsername = "";
            m_szFullname = "";
            m_iJournalType = USER;
            m_bgColor = java.awt.Color.WHITE;
            m_fgColor = java.awt.Color.BLACK;
            m_iGroupMask = new intBitSet();
            m_bFriendOf = false;
            m_bUpdated = false;
            m_iAccStatus = ACCOUNT_STATUS_ACTIVE;
            m_Birthday = null;
        }
        
        public Object clone()
        {
            LJFriend friend = new LJFriend();
            friend.m_bFriendOf = m_bFriendOf;
            friend.m_bUpdated = m_bUpdated;
            friend.m_iJournalType = m_iJournalType;
            friend.m_bgColor = new java.awt.Color(m_bgColor.getRGB());
            friend.m_fgColor = new java.awt.Color(m_fgColor.getRGB());
            friend.m_szFullname = m_szFullname;
            friend.m_szUsername = m_szUsername;
            friend.m_iGroupMask.setIntValue(m_iGroupMask.getIntValue());
            return friend;
        }
        
        public void update(LJFriend newInfo)
        {
            m_szUsername = newInfo.m_szUsername;
            m_szFullname = newInfo.m_szFullname;
            m_iJournalType = newInfo.m_iJournalType;
            m_bgColor = newInfo.m_bgColor;
            m_fgColor = newInfo.m_fgColor;
            m_iGroupMask.setIntValue(newInfo.m_iGroupMask.getIntValue());
            m_bFriendOf = newInfo.m_bFriendOf;
            m_bUpdated = true;
        }
        
        public String toString()
        {
            return m_szUsername;
        }
        
        public boolean equals(Object obj)
        {
            if (obj instanceof String)
            {
                if (m_szUsername.compareTo(obj) == 0) return true;
            }
            if (obj instanceof LJFriend)
            {
                if (m_szUsername.compareTo(((LJFriend)obj).m_szUsername) == 0) return true;
            }
            return false;
        }
        
    }

    javax.swing.table.DefaultTableModel m_TableModel;
    int m_iUserWithBDays;
    
    public int getBDayCount() { return m_iUserWithBDays; }
    public void setBDayCount(int i) { m_iUserWithBDays = i; }
    
    /** Creates a new instance of LJFriends */
    public LJFriends() {
        m_TableModel = new javax.swing.table.DefaultTableModel();
        m_iUserWithBDays = 0;
    }

    public Object clone()
    {
        LJFriends friend = new LJFriends();
        for (int i = 0; i < elementCount; i++)
            friend.add(((LJFriend)get(i)).clone());

        return friend;
    }
    
    public Object remove(int index)
    {
        Object obj = super.remove(index);
        m_TableModel.fireTableDataChanged();
        return obj;
    }
    
    public boolean add(Object obj)
    {
        boolean bResult = super.add(obj);
        m_TableModel.fireTableDataChanged();
        return bResult;
    }
    
    protected LJFriend find(String szUname)
    {
        for (int i = 0; i < elementCount; i++)
        {
            LJFriend friend = (LJFriend)get(i);
            if (friend.m_szUsername.compareTo(szUname) == 0) return friend;
        }
        return null;
    }
    
    public void addFriend(XMLfriend newfriend)
    {
        LJFriend friend;
        friend = find(newfriend.m_username);
        if (friend == null)
        {
            friend= new LJFriend();
            friend.m_szUsername = newfriend.m_username;
            if (newfriend.m_fullname != null) friend.m_szFullname = XMLfriend.toString(newfriend.m_fullname);
            if (newfriend.m_type != null)
            {
                if (newfriend.m_type.compareToIgnoreCase("community") == 0) friend.m_iJournalType = LJFriend.COMMUNITY;
                if (newfriend.m_type.compareToIgnoreCase("syndicated") == 0) friend.m_iJournalType = LJFriend.SYNDICATED;
            }
            int r,g,b;
            r = (Integer.decode(newfriend.m_bgcolor).intValue() >> 16) & 0xFF;
            g = (Integer.decode(newfriend.m_bgcolor).intValue() >> 8) & 0xFF;
            b = (Integer.decode(newfriend.m_bgcolor).intValue() & 0xFF);
            java.awt.Color bgcol = new java.awt.Color(r,g,b);
            friend.m_bgColor = bgcol; //new java.awt.Color(r,g,b);
            r = (Integer.decode(newfriend.m_fgcolor).intValue() >> 16) & 0xFF;
            g = (Integer.decode(newfriend.m_fgcolor).intValue() >> 8) & 0xFF;
            b = (Integer.decode(newfriend.m_fgcolor).intValue() & 0xFF);
            java.awt.Color fgcol = new java.awt.Color(r,g,b);
            friend.m_fgColor = fgcol; //new java.awt.Color(r,g,b);
            if (newfriend.m_groupmask != null)
                friend.m_iGroupMask.setIntValue(newfriend.m_groupmask.intValue());
            else
                friend.m_iGroupMask.setIntValue(1);
            
            if (newfriend.m_status != null)
            {
                if (newfriend.m_status.compareToIgnoreCase("deleted")==0) friend.m_iAccStatus = friend.ACCOUNT_STATUS_DELETED;
                if (newfriend.m_status.compareToIgnoreCase("suspended") == 0) friend.m_iAccStatus = friend.ACCOUNT_STATUS_SUSPENDED;
                if (newfriend.m_status.compareToIgnoreCase("purged") == 0) friend.m_iAccStatus = friend.ACCOUNT_STATUS_PURGED;
            }
            if (newfriend.m_birthday != null)
            {
                java.text.SimpleDateFormat df= new java.text.SimpleDateFormat("yyyy-MM-dd");
                try {
                    friend.m_Birthday = df.parse((String)newfriend.m_birthday);
                } catch (java.text.ParseException e) { System.err.println(e); }
                m_iUserWithBDays++;
            }
            add(friend);
        }
        else
        {
            friend.m_bgColor = java.awt.Color.decode(newfriend.m_bgcolor);
            friend.m_fgColor = java.awt.Color.decode(newfriend.m_fgcolor);
            if (newfriend.m_groupmask != null)
                friend.m_iGroupMask.setIntValue(newfriend.m_groupmask.intValue());
            else
                friend.m_iGroupMask.setIntValue(1);
        }
    }
    
    public void addFriendOf(XMLfriend newfriend)
    {
        LJFriend friend;
        friend = find(newfriend.m_username);
        if (friend == null)
        {
            friend= new LJFriend();
            friend.m_szUsername = newfriend.m_username;
            if (newfriend.m_fullname != null) friend.m_szFullname = XMLfriend.toString(newfriend.m_fullname);
            if (newfriend.m_type != null)
            {
                if (newfriend.m_type.compareToIgnoreCase("community") == 0) friend.m_iJournalType = LJFriend.COMMUNITY;
                if (newfriend.m_type.compareToIgnoreCase("syndicated") == 0) friend.m_iJournalType = LJFriend.SYNDICATED;
            }
            friend.m_bgColor = java.awt.Color.decode(newfriend.m_bgcolor);
            friend.m_fgColor = java.awt.Color.decode(newfriend.m_fgcolor);
            friend.m_bFriendOf = true;
            add(friend);
        }
        else
            friend.m_bFriendOf = true;
    }
    
    public void addTableModelListener(javax.swing.event.TableModelListener l) {
        m_TableModel.addTableModelListener(l);
    }
    
    public Class getColumnClass(int columnIndex) {
//        switch (columnIndex)
//        {
//            case 0:
                return LJFriend.class;
//            default:
//                return String.class;
//        }
    }
    
    public int getColumnCount() {
        return 3;
    }
    
    public String getColumnName(int columnIndex) {
        switch (columnIndex)
        {
            case 0:
                return new String(InstallInfo.getString("label.username"));
            case 1:
                return new String(InstallInfo.getString("label.fullname"));
            case 2:
                return new String(InstallInfo.getString("label.updated"));
            default:
                return new String("");
        }
    }
    
    public int getRowCount() {
        return elementCount;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        LJFriend friend = (LJFriend)get(rowIndex);
//        switch (columnIndex)
//        {
//            case 0:
                return friend;
//            case 1:
//                return friend.m_szFullname;
//            case 2:
//                return new String(friend.m_bUpdated?"Yes":"No");
//            default:
//                return new String("");
//        }
    }
    
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false;
    }
    
    public void removeTableModelListener(javax.swing.event.TableModelListener l) {
        m_TableModel.removeTableModelListener(l);
    }
    
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
    }
    
    public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        javax.swing.JLabel cell = new javax.swing.JLabel();
        cell.setOpaque(true);
        LJFriend data = (LJFriend)value;
        if (isSelected)
        {
            cell.setBackground(table.getSelectionBackground());
            cell.setForeground(table.getSelectionForeground());
        }
        else
        {
            cell.setBackground(data.m_bgColor);
            cell.setForeground(data.m_fgColor);
        }

        if (column == 0)
        {
            javax.swing.Icon icon = null;
            if (data.m_iJournalType == data.USER)
            {
                if (data.m_iGroupMask.get(0) && data.m_bFriendOf)
                    icon = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/mutual.gif"));
                else if (data.m_bFriendOf)
                    icon = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/friendof.gif"));
                else if (data.m_iGroupMask.get(0))
                    icon = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/friend.gif"));
            }
            else if (data.m_iJournalType == data.COMMUNITY)
                icon = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/community.gif"));
            else if (data.m_iJournalType == data.SYNDICATED)
                icon = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/syndicated.gif"));
                
            cell.setText(data.m_szUsername);
            cell.setIcon(icon);
        }
        else if (column == 1)
        {
            cell.setText(data.m_szFullname);
        }
        else if (column == 2)
        {
            cell.setText(data.m_bUpdated?"Yes":"No");
        }
        
        return cell;
    }
    
    public Birthday[] getBDayList()
    {
        int iIndex = 0;
        Birthday[] bDays = new Birthday[m_iUserWithBDays];
        for (int i = 0; i < elementCount; i++)
        {
            LJFriend friend = (LJFriend)get(i);
            if (friend.m_Birthday != null)
            {
                bDays[iIndex] = new Birthday(friend.m_szUsername,friend.m_Birthday);
                iIndex ++;
            }
        }
        
        java.util.Arrays.sort(bDays);
        
        return bDays;
    }
    
    public LJFriends.LJFriend[][] compareFriendOf(LJFriends local)
    {
        LJFriends.LJFriend[][] adddel = new LJFriends.LJFriend[2][];
        Vector add = new Vector();
        Vector del = new Vector();
          
        int iSize = java.lang.Math.max(elementCount,local.size());
        for (int i = 0; i < iSize; i++)
        {
            if (i < elementCount)
            {
                LJFriend dlFriend = (LJFriend)get(i);
                LJFriend friend = local.find(dlFriend.m_szUsername);
                if ((friend == null) && dlFriend.m_bFriendOf)
                    add.add(dlFriend);
                else if ((friend != null) &&  ((friend.m_bFriendOf != dlFriend.m_bFriendOf) && !friend.m_bFriendOf))
                    add.add(dlFriend);
            }

            if (i < local.size())
            {
                LJFriend friend = (LJFriend)local.get(i);
                LJFriend dlFriend = find (friend.m_szUsername);
                if ((dlFriend == null) && (friend.m_bFriendOf))
                    del.add(friend);
                else if ((dlFriend != null) && ((friend.m_bFriendOf != dlFriend.m_bFriendOf) && friend.m_bFriendOf))
                    del.add(friend);
            }
        }
        adddel[0] = new LJFriends.LJFriend[add.size()];
        adddel[1] = new LJFriends.LJFriend[del.size()];
        add.toArray(adddel[0]);
        del.toArray(adddel[1]);
        return adddel;
    }
    
    public class Birthday extends Object implements java.lang.Comparable
    {
        
        java.util.Date m_BDay = null;
        String m_szName = null;
        /** Compares this object with the specified object for order.  Returns a
         * negative integer, zero, or a positive integer as this object is less
         * than, equal to, or greater than the specified object.<p>
         *
         * In the foregoing description, the notation
         * <tt>sgn(</tt><i>expression</i><tt>)</tt> designates the mathematical
         * <i>signum</i> function, which is defined to return one of <tt>-1</tt>,
         * <tt>0</tt>, or <tt>1</tt> according to whether the value of <i>expression</i>
         * is negative, zero or positive.
         *
         * The implementor must ensure <tt>sgn(x.compareTo(y)) ==
         * -sgn(y.compareTo(x))</tt> for all <tt>x</tt> and <tt>y</tt>.  (This
         * implies that <tt>x.compareTo(y)</tt> must throw an exception iff
         * <tt>y.compareTo(x)</tt> throws an exception.)<p>
         *
         * The implementor must also ensure that the relation is transitive:
         * <tt>(x.compareTo(y)&gt;0 &amp;&amp; y.compareTo(z)&gt;0)</tt> implies
         * <tt>x.compareTo(z)&gt;0</tt>.<p>
         *
         * Finally, the implementer must ensure that <tt>x.compareTo(y)==0</tt>
         * implies that <tt>sgn(x.compareTo(z)) == sgn(y.compareTo(z))</tt>, for
         * all <tt>z</tt>.<p>
         *
         * It is strongly recommended, but <i>not</i> strictly required that
         * <tt>(x.compareTo(y)==0) == (x.equals(y))</tt>.  Generally speaking, any
         * class that implements the <tt>Comparable</tt> interface and violates
         * this condition should clearly indicate this fact.  The recommended
         * language is "Note: this class has a natural ordering that is
         * inconsistent with equals."
         *
         * @param   o the Object to be compared.
         * @return  a negative integer, zero, or a positive integer as this object
         * 		is less than, equal to, or greater than the specified object.
         *
         * @throws ClassCastException if the specified object's type prevents it
         *         from being compared to this Object.
         */
        public int compareTo(Object o) {
            if (!(o instanceof Birthday)) throw new java.lang.ClassCastException();
            Birthday oBday = (Birthday)o;
            
            java.util.Calendar thisCalen = java.util.Calendar.getInstance();
            thisCalen.setTime(m_BDay);
            
            java.util.Calendar oCalen = java.util.Calendar.getInstance();
            oCalen.setTime(oBday.getBirthday());
  
            if (thisCalen.get(thisCalen.MONTH) < oCalen.get(oCalen.MONTH))
                return -1;
            else if (thisCalen.get(thisCalen.MONTH) > oCalen.get(oCalen.MONTH))
                return 1;
            
            if (thisCalen.get(thisCalen.DAY_OF_MONTH) < oCalen.get(oCalen.DAY_OF_MONTH))
                return -1;
            else if (thisCalen.get(thisCalen.DAY_OF_MONTH) > oCalen.get(oCalen.DAY_OF_MONTH))
                return 1;
            else
                return 0;
        }
        
        public java.util.Date getBirthday()
        {
            return m_BDay;
        }
        
        public String getName()
        {
            return m_szName;
        }
        
        public Birthday(String szName, java.util.Date bDay)
        {
            m_BDay = bDay;
            m_szName = szName;
        }
        
        public String toString()
        {
            java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("MMM dd, yyyy");
            return m_szName + ": " + df.format(m_BDay);
        }
    }    
}
