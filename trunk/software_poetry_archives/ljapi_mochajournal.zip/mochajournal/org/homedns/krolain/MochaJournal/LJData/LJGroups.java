/*
 * LJGroups.java
 *
 * Created on May 13, 2004, 10:07 AM
 */

package org.homedns.krolain.MochaJournal.LJData;

import org.homedns.krolain.util.intBitSet;
import org.homedns.krolain.MochaJournal.Protocol.XMLfriendgroup;
import org.homedns.krolain.util.InstallInfo;
/**
 *
 * @author  jsmith
 */
public class LJGroups extends java.util.Vector implements javax.swing.table.TableModel, javax.swing.ListModel, java.lang.Cloneable, java.io.Serializable {
    
    public static class LJGroup implements java.lang.Cloneable, java.io.Serializable
    {
        public String m_szName;
        public int m_iBit;
        public int m_iSortOrder;
        public boolean m_bPublic;
        public boolean m_bNew;
        public boolean m_bDeleted;
        public boolean m_bUpdated;
        
        public Object clone()
        {
            LJGroup group = new LJGroup();
            group.m_szName = m_szName;
            group.m_iBit = m_iBit;
            group.m_iSortOrder = m_iSortOrder;
            group.m_bPublic = m_bPublic;
            group.m_bNew = m_bNew;
            group.m_bDeleted = m_bDeleted;
            group.m_bUpdated = m_bUpdated;
            return group;
        }
        
        public LJGroup()
        {
            m_szName = "";
            m_iBit = -1; // No bit set.
            m_bPublic = true;
            m_iSortOrder = 0;
            m_bNew = false;
            m_bDeleted = false;
            m_bUpdated = false;
        }
        
        public String getName() { return m_szName; }
        public void setName(String name) { m_szName = name; }
        public int getBit() { return m_iBit; }
        public void setBit(int i) { m_iBit = i; }
        public int getOrder() { return m_iSortOrder; }
        public void setOrder( int i) { m_iSortOrder = i; }
        public boolean getPublic() { return m_bPublic;}
        public void setPublic (boolean b) { m_bPublic = b; }
        
        public boolean equals(Object obj)
        {
            if (obj instanceof LJGroup)
                return (((LJGroup)obj).m_iBit == m_iBit);

            return false;
        }
        
        public String toString()
        {
            return m_szName;
        }
    }
    
    intBitSet m_GroupBits;
    javax.swing.table.DefaultTableModel m_Model;
    java.util.Vector m_DataListenList;
    
    public Object clone()
    {
        LJGroups group = new LJGroups();
        group.m_GroupBits.setIntValue(m_GroupBits.getIntValue());
        for (int i = 0; i < elementCount; i++)
            group.add(((LJGroup)get(i)).clone());
        return group;
    }
    
    /** Creates a new instance of LJGroups */
    public LJGroups() {
        m_GroupBits = new intBitSet();
        m_GroupBits.set(0);
        m_Model = new javax.swing.table.DefaultTableModel();
        m_DataListenList = new java.util.Vector();
    }
    
    public void setGroups(LJGroups groups)
    {
        removeAllElements();
        addAll(java.util.Arrays.asList(groups.toArray()));
        m_GroupBits.setIntValue(groups.m_GroupBits.getIntValue());
        m_Model.fireTableDataChanged();
    }
    
    public void addGroup(XMLfriendgroup newgroup)
    {
        LJGroup group = new LJGroup();
        group.m_szName = XMLfriendgroup.toString(newgroup.m_name);
        group.m_iBit = newgroup.m_id.intValue();
        m_GroupBits.set(group.m_iBit);
        group.m_iSortOrder = newgroup.m_sortorder.intValue();
        group.m_bPublic = ((Integer)newgroup.m_public).intValue() == 1;
        add(group);
    }
    
    public void delGroup(int iIdx)
    {
        int idx = -1;
        LJGroup group = null;
        int i;
        for (i = 0; i < elementCount; i++)
        {
            group = (LJGroup)get(i);
            if (!group.m_bDeleted) idx ++;
            if (idx == iIdx) break;
        }
        if (group.m_bNew) remove(i);
        group.m_bDeleted = true;
        m_GroupBits.set(group.m_iBit,false);
        m_Model.fireTableDataChanged();
    }
    
    public boolean addGroup(String szName)
    {
        LJGroup group = new LJGroup();
        group.m_szName = szName;
        int iSize = m_GroupBits.size();
        for (int i = 0; i < iSize; i++)
        {
            if (!m_GroupBits.get(i))
            {
                group.m_iBit = i;
                group.m_bNew = true;
                add(group);
                m_Model.fireTableDataChanged();
                return true;
            }
        }
        return false;
    }
    
    public void addTableModelListener(javax.swing.event.TableModelListener l) {
        m_Model.addTableModelListener(l);
    }
    
    public Class getColumnClass(int columnIndex) {
        switch (columnIndex)
        {
            case 0:
                return String.class;
            case 1:
                return Boolean.class;
            default:
                return Object.class;
        }
    }
    
    public int getColumnCount() {
        return 2;
    }
    
    public String getColumnName(int columnIndex) {
        switch (columnIndex)
        {
            case 0:
                return InstallInfo.getString("label.your.group");
            case 1:
                return InstallInfo.getString("group.public");
            default:
                return "";
        }
    }
    
    public int getRowCount() {
        int iResult = 0;
        for (int i = 0; i < elementCount; i++)
            if (!((LJGroup)get(i)).m_bDeleted) iResult ++;
        return iResult;
    }
    
    public Object getValueAt(int rowIndex, int columnIndex) {
        int iResult = -1;
        LJGroup group = null;
        for (int i = 0; i < elementCount; i++)
        {
            group = (LJGroup)get(i);
            if (!group.m_bDeleted) iResult ++;
            if (iResult == rowIndex) break;
        }
        if (group == null) return null;
        switch (columnIndex)
        {
            case 0:
                return group.m_szName;
            case 1:
                return new Boolean(group.m_bPublic);
            default:
                return new Object();
        }
    }
    
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }
    
    public void removeTableModelListener(javax.swing.event.TableModelListener l) {
        m_Model.removeTableModelListener(l);
    }
    
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        LJGroup group = (LJGroup)get(rowIndex);
        switch (columnIndex)
        {
            case 0:
                group.m_szName = (String)aValue;
                break;
            case 1:
                group.m_bPublic = ((Boolean)aValue).booleanValue();
                break;
            default:
                break;
        }
    }
    
    public void addListDataListener(javax.swing.event.ListDataListener l) {
        m_DataListenList.add(l);
    }
    
    public Object getElementAt(int index) {
        return get(index);
    }
    
    public int getSize() {
        return elementCount;
    }
    
    public void removeListDataListener(javax.swing.event.ListDataListener l) {
        m_DataListenList.remove(l);
    }
    
}
