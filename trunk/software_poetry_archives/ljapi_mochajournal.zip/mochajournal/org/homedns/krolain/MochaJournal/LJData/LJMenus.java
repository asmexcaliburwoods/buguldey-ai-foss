/*
 * LJMenus.java
 *
 * Created on July 4, 2002, 9:32 PM
 */

/**
 *
 * @author  krolain
 */
package org.homedns.krolain.MochaJournal.LJData;

import java.lang.String;
import java.awt.event.KeyEvent;
import java.util.BitSet;

public class LJMenus extends javax.swing.AbstractAction 
{
    static BitSet m_Mnemonic;
    /** Creates a new instance of LJMenus */
    String m_szUrl = null;
    LJMenus m_SubMenu[] = null;
    static String m_szBrowser = null;
    
    static final short m_iBits = 26;
    
    public LJMenus ()
    {
        this("");
    }
    
    public LJMenus(String name)
    {
        this(name,null);
    }
    
    public LJMenus(String name, javax.swing.Icon icon)
    {
        super(name,icon);
        // Make it large enough to hold a location for each letter of the english alphabet.
        m_Mnemonic = new BitSet(m_iBits); 
    }
    
    public void setUrl(String url)
    {
        m_szUrl = url;
    }
    
    public void setSubmenu(LJMenus[] subMenu)
    {
        m_SubMenu = subMenu;
    }

    public boolean isSubMenu()
    {
        return (m_SubMenu != null);
    }
    
    public static void setBrowser (String szBrowser)
    {
        m_szBrowser = szBrowser;
    }
    
    public static String getBrowser()
    {
        return m_szBrowser;
    }
    
    public static boolean isBrowserSet()
    {
        return ((m_szBrowser != null) && (m_szBrowser.length() > 0));
    }
    
    public boolean isSeperator()
    {
        String szName = (String)getValue(javax.swing.Action.NAME);
        return ((szName != null) && (szName.compareTo("-") == 0));
    }
    
    public boolean isMenuItem()
    {
        return (m_szUrl != null);
    }
    
    public void actionPerformed(java.awt.event.ActionEvent actionEvent) 
    {
        if ((m_szBrowser != null) && (m_szUrl != null) && (m_szUrl.length() > 0))
        {
            org.homedns.krolain.util.NativeSystem.launchBrowser(m_szBrowser,m_szUrl);
        }
        
    }
    
    private void setMnemonic()
    {
        String name = (String)getValue(NAME);
        name = name.toUpperCase();
        int iLen = name.length();
        for (int i = 0 ; i < iLen; i++)
        {
            int iLetterIdx = name.charAt(i) - 'A';
            // This fixes a bug where sometimes we don't get the proper text coming from LJ
            // and we get strange, non alphabetical characters
            if ((iLetterIdx < 0) || (iLetterIdx >= m_iBits)) continue;
            
            if (!m_Mnemonic.get(iLetterIdx))
            {
                putValue(MNEMONIC_KEY,new java.lang.Integer(KeyEvent.VK_A+iLetterIdx));
                m_Mnemonic.set(iLetterIdx);
                break;
            }
        }
    }
    
    public javax.swing.JMenu getMenu()
    {

        javax.swing.JMenu menu = new javax.swing.JMenu(this);
        setMnemonic();
        javax.swing.JMenuItem menuItem = null;
        int iSize = m_SubMenu.length;
        for (int i = 0; i < iSize; i++)
        {
            if (m_SubMenu[i].isSeperator())
                menu.add(new javax.swing.JSeparator());
            else if (m_SubMenu[i].isMenuItem())
            {
                javax.swing.JMenuItem menu1 = new javax.swing.JMenuItem(m_SubMenu[i]);
                m_SubMenu[i].setMnemonic();
                menu.add(menu1);
            }
            else if (m_SubMenu[i].isSubMenu())
                menu.add(m_SubMenu[i].getMenu());
        }
        return menu;
    }
    
}
