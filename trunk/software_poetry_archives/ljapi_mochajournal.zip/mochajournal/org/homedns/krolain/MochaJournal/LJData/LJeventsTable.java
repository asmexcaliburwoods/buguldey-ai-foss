/*
 * OldPostInfo.java
 *
 * Created on July 20, 2002, 6:05 PM
 */

package org.homedns.krolain.MochaJournal.LJData;
import org.homedns.krolain.MochaJournal.LJData.OldEventInfo;
import java.io.*;
import java.beans.*;
import java.util.regex.*;
import java.nio.charset.Charset;
import java.net.URL;
import org.homedns.krolain.MochaJournal.*;
import java.util.*;
import org.homedns.krolain.MochaJournal.Protocol.*;

/**
 *
 * @author  krolain
 */
/* This class contains the result recieved from a getevents event
 * sent to LiveJournal
 */
public class LJeventsTable implements java.io.Serializable {

    java.util.Hashtable m_EventList = null;
    java.util.Date m_LastEntry = null;
    
    java.util.Hashtable m_UserList = null;
    java.util.Hashtable m_CommentList = null;
    int m_LastCommentID = -1;
    
    /** Creates a new instance of OldPostInfo */
    public LJeventsTable() {
        m_EventList = new java.util.Hashtable();
        m_CommentList = new java.util.Hashtable();
        m_UserList = new java.util.Hashtable();
        m_LastEntry = null;
    }
    
    public void exportEvents(String szUsername,HTMLExport exp, java.awt.Frame parent)
    {
        String szTemplate;
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+szUsername+System.getProperty("file.separator")+"export";
        OldEventInfo[] eventList = getEventList();
        int iSize = eventList.length;
        if (iSize == 0) return;
        if (exp.NewDocument(szPath,szUsername,parent))
        {
            exp.insertEntries(this);
            exp.closeDocument();
        }
        
    }
    
    //Methods to access the entire indexed property array
    public OldEventInfo[] getEventList()
    {
        OldEventInfo[] infos = new OldEventInfo[m_EventList.size()];
        m_EventList.values().toArray(infos);
        return infos;
    }
    public void setEventList(OldEventInfo[] value)
    {
        int iSize = value.length;
        for (int i = 0; i < iSize; i++)
            m_EventList.put(new Integer(value[i].m_iItemID), value[i]);
    }

    public java.util.Date getLastEntry()
    {
        return m_LastEntry;
    }
    public void setLastEntry(java.util.Date entry)
    {
        m_LastEntry = entry;
    }
    
    public int getCommentID()
    {
        return m_LastCommentID;
    }
    public void setCommentID(int iID)
    {
        m_LastCommentID = iID;
    }
    public LJComment[] getComments()
    {
        LJComment[] comments = new LJComment[m_CommentList.size()];
        m_CommentList.values().toArray(comments);
        return comments;
    }
    public void setComments(LJComment[] comments)
    {
        int iSize = comments.length;
        for (int i = 0; i < iSize; i++)
            m_CommentList.put(new Integer(comments[i].m_iID), comments[i]);
    }

    public LJuserMap[] getUsers()
    {
        LJuserMap[] users = new LJuserMap[m_UserList.size()];
        m_UserList.values().toArray(users);
        return users;
    }
    public void setUsers(LJuserMap[] users)
    {
        int iSize = users.length;
        for (int i = 0; i < iSize; i++)
            m_UserList.put(new Integer(users[i].m_iID), users[i]);
    }
    
    public void addItem(OldEventInfo info)
    {
        m_EventList.put(new Integer(info.m_iItemID),info);
    }
    
    public void addItems(OldEventInfo[] items)
    {
        int iSize = items.length;
        for (int i = 0; i < iSize; i++)
        {
            OldEventInfo evtInfo =  items[i];
            Object obj = m_EventList.get(new Integer(evtInfo.m_iItemID));
            if (obj != null)
                delItem(evtInfo.m_iItemID);
            addItem(evtInfo);
            if ((m_LastEntry == null) || (evtInfo.m_Date.after(m_LastEntry)))
                m_LastEntry = evtInfo.m_Date;
        }
    }

    public int getCount()
    {
        return m_EventList.size();
    }
    
    public void delItem(int iEventID)
    {
        m_EventList.remove(new Integer(iEventID));
    }
    
    public String getLastEntryDate()
    {
        if (m_LastEntry == null) return null;
        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return df.format(m_LastEntry);
    }
    
    public int getLastCommentID()
    {
        return m_LastCommentID;
    }
    
    public Object[] getList()
    {
        return m_EventList.values().toArray();
    }
    
    public void addCommentPosters(Vector posters)
    {
        int iSize = posters.size();
        for (int i = 0; i < iSize; i++)
        {
            LJuserMap user = (LJuserMap)posters.get(i);
            Object obj = m_UserList.get(new Integer(user.m_iID));
            if (obj != null)
            {
                LJuserMap savedUser = (LJuserMap)obj;
                savedUser.m_szUserName = user.m_szUserName;
            }
            else
                m_UserList.put(new Integer(user.m_iID), user);
            
        }
    }
    public void addComments(Vector comments)
    {
        int iSize = comments.size();
        for (int i = 0; i < iSize; i++)
        {
            XMLcomments.comment comment = (XMLcomments.comment)comments.get(i);
            LJComment savedComment = new LJComment();
            savedComment.m_iID = comment.m_iID;
            savedComment.m_iUserID = comment.m_iPoster;
            savedComment.m_szBody = comment.m_szBody;
            savedComment.m_Date = comment.m_Date;
            savedComment.m_szSubject = comment.m_szSubject;
            if (comment.m_szState == null)
                savedComment.m_iState = savedComment.ACTIVE;
            else if (comment.m_szState.compareToIgnoreCase("D") == 0)
                savedComment.m_iState = savedComment.DELETED;
            else if (comment.m_szState.compareToIgnoreCase("S") == 0)
                savedComment.m_iState = savedComment.SCREENED;
            else if (comment.m_szState.compareToIgnoreCase("A") == 0)
                savedComment.m_iState = savedComment.ACTIVE;
            if (comment.m_iParentID != -1)
            {
                Object obj = m_CommentList.get(new Integer(comment.m_iParentID));
                if (obj != null)
                {
                    LJComment parentComment = (LJComment)obj;
                    parentComment.addComment(savedComment);
                }
                else
                {
                    OldEventInfo event = (OldEventInfo)m_EventList.get(new Integer(comment.m_iJournalID));
                    event.m_Comments.add(savedComment);
                }
            }
            else
            {
                OldEventInfo event = (OldEventInfo)m_EventList.get(new Integer(comment.m_iJournalID));
                event.m_Comments.add(savedComment);
            }
            m_CommentList.put(new Integer(savedComment.m_iID), savedComment);
            if (m_LastCommentID < savedComment.m_iID)
                m_LastCommentID = savedComment.m_iID;
        }
    }
    
    public String getUserName(int userID)
    {
        Object obj = m_UserList.get(new Integer(userID));
        if (obj != null)
        {
            return ((LJuserMap)obj).m_szUserName;
        }
        return null;
    }
    
    public void updateComments (Vector comments)
    {
        int iSize = comments.size();
        for (int i = 0; i < iSize; i++)
        {
            XMLcomments.comment comment = (XMLcomments.comment)comments.get(i);
            Object obj = m_CommentList.get(new Integer(comment.m_iID));
            if (obj != null)
            {
                LJComment savedComment = (LJComment)obj;
                savedComment.m_iUserID = comment.m_iPoster;
                if (comment.m_szState == null)
                    savedComment.m_iState = savedComment.ACTIVE;
                else if (comment.m_szState.compareToIgnoreCase("D") == 0)
                    savedComment.m_iState = savedComment.DELETED;
                else if (comment.m_szState.compareToIgnoreCase("S") == 0)
                    savedComment.m_iState = savedComment.SCREENED;
                else if (comment.m_szState.compareToIgnoreCase("A") == 0)
                    savedComment.m_iState = savedComment.ACTIVE;
            }
        }
    }
}
