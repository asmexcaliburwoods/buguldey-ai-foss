/*
 * eventHistInfo.java
 *
 * Created on July 20, 2002, 3:17 PM
 */

package org.homedns.krolain.MochaJournal.LJData;
import org.homedns.krolain.MochaJournal.Protocol.XMLgetdaycounts.XMLdaycount;
/**
 *
 * @author  krolain
 */
/* This class stores the result recived by sending an getdaycounts event
 * to LiveJournal
 */
public class LJgetdaycount {
    
    class LJDayInfo implements java.lang.Comparable
    {
        String m_Date = null;
        int m_iPosts = 0;
        
        public int compareTo(Object o) {
            if (o instanceof LJDayInfo)
                return m_Date.compareTo(((LJDayInfo)o).m_Date);
            else if (o instanceof String)
                return m_Date.compareTo(o);
            else
                throw (new java.lang.ClassCastException());
            
        }
        
    }
    
    java.util.ArrayList m_szReturnList = null;
    
    /** Creates a new instance of eventHistInfo */
    public LJgetdaycount()
    {
        m_szReturnList = new java.util.ArrayList();
    }
    
    public void setList (XMLdaycount[] list)
    {
        LJDayInfo[] daylist = new LJDayInfo[list.length];
        for (int i = 0; i < list.length; i++)
        {
            LJDayInfo day = new LJDayInfo();
            day.m_iPosts = list[i].m_count.intValue();
            day.m_Date = list[i].m_date;
            daylist[i] = day;
        }
        java.util.Arrays.sort(daylist);
        m_szReturnList = new java.util.ArrayList(java.util.Arrays.asList(daylist));
    }
    
    private String dateToString(int iDay, int iMonth, int iYear)
    {
        String szYear = java.lang.Integer.toString(iYear);
        szYear += "-";
        String szTemp = java.lang.Integer.toString(iMonth);
        if (szTemp.length() == 1)
            szYear += "0"+szTemp;
        else
            szYear += szTemp;
        szYear += "-";
        szTemp = java.lang.Integer.toString(iDay);
        if (szTemp.length() == 1)
            szYear += "0"+szTemp;
        else
            szYear += szTemp;
        
        return szYear;
    }
    
    private int findIndex(int iDay, int iMonth, int iYear)
    {
        if (m_szReturnList.size() == 0) return -1;

        String szYear = dateToString(iDay,iMonth,iYear);
        
        int iIndex = java.util.Arrays.binarySearch(m_szReturnList.toArray(),szYear);
        return iIndex;
    }

    private int addDay(int iDay, int iMonth, int iYear)
    {
        String szYear = dateToString(iDay,iMonth,iYear);
        LJDayInfo response = new LJDayInfo();
        response.m_Date = szYear;
        response.m_iPosts = 0;
        m_szReturnList.add(response);
        Object[] objList = m_szReturnList.toArray();
        java.util.Arrays.sort(objList);
        m_szReturnList = new java.util.ArrayList(java.util.Arrays.asList(objList));
        return findIndex(iDay,iMonth,iYear);
    }
    
    public void decDay(int iDay, int iMonth, int iYear)
    {
        int iIndex = findIndex(iDay, iMonth, iYear);
        if (iIndex < 0) return;
        ((LJDayInfo)m_szReturnList.get(iIndex)).m_iPosts --;
    }
    
    public void incDay(int iDay, int iMonth, int iYear)
    {
        int iIndex = findIndex(iDay, iMonth, iYear);
        if (iIndex < 0)
            iIndex = addDay(iDay, iMonth, iYear);
        
        ((LJDayInfo)m_szReturnList.get(iIndex)).m_iPosts++;
    }
    
    public String getDateString(int iDay, int iMonth, int iYear)
    {
        int iIndex = findIndex(iDay, iMonth, iYear);
        if (iIndex < 0) return null;
        return String.valueOf(((LJDayInfo)m_szReturnList.get(iIndex)).m_iPosts);
    }
    
}