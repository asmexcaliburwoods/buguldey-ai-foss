/*
 * LJsyncitemResponse.java
 *
 * Created on April 24, 2004, 3:03 PM
 */

package org.homedns.krolain.MochaJournal.LJData;
import org.homedns.krolain.MochaJournal.LJData.OldEventInfo;
import org.homedns.krolain.MochaJournal.Protocol.*;

/**
 *
 * @author  Krolain
 */
public class LJsyncTable {
    
    static public class syncItem implements Comparable
    {
        public java.util.Date m_Date = null;
        public int m_iID = -1;
        public String m_szAction = "";
        public boolean m_bDownloaded = false;
        
        public int compareTo(Object o) {
            return m_Date.compareTo(((syncItem)o).m_Date);
        }
        
    }
    
    java.util.Hashtable m_HashedAction;
    java.util.Vector m_SortedAction;
    String m_szLastUpdate = null;
    public int m_iTotal = 0;
    public int m_iCur = 0;
    
    /** Creates a new instance of LJsyncitemResponse */
    public LJsyncTable() {
        m_HashedAction = new java.util.Hashtable();
        m_SortedAction = new java.util.Vector();
    }
    
    
    
    public void addAllSyncItems(XMLsyncItems newItems)
    {
        int iSize = newItems.m_syncitems.size();
        for (int i = 0; i < iSize; i++)
        {
            XMLsyncItems.XMLsyncitem xmlItem = (XMLsyncItems.XMLsyncitem) newItems.m_syncitems.get(i);
            if (xmlItem.m_item.charAt(0) == 'L')
            {
                try
                {
                    syncItem item = new syncItem();
                    item.m_iID = Integer.parseInt(xmlItem.m_item.substring(2));
                    item.m_szAction = xmlItem.m_action;
                    java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    item.m_Date = df.parse(xmlItem.m_time);
                    m_HashedAction.put(new Integer(item.m_iID), item);
                    if (m_szLastUpdate != null)
                    {
                        java.util.Date thisdate = df.parse(m_szLastUpdate);
                        if (thisdate.before(item.m_Date))
                            m_szLastUpdate = xmlItem.m_time;
                    }
                    else
                        m_szLastUpdate = xmlItem.m_time;
                }
                catch (java.text.ParseException e) { System.err.println(e); }
            }
        }
/*        m_HashedAction.putAll(newItems.m_HashedAction);
        if (newItems.m_szLastUpdate != null)
        {
            java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            java.util.Date thisdate = df.parse(m_szLastUpdate, new java.text.ParsePosition(0));
            java.util.Date thatdate = df.parse(newItems.m_szLastUpdate, new java.text.ParsePosition(0));
            if (thisdate.before(thatdate))
                m_szLastUpdate = newItems.m_szLastUpdate;
        } */
    }
    
    public void insertSyncItem(String szItemID, String szAction, String szDate)
    {
        try
        {
            syncItem item = new syncItem();
            item.m_iID = new Integer(szItemID).intValue();
            java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            item.m_Date = df.parse(szDate,new java.text.ParsePosition(0));
            m_HashedAction.put(new Integer(szItemID),item);

            if (m_szLastUpdate != null)
            {
                java.util.Date lastDate = df.parse(m_szLastUpdate,new java.text.ParsePosition(0));
                if (lastDate.before(item.m_Date))
                    m_szLastUpdate = szDate;
            }
            else if (szDate != null)
                m_szLastUpdate = szDate;
            
        } catch (java.lang.NumberFormatException e) { System.out.println(e); }

   }
    
    public void sort()
    {
        Object[] objs = m_HashedAction.values().toArray();
        java.util.Arrays.sort(objs);
        m_SortedAction.addAll(java.util.Arrays.asList(objs));
    }
    
    public boolean hasMoreUpdates()
    {
        int iSize = 0;
        for (int i = 0; i < m_SortedAction.size(); i++)
        {
            syncItem itm = (syncItem)m_SortedAction.get(i);
            if (!itm.m_bDownloaded)
                return true;
        }
        return false;
    }
    
    public void updateItems(OldEventInfo[] dnlItems)
    {
        int iSize = dnlItems.length;
        for (int i = 0; i < iSize; i++)
        {
            OldEventInfo event = dnlItems[i];
            syncItem item = (syncItem)m_HashedAction.get(new Integer(event.m_iItemID));
            if (item != null)
                item.m_bDownloaded = true;
        }
    }
    
    public String syncFrom()
    {
        return m_szLastUpdate;
/*        java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        java.util.Date syncDate = df.parse(m_szLastUpdate,new java.text.ParsePosition(0));
        java.util.Calendar calen = java.util.Calendar.getInstance();
        calen.setTime(syncDate);
        calen.roll(calen.SECOND,false);
        return df.format(calen.getTime()); */
    }
    
    public String downloadFrom()
    {
        int iSize = 0;
        for (int i = 0; i < m_SortedAction.size(); i++)
        {
            syncItem itm = (syncItem)m_SortedAction.get(i);
            if (!itm.m_bDownloaded)
            {
                java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.util.Calendar calen = java.util.Calendar.getInstance();
                calen.setTime(itm.m_Date);
                calen.roll(calen.SECOND,false);
                return df.format(calen.getTime());
            }
        }
        return null;
    }
}
