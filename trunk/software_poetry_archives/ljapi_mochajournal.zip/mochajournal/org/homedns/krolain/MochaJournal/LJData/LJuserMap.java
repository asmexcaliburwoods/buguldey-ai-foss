/*
 * LJuserMap.java
 *
 * Created on May 26, 2004, 12:57 PM
 */

package org.homedns.krolain.MochaJournal.LJData;

/**
 *
 * @author  jsmith
 */
public class LJuserMap implements java.io.Serializable {
    
    public int m_iID;
    public String m_szUserName;
    
    /** Creates a new instance of LJuserMap */
    public LJuserMap() {
        m_iID = -1;
        m_szUserName = "";
    }
    
    public int getID()
    {
        return m_iID;
    }
    public void setID(int i)
    {
        m_iID = i;
    }
    
    public String getName()
    {
        return m_szUserName;
    }
    public void setName(String name)
    {
        m_szUserName = name;
    }
}
