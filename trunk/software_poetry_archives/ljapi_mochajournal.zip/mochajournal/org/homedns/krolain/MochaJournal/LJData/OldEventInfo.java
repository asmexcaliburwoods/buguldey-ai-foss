/*
 * EventInfo.java
 *
 * Created on July 20, 2002, 5:44 PM
 */

package org.homedns.krolain.MochaJournal.LJData;

import java.lang.String;
import org.homedns.krolain.MochaJournal.Protocol.XMLgetEvents.XMLevent;
/**
 *
 * @author  krolain
 */
public class OldEventInfo extends PostEventInfo implements java.io.Serializable {
    
    public int m_iItemID = -1;
    public String m_szPoster = null;
    public java.util.Vector m_Comments = null;
    /** Creates a new instance of EventInfo */
    
    public int getEventID()
    {
        return m_iItemID;
    }
    public void setEventID(int i)
    {
        m_iItemID = i;
    }
    
    public String getPoster()
    {
        return m_szPoster;
    }
    public void setPoster(String szPoster)
    {
        m_szPoster = szPoster;
    }
    
    public LJComment[] getComments()
    {
        LJComment[] comments = new LJComment[m_Comments.size()];
        m_Comments.toArray(comments);
        return comments;
    }
    public void setComments(LJComment[] comments)
    {
        m_Comments.removeAllElements();
        m_Comments.addAll(java.util.Arrays.asList(comments));
    }
    
    public OldEventInfo() {
        m_Comments = new java.util.Vector();
    }

    protected String DecodeText(String szText) {
        if (szText == null) return null;
        
        try {
            return java.net.URLDecoder.decode(szText,"UTF-8");
        } catch (java.io.UnsupportedEncodingException e) {
            System.out.println(e);
            return "";
        }
    }
    
    public OldEventInfo(XMLevent event)
    {
        this();
        m_szSubject = XMLevent.toString(event.m_subject);
        Object obj;
        obj = event.m_props.get("current_music");
        if (obj != null)
            m_szMusic = XMLevent.toString(obj);
        m_szEvent = XMLevent.toString(event.m_event);
        if (event.m_security != null) 
        {
            for (int i = 0; i < SEC_STRING.length; i++)
            {
                if (SEC_STRING[i].compareToIgnoreCase(event.m_security) == 0)
                {
                    m_iSecurity = i;
                    break;
                }
            }
        }
        if (event.m_allowmask != null)
            m_iSec_Mask = event.m_allowmask.intValue();
        
        obj = event.m_props.get("current_moodid");
        if (obj != null)
            m_iMoodID = ((Integer)obj).intValue();
        obj = event.m_props.get("current_mood");
        if (obj != null)
            m_szMood = XMLevent.toString(obj);
        obj = event.m_props.get("opt_preformatted");
        if (obj != null)
            m_bFormated = (((Integer)obj).intValue() == 1);
        obj = event.m_props.get("opt_nocomments");
        if (obj != null)
            m_bNoComment = (((Integer)obj).intValue() == 1);
        obj = event.m_props.get("opt_noemail");
        if (obj != null)
            m_bNoEmail = (((Integer)obj).intValue() == 1);
        obj = event.m_props.get("picture_keyword");
        if (obj != null)
            m_szPickKW = (String)obj;
        obj = event.m_props.get("opt_backdated");
        if (obj != null)
            m_bBackdate = (((Integer)obj).intValue() == 1);
        m_szPoster = event.m_poster;
        m_iItemID = event.m_itemid.intValue();
        try
        {
            java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            m_Date = df.parse(event.m_eventtime);
        }
        catch (java.text.ParseException e) { System.err.println(e); }
    }
    
    public OldEventInfo(PostEventInfo e)
    {
        this();
        m_szSubject = e.m_szSubject;     
        m_szMusic = e.m_szMusic;     
        m_szEvent = e.m_szEvent;     
        m_iSecurity = e.m_iSecurity;     
        m_iSec_Mask = e.m_iSec_Mask;     
        m_iMoodID = e.m_iMoodID;     
        m_szMood = e.m_szMood;     
        m_bFormated = e.m_bFormated;     
        m_bNoComment = e.m_bNoComment;     
        m_bNoEmail = e.m_bNoEmail;     
        m_szPickKW = e.m_szPickKW;     
        m_bBackdate = e.m_bBackdate;
        m_szUseJournal = e.m_szUseJournal;
    }
}
