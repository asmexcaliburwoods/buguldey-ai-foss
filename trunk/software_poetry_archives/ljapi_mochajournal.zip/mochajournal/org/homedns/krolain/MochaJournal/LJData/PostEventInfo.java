/*
 * PostEventInfo.java
 *
 * Created on July 3, 2002, 2:22 PM
 */

/**
 *
 * @author  krolain
 */
package org.homedns.krolain.MochaJournal.LJData;
import java.lang.String;

public class PostEventInfo extends java.lang.Object implements java.io.Serializable {
    
    public static final int SEC_PUBLIC = 0;
    public static final int SEC_PRIVATE = 1;
    public static final int SEC_MASK = 2;
    public static final String[] SEC_STRING = {"public","private","usemask"};
    
    public String m_szSubject = null;     
    public String m_szMusic = null;     
    public String m_szEvent = null;     
    public int m_iSecurity = SEC_PUBLIC;     
    public int m_iSec_Mask = 0;     
    public int m_iMoodID = -1;     
    public String m_szMood = null;     
    public boolean m_bFormated = false;     
    public boolean m_bNoComment = false;     
    public boolean m_bNoEmail = false;     
    public String m_szPickKW = null;     
    public boolean m_bBackdate = false;
    public String m_szUseJournal = null;
    public java.util.Date m_Date = null;
    
    public boolean getBackdate()
    {
        return m_bBackdate;
    }
    public void setBackdate(boolean b)
    {
        m_bBackdate = b;
    }
    
    public String getJournal()
    {
        return m_szUseJournal;
    }
    public void setJournal(String szJournal)
    {
        m_szUseJournal = szJournal;
    }
    
    public boolean getFormatted()
    {
        return m_bFormated;
    }
    public void setFormatted(boolean b)
    {
        m_bFormated = b;
    }
    
    public boolean getComment()
    {
        return m_bNoComment;
    }
    public void setComment(boolean b)
    {
        m_bNoComment = b;
    }
    
    public boolean getEmail()
    {
        return m_bNoEmail;
    }
    public void setEmail(boolean b)
    {
        m_bNoEmail = b;
    }
    
    public String getPickKW()
    {
        return m_szPickKW;
    }
    public void setPickKW(String szPic)
    {
        m_szPickKW = szPic;
    }
    
    public int getSecurity()
    {
        return m_iSecurity;
    }
    public void setSecurity(int i)
    {
        m_iSecurity = i;
    }
    
    public int getSecurityMask()
    {
        return m_iSec_Mask;
    }
    public void setSecurityMask(int i)
    {
        m_iSec_Mask = i;
    }
    
    public int getMoodID()
    {
        return m_iMoodID;
    }
    public void setMoodID(int i)
    {
        m_iMoodID = i;
    }
    
    public String getMoodString()
    {
        return m_szMood;
    }
    public void setMoodString(String szMood)
    {
        m_szMood = szMood;
    }
    
    public String getSubject()
    {
        return m_szSubject;
    }
    public void setSubject(String szSubject)
    {
        m_szSubject = szSubject;
    }
    
    public String getMusic()
    {
        return m_szMusic;
    }
    public void setMusic(String szMusic)
    {
        m_szMusic = szMusic;
    }
    
    public String getEvent()
    {
        return m_szEvent;
    }
    public void setEvent(String szEvent)
    {
        m_szEvent = szEvent;
    }

    public java.util.Date getDate()
    {
        return m_Date;
    }
    public void setDate(java.util.Date date)
    {
        m_Date = date;
    }
    
    /** Creates a new instance of PostEventInfo */
    public PostEventInfo() {
        m_Date = java.util.Calendar.getInstance().getTime();
    }
}
