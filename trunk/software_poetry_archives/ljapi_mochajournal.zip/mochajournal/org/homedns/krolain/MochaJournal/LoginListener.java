/*
 * LoginListener.java
 *
 * Created on September 3, 2002, 12:07 AM
 */

package org.homedns.krolain.MochaJournal;

/**
 *
 * @author  krolain
 */
public interface LoginListener {
    
    public void LogoutDlgClosed();
}
