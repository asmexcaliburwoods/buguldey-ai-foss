/*
 * LogoutListener.java
 *
 * Created on July 8, 2002, 11:39 PM
 */

package org.homedns.krolain.MochaJournal;

/**
 *
 * @author  krolain
 */
interface LogoutListener {
    
    public void LoggedIn();
    public void SaveInfo();
    public void Reset();

    public abstract void Exit();
}
