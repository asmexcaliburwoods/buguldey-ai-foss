/*
 * JLJ.java
 *
 * Created on June 26, 2002, 11:05 PM
 */

/**
 *
 * @author  krolain
 */
package org.homedns.krolain.MochaJournal;

import java.lang.String;
import org.homedns.krolain.swing.*;
import org.homedns.krolain.MochaJournal.LJData.*;
import org.homedns.krolain.MochaJournal.LJData.LJMoods.MoodInfo;
import org.homedns.krolain.MochaJournal.Protocol.*;
import org.homedns.krolain.MochaJournal.Panels.EntryPanel;
import org.homedns.krolain.MochaJournal.Panels.HistPanel.HistPanel;
import com.oyoaha.swing.plaf.oyoaha.*;
import com.l2fprod.gui.plaf.skin.*;

import javax.swing.JDialog;
import javax.swing.JFrame;
import org.homedns.krolain.MochaJournal.InitWizard.*;
import org.homedns.krolain.util.InstallInfo;
import javax.swing.LookAndFeel;

public class MochaJournal extends Object implements LogoutListener, InitCallback, java.lang.Cloneable {
    
    EntryFrame entryFrame = null;
    XMLProtocol protocol = null;
    
    static boolean m_bDebug = false;
    InitWizard m_Wizard = null;

    protected static boolean m_bQuitting = false;
    
    /** Creates a new instance of JLJ */
    public MochaJournal() {
        try 
        {
            if (m_bDebug)
            {
                ErrorLogPrintStream wndLog = ErrorLogPrintStream.getInstance("MJOUT.LOG",false,null);
                wndLog.showWindow(true);
                System.setOut(wndLog);
            }
            else
                System.setOut(ErrorLogPrintStream.getInstance("MJOUT.LOG",false,null));
            System.setErr(ErrorLogPrintStream.getInstance("MJOUT.LOG",true,"Error!!"));
        } catch (java.io.FileNotFoundException e) {}

        entryFrame = new EntryFrame();
        
        protocol = new XMLProtocol(entryFrame);
        entryFrame.setProtocol(protocol);
        entryFrame.addLogoutListener(this);
        entryFrame.setTitle(InstallInfo.getString("app.title"));
    }

    public Object clone()
    {
        JLJSettings settings = JLJSettings.GetSettings();
        
        MochaJournal mj = new MochaJournal();
        mj.protocol = (XMLProtocol)protocol.clone();
        
        
        mj.m_Wizard = new InitWizard(mj);
        mj.restoreSettings();
        
        mj.entryFrame = (EntryFrame)entryFrame.clone();
        mj.protocol.setParent(mj.entryFrame);
        mj.entryFrame.setProtocol(mj.protocol);
        mj.entryFrame.addLogoutListener(mj);
        
        String szTitle = new String();
        szTitle = InstallInfo.getString("app.title");

        return mj;
    }
    
    public synchronized void Restart()
    {
        try
        {
            wait();
        } catch (java.lang.IllegalMonitorStateException e) { System.err.println(e); }
        catch (java.lang.InterruptedException e2) { System.err.println(e2); }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int iSize = java.util.Arrays.asList(args).size();
        for (int i = 0; i < iSize; i++)
        {
            if (args[i].compareTo("__debug__") == 0)
                m_bDebug = true;
                
        }
       
        MochaJournal mj = null;
        if (!JLJSettings.LoadSettings())  // We didn't load the settings.  Exit gracefully.
            System.exit(0);
        
        JLJSettings settings = JLJSettings.GetSettings();
        
        while (!m_bQuitting)
        {
            setLookFeel();
            if (mj == null)
                mj = new MochaJournal();
            else
                mj = (MochaJournal)mj.clone();

            mj.entryFrame.Restart();
            
            mj.Restart();
        }
    }
    
    private static void setLookFeel()
    {
        JLJSettings settings = JLJSettings.GetSettings();
        int iIndex = settings.m_iLookFeelIdx;
        String szLookFeel = settings.m_szLookFeelFile;
        try
        {
            if (iIndex == SetupDlg.DEFAULT_INDEX)
            {
                OyoahaLookAndFeel.setCurrentTheme(new javax.swing.plaf.metal.DefaultMetalTheme());
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            }
            else if (iIndex < SetupDlg.OYOAHA_LF_IDX)
            {
                UIManager.LookAndFeelInfo lf = UIManager.getInstalledLookAndFeels()[iIndex-1];
                OyoahaLookAndFeel.setCurrentTheme(new javax.swing.plaf.metal.DefaultMetalTheme());
                UIManager.setLookAndFeel(lf.getClassName());
            }
            else if (iIndex == SetupDlg.OYOAHA_LF_IDX)
            {
                OyoahaLookAndFeel lnf = new OyoahaLookAndFeel();
                java.io.File file = new java.io.File(szLookFeel);
                if(file.exists())
                    lnf.setOyoahaTheme(file);

                UIManager.setLookAndFeel(lnf);                 
            }
            else if (iIndex == SetupDlg.SKIN_LF_IDX)
            {
                if (szLookFeel.length() == 0)
                    SkinLookAndFeel.setSkin(SkinLookAndFeel.loadDefaultThemePack());
                else
                {
                    java.io.File file = new java.io.File(szLookFeel);
                    if (!file.exists())
                        SkinLookAndFeel.setSkin(SkinLookAndFeel.loadDefaultThemePack());
                    else
                        SkinLookAndFeel.setSkin(SkinLookAndFeel.loadThemePack(szLookFeel));
                }
                  UIManager.setLookAndFeel(new SkinLookAndFeel());
            }
            LookAndFeel lf = UIManager.getLookAndFeel();
            JFrame.setDefaultLookAndFeelDecorated(lf.getSupportsWindowDecorations());
            JDialog.setDefaultLookAndFeelDecorated(lf.getSupportsWindowDecorations());
        } catch (java.lang.Exception e) {
            System.err.println(e.toString());
        }
    }

    protected void restoreSettings()
    {
        JLJSettings settings = JLJSettings.GetSettings();
        LJMenus.setBrowser(settings.m_szBrowser);
        protocol.setProxySettings(settings.m_Proxy);

    }
    
    public void LoggedOut()
    {
        System.runFinalization();
        m_Wizard = new InitWizard(this);
        m_Wizard.show();
    }
    
    public synchronized void Reset()
    {
        SaveInfo();
        entryFrame.dispose();
        try
        {
            notify();
        } catch (java.lang.IllegalMonitorStateException e) { System.err.println(e); }
    }
    
    public void Exit()
    {
        m_bQuitting = true;
        System.out.close();
        System.err.close();
        if (entryFrame.m_Tray != null)
            entryFrame.m_Tray.deleteTrayIcon();
        System.exit(0);
    }
    
    public synchronized void SaveInfo()
    {
        JLJSettings settings = JLJSettings.GetSettings();
        settings.m_szBrowser = LJMenus.getBrowser();

        settings.m_Proxy = protocol.getProxySettings();
        
        if (!settings.SaveSettings())
            javax.swing.JOptionPane.showMessageDialog(entryFrame,InstallInfo.getString("string.error.no.save.data"),InstallInfo.getString("app.title"),javax.swing.JOptionPane.ERROR_MESSAGE);

        System.runFinalization();
        System.gc();
    }

    public void LoggedIn()
    {
        java.util.Timer timer = new java.util.Timer();
            timer.schedule(new java.util.TimerTask() {
                public void run() {LoggedOut();}
        },500);
    }
    
    public void InitDone() {
        if (m_Wizard.getResult() == InitWizard.OK)
        {
            restoreSettings();
            entryFrame.logIn();
        }
        else
            System.exit(0);
    }
    
}

