/*
 * EntryPanel.java
 *
 * Created on July 17, 2002, 6:43 PM
 */

package org.homedns.krolain.MochaJournal.Panels;
import org.homedns.krolain.MochaJournal.Protocol.*;
import org.homedns.krolain.MochaJournal.LJData.*;
import org.homedns.krolain.MochaJournal.LJData.LJMoods.MoodInfo;
import org.homedns.krolain.MochaJournal.EntryFrame;
import java.awt.Component;
import java.awt.Frame;
import javax.swing.*;
import javax.swing.filechooser.*;
import org.homedns.krolain.MochaJournal.Panels.HistPanel.*;
import javax.swing.JFormattedTextField;
import org.homedns.krolain.util.intBitSet;
import java.awt.event.KeyEvent;
import org.homedns.krolain.util.InstallInfo;
import com.swabunga.spell.swing.JTextComponentSpellChecker;
import org.homedns.krolain.MochaJournal.*;
import javax.swing.event.*;
import java.io.*;
import java.util.regex.*;
import java.net.URL;

class MJFileFilter extends javax.swing.filechooser.FileFilter
{
    public static final String EXTENSION=".dft";
    
    public MJFileFilter()
    {
    }
    
    public boolean accept (File file)
    {
        if (file.getName().endsWith(EXTENSION)) return true;
        return false;
    }
    
    public String getDescription()
    {
        return InstallInfo.getString("string.MJ.file");
    }
}

/**
 *
 * @author  krolain
 */
public class EntryPanel extends javax.swing.JPanel implements LJPanel, ListCellRenderer {
    public native String DetectMusic();
    public native boolean CanDetectMusic();
    
    /** Creates new form EntryPanel */
    protected XMLProtocol m_Protocol = null;
    protected PrivDlg m_PrivDlg = null;
    protected int m_iPrivIndex = 0;
    protected java.util.Vector m_FriendList = null;
    protected String[] m_szPicKWText = null;
    
    public static final int EDIT_MODE = 0;
    public static final int POST_MODE = 1;
    protected int m_iMode;
    
    LJMoods m_Moods = null;
    LJGroups m_PrivList = null;
    int m_iEntryID = -1;
    java.util.Date m_OldDate = null;
    String m_szTemplate  = null;
    
    protected void finalize() throws java.lang.Throwable {
        m_Protocol = null;
        m_PrivDlg = null;
        m_FriendList = null;
        m_Moods = null;
        m_PrivList = null;
        m_OldDate = null;
        super.finalize();
    }
    
    public EntryPanel(XMLProtocol prot,java.awt.Frame parent,int iPostMode) {
        this(prot,parent,true,iPostMode);
    }
    
    public EntryPanel(XMLProtocol prot, java.awt.Frame parent, boolean bInit,int iPostMode) {
        m_PrivDlg = new PrivDlg(parent,true);
        m_Protocol = prot;
        m_iMode = iPostMode;
        
        initComponents();

        javax.swing.ImageIcon icn = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/edit.gif"));
        jTabbedPane.setIconAt(0, icn);
        icn = new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/preview.gif"));
        jTabbedPane.setIconAt(1, icn);
        
        jPrivacyList.insertItemAt(InstallInfo.getString("group.custom"),0);
        jPrivacyList.insertItemAt(InstallInfo.getString("group.friends"),0);
        jPrivacyList.insertItemAt(InstallInfo.getString("group.private"),0);
        jPrivacyList.insertItemAt(InstallInfo.getString("group.public"),0);
        jPrivacyList.setSelectedIndex(0);
        
        if (m_iMode == POST_MODE) {
            jLabel7.setEnabled(false);
            jLabel7.setVisible(false);
            m_EntryDate.setEnabled(false);
            m_EntryDate.setVisible(false);
            jDelBtn.setEnabled(false);
            jDelBtn.setVisible(false);
        }
        if (m_iMode == EDIT_MODE) {
            jJournalList.setEnabled(false);
            jJournalList.setVisible(false);
            jLabel6.setEnabled(false);
            jLabel6.setVisible(false);
            jClearBtn.setText(InstallInfo.getString("button.close"));
        }
        
        String szInstallPath = InstallInfo.getInstallPath();
        String fs = System.getProperty("file.separator");
        String szLibPath = szInstallPath+fs+"Library";
        
        if (szLibPath != null) {
            try {
                String szLib = System.mapLibraryName(szLibPath+fs+"DetMusic");
                System.load(szLib);
                if (!CanDetectMusic())
                    jDetectBtn.setVisible(false);
                else
                    jDetectBtn.setEnabled(true);
            } catch (java.lang.UnsatisfiedLinkError e) {
                jDetectBtn.setVisible(false);
                System.out.println(e);
            }
        }
        else
            jDetectBtn.setVisible(false);
        
        // Read the base HTML template for formatting.
        m_szTemplate = "";
        try {
            InputStream i = getClass().getResourceAsStream("/org/homedns/krolain/MochaJournal/template.html");
            BufferedReader input = new BufferedReader(new InputStreamReader(i));
            String szRead = input.readLine();
            while (szRead != null) {
                m_szTemplate = m_szTemplate.concat(szRead);
                szRead = input.readLine();
            }
        } catch (java.io.IOException e) {}
        
        revalidate();
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        java.awt.GridBagConstraints gridBagConstraints;

        jEditMenu = new javax.swing.JMenu();
        jCutItem = new javax.swing.JMenuItem();
        jCopyItem = new javax.swing.JMenuItem();
        jPasteItem = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jMenu1 = new javax.swing.JMenu();
        jUsrLnkItem = new javax.swing.JMenuItem();
        jCommLnkItem = new javax.swing.JMenuItem();
        jCutLnkItem = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jBackDateItem = new javax.swing.JCheckBoxMenuItem();
        jNoCommentItem = new javax.swing.JCheckBoxMenuItem();
        jNoMailNotifyItem = new javax.swing.JCheckBoxMenuItem();
        jSaveItem = new javax.swing.JMenuItem();
        jLoadItem = new javax.swing.JMenuItem();
        jViewMenu = new javax.swing.JMenu();
        jEditBarOn = new javax.swing.JCheckBoxMenuItem();
        jWebBarOn = new javax.swing.JCheckBoxMenuItem();
        jLJBarOn = new javax.swing.JCheckBoxMenuItem();
        jMiscBarOn = new javax.swing.JCheckBoxMenuItem();
        jTabbedPane = new javax.swing.JTabbedPane();
        jEditPane = new javax.swing.JPanel();
        jToolBar1 = new javax.swing.JToolBar();
        jFileToolBar = new javax.swing.JToolBar();
        jSaveBtn = new javax.swing.JButton();
        jOpenBtn = new javax.swing.JButton();
        jEditToolBar = new javax.swing.JToolBar();
        jCutBtn = new javax.swing.JButton();
        jCopyBtn = new javax.swing.JButton();
        jPasteBtn = new javax.swing.JButton();
        jFmtToolBar = new javax.swing.JToolBar();
        jBoldBtn = new javax.swing.JButton();
        jItalBtn = new javax.swing.JButton();
        jUnderBth = new javax.swing.JButton();
        jColourBtn = new javax.swing.JButton();
        jLnkBtn = new javax.swing.JButton();
        jImgSrcBtn = new javax.swing.JButton();
        jLJToolBar = new javax.swing.JToolBar();
        jLJUsrBtn = new javax.swing.JButton();
        jLJCommBtn = new javax.swing.JButton();
        jMiscToolBar = new javax.swing.JToolBar();
        jSpellBtn = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        m_EntryDate = new JFormattedTextField(new java.text.SimpleDateFormat("MMMM d, yyyy HH:mm:ss"));
        jLabel1 = new javax.swing.JLabel();
        jSubjectField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jMusicField = new javax.swing.JTextField();
        jDetectBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jEntryText = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPicList = new javax.swing.JComboBox();
        jMoodList = new javax.swing.JComboBox();
        jJournalList = new javax.swing.JComboBox();
        jPanel1 = new javax.swing.JPanel();
        jPrivacyList = new javax.swing.JComboBox();
        jCustBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPreviewPane = new javax.swing.JTextPane();
        jPanel3 = new javax.swing.JPanel();
        jPostBtn = new javax.swing.JButton();
        jUploadTime = new javax.swing.JCheckBox();
        jDelBtn = new javax.swing.JButton();
        jClearBtn = new javax.swing.JButton();

        jEditMenu.setMnemonic(KeyEvent.VK_E);
        jEditMenu.setText(InstallInfo.getString("menu.edit"));
        jEditMenu.setEnabled(false);
        jCutItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        jCutItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/cut.gif")));
        jCutItem.setMnemonic(KeyEvent.VK_T);
        jCutItem.setText(InstallInfo.getString("menu.cut"));
        jCutItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCutActionPerformed(evt);
            }
        });

        jEditMenu.add(jCutItem);

        jCopyItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jCopyItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/copy.gif")));
        jCopyItem.setMnemonic(KeyEvent.VK_C);
        jCopyItem.setText(InstallInfo.getString("menu.copy"));
        jCopyItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCopyActionPerformed(evt);
            }
        });

        jEditMenu.add(jCopyItem);

        jPasteItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        jPasteItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/paste.gif")));
        jPasteItem.setMnemonic(KeyEvent.VK_P);
        jPasteItem.setText(InstallInfo.getString("menu.paste"));
        jPasteItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasteActionPerformed(evt);
            }
        });

        jEditMenu.add(jPasteItem);

        jEditMenu.add(jSeparator1);

        jMenu1.setMnemonic(KeyEvent.VK_I);
        jMenu1.setText(InstallInfo.getString("menu.insert"));
        jUsrLnkItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        jUsrLnkItem.setMnemonic(KeyEvent.VK_U);
        jUsrLnkItem.setText(InstallInfo.getString("menu.ljuserlink"));
        jUsrLnkItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUsrLnkItemActionPerformed(evt);
            }
        });

        jMenu1.add(jUsrLnkItem);

        jCommLnkItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        jCommLnkItem.setMnemonic(KeyEvent.VK_M);
        jCommLnkItem.setText(InstallInfo.getString("menu.ljcommunitylink"));
        jCommLnkItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCommLnkItemActionPerformed(evt);
            }
        });

        jMenu1.add(jCommLnkItem);

        jCutLnkItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_H, java.awt.event.InputEvent.CTRL_MASK));
        jCutLnkItem.setMnemonic(KeyEvent.VK_H);
        jCutLnkItem.setText(InstallInfo.getString("menu.ljcutlink"));
        jCutLnkItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCutLnkItemActionPerformed(evt);
            }
        });

        jMenu1.add(jCutLnkItem);

        jEditMenu.add(jMenu1);

        jMenu2.setMnemonic(KeyEvent.VK_X);
        jMenu2.setText(InstallInfo.getString("menu.extra.post"));
        jBackDateItem.setMnemonic(KeyEvent.VK_B);
        jBackDateItem.setText(InstallInfo.getString("menu.backdate"));
        jMenu2.add(jBackDateItem);

        jNoCommentItem.setMnemonic(KeyEvent.VK_D);
        jNoCommentItem.setText(InstallInfo.getString("menu.no.comment"));
        jMenu2.add(jNoCommentItem);

        jNoMailNotifyItem.setMnemonic(KeyEvent.VK_E);
        jNoMailNotifyItem.setText(InstallInfo.getString("menu.no.email"));
        jMenu2.add(jNoMailNotifyItem);

        jEditMenu.add(jMenu2);

        jSaveItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jSaveItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/save.gif")));
        jSaveItem.setText(InstallInfo.getString("menu.save"));
        jSaveItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSaveActionPerformed(evt);
            }
        });

        jLoadItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        jLoadItem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/open.gif")));
        jLoadItem.setText(InstallInfo.getString("menu.load"));
        jLoadItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOpenActionPerformed(evt);
            }
        });

        jViewMenu.setText(InstallInfo.getString("menu.view"));
        jViewMenu.setEnabled(false);
        jEditBarOn.setSelected(true);
        jEditBarOn.setText(InstallInfo.getString("menu.toolbar.edit"));
        jEditBarOn.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jBarOnItemStateChanged(evt);
            }
        });

        jViewMenu.add(jEditBarOn);

        jWebBarOn.setSelected(true);
        jWebBarOn.setText(InstallInfo.getString("menu.toolbar.web"));
        jWebBarOn.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jBarOnItemStateChanged(evt);
            }
        });

        jViewMenu.add(jWebBarOn);

        jLJBarOn.setSelected(true);
        jLJBarOn.setText(InstallInfo.getString("menu.toolbar.LJ"));
        jLJBarOn.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jBarOnItemStateChanged(evt);
            }
        });

        jViewMenu.add(jLJBarOn);

        jMiscBarOn.setSelected(true);
        jMiscBarOn.setText(InstallInfo.getString("menu.toolbar.misc"));
        jMiscBarOn.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jBarOnItemStateChanged(evt);
            }
        });

        jViewMenu.add(jMiscBarOn);

        setLayout(new java.awt.BorderLayout());

        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                formComponentHidden(evt);
            }
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jTabbedPane.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);
        jTabbedPane.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPaneStateChanged(evt);
            }
        });

        jEditPane.setLayout(new java.awt.GridBagLayout());

        jToolBar1.setBorder(null);
        jToolBar1.setFloatable(false);
        jToolBar1.setRollover(true);
        jFileToolBar.setBorder(new javax.swing.border.EtchedBorder());
        jFileToolBar.setFloatable(false);
        jFileToolBar.setRollover(true);
        jSaveBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/save.gif")));
        jSaveBtn.setToolTipText(InstallInfo.getString("tooltip.save"));
        jSaveBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jSaveBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jSaveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSaveActionPerformed(evt);
            }
        });

        jFileToolBar.add(jSaveBtn);

        jOpenBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/open.gif")));
        jOpenBtn.setToolTipText(InstallInfo.getString("tooltip.load"));
        jOpenBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jOpenBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jOpenBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOpenActionPerformed(evt);
            }
        });

        jFileToolBar.add(jOpenBtn);

        jToolBar1.add(jFileToolBar);

        jEditToolBar.setBorder(new javax.swing.border.EtchedBorder());
        jEditToolBar.setFloatable(false);
        jEditToolBar.setRollover(true);
        jCutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/cut.gif")));
        jCutBtn.setToolTipText(InstallInfo.getString("tooltip.cut"));
        jCutBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jCutBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jCutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCutActionPerformed(evt);
            }
        });

        jEditToolBar.add(jCutBtn);

        jCopyBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/copy.gif")));
        jCopyBtn.setToolTipText(InstallInfo.getString("tooltip.copy"));
        jCopyBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jCopyBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jCopyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCopyActionPerformed(evt);
            }
        });

        jEditToolBar.add(jCopyBtn);

        jPasteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/paste.gif")));
        jPasteBtn.setToolTipText(InstallInfo.getString("tooltip.paste"));
        jPasteBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jPasteBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jPasteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasteActionPerformed(evt);
            }
        });

        jEditToolBar.add(jPasteBtn);

        jToolBar1.add(jEditToolBar);

        jFmtToolBar.setBorder(new javax.swing.border.EtchedBorder());
        jFmtToolBar.setFloatable(false);
        jFmtToolBar.setRollover(true);
        jBoldBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/bold.gif")));
        jBoldBtn.setToolTipText(InstallInfo.getString("tooltip.bold"));
        jBoldBtn.setMaximumSize(new java.awt.Dimension(28, 28));
        jBoldBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jBoldBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jBoldBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBoldBtnActionPerformed(evt);
            }
        });

        jFmtToolBar.add(jBoldBtn);

        jItalBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/italic.gif")));
        jItalBtn.setToolTipText(InstallInfo.getString("tooltip.italic"));
        jItalBtn.setMaximumSize(new java.awt.Dimension(28, 28));
        jItalBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jItalBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jItalBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jItalBtnActionPerformed(evt);
            }
        });

        jFmtToolBar.add(jItalBtn);

        jUnderBth.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/underline.gif")));
        jUnderBth.setToolTipText(InstallInfo.getString("tooltip.underline"));
        jUnderBth.setMaximumSize(new java.awt.Dimension(28, 28));
        jUnderBth.setMinimumSize(new java.awt.Dimension(20, 20));
        jUnderBth.setPreferredSize(new java.awt.Dimension(24, 24));
        jUnderBth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUnderBthActionPerformed(evt);
            }
        });

        jFmtToolBar.add(jUnderBth);

        jColourBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/palette.gif")));
        jColourBtn.setToolTipText(InstallInfo.getString("tooltip.colour"));
        jColourBtn.setMaximumSize(new java.awt.Dimension(28, 28));
        jColourBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jColourBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jColourBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jColourBtnActionPerformed(evt);
            }
        });

        jFmtToolBar.add(jColourBtn);

        jLnkBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/link.gif")));
        jLnkBtn.setToolTipText(InstallInfo.getString("tooltip.web.link"));
        jLnkBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jLnkBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jLnkBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jLnkBtnActionPerformed(evt);
            }
        });

        jFmtToolBar.add(jLnkBtn);

        jImgSrcBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/picture.gif")));
        jImgSrcBtn.setToolTipText(InstallInfo.getString("tooltip.web.image"));
        jImgSrcBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jImgSrcBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jImgSrcBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jImgSrcBtnActionPerformed(evt);
            }
        });

        jFmtToolBar.add(jImgSrcBtn);

        jToolBar1.add(jFmtToolBar);

        jLJToolBar.setBorder(new javax.swing.border.EtchedBorder());
        jLJToolBar.setFloatable(false);
        jLJToolBar.setRollover(true);
        jLJUsrBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/ljuser.gif")));
        jLJUsrBtn.setToolTipText(InstallInfo.getString("tooltip.lj.user"));
        jLJUsrBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jLJUsrBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jLJUsrBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jUsrLnkItemActionPerformed(evt);
            }
        });

        jLJToolBar.add(jLJUsrBtn);

        jLJCommBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/ljcomm.gif")));
        jLJCommBtn.setToolTipText(InstallInfo.getString("tooltip.lj.comm"));
        jLJCommBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jLJCommBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jLJCommBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCommLnkItemActionPerformed(evt);
            }
        });

        jLJToolBar.add(jLJCommBtn);

        jToolBar1.add(jLJToolBar);

        jMiscToolBar.setBorder(new javax.swing.border.EtchedBorder());
        jMiscToolBar.setFloatable(false);
        jMiscToolBar.setRollover(true);
        jSpellBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/spell.gif")));
        jSpellBtn.setToolTipText(InstallInfo.getString("tooltip.spell"));
        jSpellBtn.setMinimumSize(new java.awt.Dimension(20, 20));
        jSpellBtn.setPreferredSize(new java.awt.Dimension(24, 24));
        jSpellBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSpellBtnActionPerformed(evt);
            }
        });

        jMiscToolBar.add(jSpellBtn);

        jToolBar1.add(jMiscToolBar);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        jEditPane.add(jToolBar1, gridBagConstraints);

        jLabel7.setLabelFor(m_EntryDate);
        jLabel7.setText(InstallInfo.getString("label.entry"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 1, 1);
        jEditPane.add(jLabel7, gridBagConstraints);

        m_EntryDate.setColumns(32);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(5, 0, 1, 5);
        jEditPane.add(m_EntryDate, gridBagConstraints);

        jLabel1.setLabelFor(jSubjectField);
        jLabel1.setText(InstallInfo.getString("label.subject"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 1, 1);
        jEditPane.add(jLabel1, gridBagConstraints);

        jSubjectField.setColumns(32);
        jSubjectField.setMinimumSize(new java.awt.Dimension(100, 20));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 1, 5);
        jEditPane.add(jSubjectField, gridBagConstraints);

        jLabel3.setLabelFor(jMusicField);
        jLabel3.setText(InstallInfo.getString("label.music"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 1);
        jEditPane.add(jLabel3, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        jEditPane.add(jMusicField, gridBagConstraints);

        jDetectBtn.setMnemonic(KeyEvent.VK_D);
        jDetectBtn.setText(InstallInfo.getString("button.detect"));
        jDetectBtn.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jDetectBtn.setEnabled(false);
        jDetectBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDetectBtnActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(0, 1, 0, 5);
        jEditPane.add(jDetectBtn, gridBagConstraints);

        jEntryText.setColumns(32);
        jEntryText.setLineWrap(true);
        jEntryText.setRows(10);
        jEntryText.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jEntryText);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 3, 5);
        jEditPane.add(jScrollPane1, gridBagConstraints);

        jLabel5.setLabelFor(jPicList);
        jLabel5.setText(InstallInfo.getString("label.picture"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.weightx = 0.25;
        jEditPane.add(jLabel5, gridBagConstraints);

        jLabel2.setLabelFor(jMoodList);
        jLabel2.setText(InstallInfo.getString("label.mood"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.weightx = 0.25;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 1);
        jEditPane.add(jLabel2, gridBagConstraints);

        jLabel6.setLabelFor(jJournalList);
        jLabel6.setText(InstallInfo.getString("label.journal"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.weightx = 0.25;
        gridBagConstraints.insets = new java.awt.Insets(0, 1, 0, 0);
        jEditPane.add(jLabel6, gridBagConstraints);

        jLabel4.setLabelFor(jPrivacyList);
        jLabel4.setText(InstallInfo.getString("label.privacy"));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.weightx = 0.25;
        gridBagConstraints.insets = new java.awt.Insets(0, 1, 0, 5);
        jEditPane.add(jLabel4, gridBagConstraints);

        jPicList.setRenderer(this);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.25;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 1);
        jEditPane.add(jPicList, gridBagConstraints);

        jMoodList.setEditable(true);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.25;
        gridBagConstraints.insets = new java.awt.Insets(0, 5, 0, 1);
        jEditPane.add(jMoodList, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.25;
        jEditPane.add(jJournalList, gridBagConstraints);

        jPanel1.setLayout(new java.awt.GridBagLayout());

        jPrivacyList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPrivacyListActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        jPanel1.add(jPrivacyList, gridBagConstraints);

        jCustBtn.setText("...");
        jCustBtn.setMargin(new java.awt.Insets(1, 1, 1, 1));
        jCustBtn.setEnabled(false);
        jCustBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCustBtnActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        jPanel1.add(jCustBtn, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 0.25;
        gridBagConstraints.insets = new java.awt.Insets(0, 1, 0, 5);
        jEditPane.add(jPanel1, gridBagConstraints);

        jTabbedPane.addTab("Edit", new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/edit.gif")), jEditPane);

        jPreviewPane.setEditable(false);
        jPreviewPane.setEditorKit(new javax.swing.text.html.HTMLEditorKit());
        jScrollPane2.setViewportView(jPreviewPane);

        jTabbedPane.addTab("Preview", new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/preview.gif")), jScrollPane2);

        add(jTabbedPane, java.awt.BorderLayout.CENTER);

        jPanel3.setLayout(new java.awt.GridBagLayout());

        jPostBtn.setMnemonic(KeyEvent.VK_P);
        jPostBtn.setText(InstallInfo.getString("button.post"));
        jPostBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPostBtnActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(3, 5, 5, 0);
        jPanel3.add(jPostBtn, gridBagConstraints);

        jUploadTime.setText("Use upload time");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.3;
        jPanel3.add(jUploadTime, gridBagConstraints);

        jDelBtn.setMnemonic(KeyEvent.VK_R);
        jDelBtn.setText(InstallInfo.getString("button.remove"));
        jDelBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDelBtnActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.weightx = 0.4;
        gridBagConstraints.insets = new java.awt.Insets(3, 0, 5, 0);
        jPanel3.add(jDelBtn, gridBagConstraints);

        jClearBtn.setMnemonic(KeyEvent.VK_C);
        jClearBtn.setText(InstallInfo.getString("button.clear"));
        jClearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jClearBtnActionPerformed(evt);
            }
        });

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.REMAINDER;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(3, 0, 5, 5);
        jPanel3.add(jClearBtn, gridBagConstraints);

        add(jPanel3, java.awt.BorderLayout.SOUTH);

    }//GEN-END:initComponents

    private void jImgSrcBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jImgSrcBtnActionPerformed
        Frame frame = (Frame)SwingUtilities.getAncestorOfClass(Frame.class, this);
        String szImg = ImageDlg.showDialog(frame);
        if (szImg.length() > 0)
            jEntryText.insert(szImg,jEntryText.getCaretPosition());
    }//GEN-LAST:event_jImgSrcBtnActionPerformed

    private void jLnkBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jLnkBtnActionPerformed
        String szAddr = JOptionPane.showInputDialog(this,InstallInfo.getString("string.web.addr"));
        if ((szAddr != null) && (szAddr.length() > 0))
            insertFormat("<a href=\""+szAddr+"\">","</a>");
    }//GEN-LAST:event_jLnkBtnActionPerformed

    private void jBarOnItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jBarOnItemStateChanged
        if (evt.getItem().equals(jEditBarOn))
            jEditToolBar.setVisible(evt.getStateChange() == evt.SELECTED);
        if (evt.getItem().equals(jWebBarOn))
            jFmtToolBar.setVisible(evt.getStateChange() == evt.SELECTED);
        if (evt.getItem().equals(jLJBarOn))
            jLJToolBar.setVisible(evt.getStateChange() == evt.SELECTED);
        if (evt.getItem().equals(jMiscBarOn))
            jMiscToolBar.setVisible(evt.getStateChange() == evt.SELECTED);
    }//GEN-LAST:event_jBarOnItemStateChanged

    private void formComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentHidden
        jEditMenu.setEnabled(false);
        jViewMenu.setEnabled(false);
    }//GEN-LAST:event_formComponentHidden

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        jEditMenu.setEnabled(true);
        jViewMenu.setEnabled(true);
        if (EntryFrame.m_bOnline)
        {
            jUploadTime.setVisible(false);
            jUploadTime.setEnabled(false);
        }
    }//GEN-LAST:event_formComponentShown

    private void jOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOpenActionPerformed
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Protocol.getUserName()+System.getProperty("file.separator")+"Draft";
        File file = new File(szPath);
        file.mkdirs();
        JFileChooser fc = new JFileChooser(file);
        fc.setDialogType(fc.SAVE_DIALOG);
        fc.setDialogTitle("Open Draft");
        fc.setLocale(JLJSettings.GetSettings().m_ProgLocale);
        fc.setFileFilter(new MJFileFilter());
        fc.setFileSelectionMode(fc.FILES_ONLY);
        int iResult = fc.showOpenDialog(this);
        if (iResult == fc.APPROVE_OPTION)
        {
            try
            {
                String filename = fc.getSelectedFile().getName();
                if (!filename.endsWith(MJFileFilter.EXTENSION)) filename += MJFileFilter.EXTENSION;
                File draft = new File(file,filename);
                if (!draft.exists()) draft.createNewFile();
                java.beans.XMLDecoder decode = new java.beans.XMLDecoder(new java.io.FileInputStream(draft));
                PostEventInfo info = (PostEventInfo)decode.readObject();
                decode.close();
                setEventInfo(info);
            } catch (IOException e) { System.err.println(e); }
        }
        
    }//GEN-LAST:event_jOpenActionPerformed

    private void jSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSaveActionPerformed
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Protocol.getUserName()+System.getProperty("file.separator")+"Draft";
        File file = new File(szPath);
        file.mkdirs();
        JFileChooser fc = new JFileChooser(file);
        fc.setDialogType(fc.SAVE_DIALOG);
        fc.setDialogTitle("Save Draft");
        fc.setLocale(JLJSettings.GetSettings().m_ProgLocale);
        fc.setFileFilter(new MJFileFilter());
        fc.setFileSelectionMode(fc.FILES_ONLY);
        int iResult = fc.showSaveDialog(this);
        if (iResult == fc.APPROVE_OPTION)
        {
            try
            {
                String filename = fc.getSelectedFile().getName();
                if (!filename.endsWith(MJFileFilter.EXTENSION)) filename += MJFileFilter.EXTENSION;
                File draft = new File(file,filename);
                if (!draft.exists()) draft.createNewFile();
                java.beans.XMLEncoder encode = new java.beans.XMLEncoder(new java.io.FileOutputStream(draft));
                PostEventInfo info = getEventInfo();
                encode.writeObject(info);
                encode.close();
            } catch (IOException e) { System.err.println(e); }
        }
    }//GEN-LAST:event_jSaveActionPerformed
    
    private void jTabbedPaneStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPaneStateChanged
        int iIndex = jTabbedPane.getSelectedIndex();
        String szSource = "";
        if (iIndex == 1) // We are in the preview pane
        {
            PostEventInfo info = getEventInfo();
            if (info != null)
            {
                HTMLExport export = new HTMLExport(false,null);
                String uName = "";
                if (EntryFrame.m_bOnline)
                    uName = m_Protocol.getUserName();
                else
                    uName = "krolain";
                String szDir = System.getProperty("user.home");
                szDir += System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+uName+System.getProperty("file.separator")+"null";
                if (export.NewDocument(szDir,uName,null))
                {
                    OldEventInfo[] events = new OldEventInfo[1];
                    events[0] = new OldEventInfo(info);
                    export.insertEntries(events);
                    export.closeDocument();
                    szSource = export.getHTMLCode();
                    if (szSource == null) szSource = "";
                }
            }
            jPreviewPane.setText(szSource);
        }
    }//GEN-LAST:event_jTabbedPaneStateChanged
    
    private void jSpellBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSpellBtnActionPerformed
        JTextComponentSpellChecker spellCheck = new JTextComponentSpellChecker(JLJSettings.GetSettings().GetDictionary());
        spellCheck.spellCheck(jEntryText);
    }//GEN-LAST:event_jSpellBtnActionPerformed
    
    private void jColourBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jColourBtnActionPerformed
        java.awt.Color colour = javax.swing.JColorChooser.showDialog(this,"Select a text colour",java.awt.Color.black);
        String szColour = java.lang.Integer.toHexString(colour.getRGB());
        szColour = "#"+szColour.substring(2);
        insertFormat("<FONT COLOR=\""+szColour+"\">","</FONT>");
    }//GEN-LAST:event_jColourBtnActionPerformed
    
    private void jUnderBthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jUnderBthActionPerformed
        insertFormat("<u>","</u>");
    }//GEN-LAST:event_jUnderBthActionPerformed
    
    private void jItalBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jItalBtnActionPerformed
        insertFormat("<I>","</I>");
    }//GEN-LAST:event_jItalBtnActionPerformed
    
    private void jBoldBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBoldBtnActionPerformed
        insertFormat("<B>","</B>");
    }//GEN-LAST:event_jBoldBtnActionPerformed
    
    private void jDetectBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDetectBtnActionPerformed
        String szMusic = DetectMusic();
        System.out.println("Music Detected: "+szMusic);
        jMusicField.setText(szMusic);
    }//GEN-LAST:event_jDetectBtnActionPerformed
    
    private void jDelBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDelBtnActionPerformed
        // Add your handling code here:
        jEntryText.setText("");
        jSubjectField.setText("");
        jPostBtnActionPerformed(evt);
    }//GEN-LAST:event_jDelBtnActionPerformed
    
    private void jCustBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCustBtnActionPerformed
        m_PrivDlg.setLocationRelativeTo(this);
        m_PrivDlg.show();
    }//GEN-LAST:event_jCustBtnActionPerformed
    
    private void jPrivacyListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPrivacyListActionPerformed
        // Add your handling code here:
        if (isVisible() && (jPrivacyList.getSelectedIndex() == 3 )) {
            m_PrivDlg.setLocationRelativeTo(this);
            m_PrivDlg.show();
            if (m_PrivDlg.getResult() == m_PrivDlg.OK) {
                m_iPrivIndex = jPrivacyList.getSelectedIndex();
            }
            else
                jPrivacyList.setSelectedIndex(m_iPrivIndex);
        }
        else
            m_iPrivIndex = jPrivacyList.getSelectedIndex();
        if (jPrivacyList.getSelectedIndex() == 3 )
            jCustBtn.setEnabled(true);
        else
            jCustBtn.setEnabled(false);
    }//GEN-LAST:event_jPrivacyListActionPerformed
    
    private void insertFormat(String szStart, String szEnd) {
        int iStart = jEntryText.getSelectionStart();
        int iEnd = jEntryText.getSelectionEnd();
        if (iStart != iEnd) {
            jEntryText.insert(szStart,iStart);
            jEntryText.insert(szEnd,iEnd+szStart.length());
        }
        else {
            jEntryText.insert(szEnd,iEnd);
            jEntryText.insert(szStart,iEnd);
        }
        jEntryText.setSelectionStart(jEntryText.getSelectionEnd());
    }
    
    private void jCutLnkItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCutLnkItemActionPerformed
        // Add your handling code here:
        String szText,szStart;
        szText = javax.swing.JOptionPane.showInputDialog(this,InstallInfo.getString("label.insert.cut.link"));
        if ((szText != null) && (szText.length() > 0))
            szStart = "<lj-cut text=\""+szText+"\">";
        else
            szStart = "<lj-cut>";
        insertFormat(szStart,"</lj-cut>");
    }//GEN-LAST:event_jCutLnkItemActionPerformed
    
    private void jCommLnkItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCommLnkItemActionPerformed
        // Add your handling code here:
        String szLJComm;
        String szText;
        szLJComm = javax.swing.JOptionPane.showInputDialog(this,InstallInfo.getString("label.insert.community.link"));
        if ((szLJComm != null) && (szLJComm.length() > 0)) {
            szText = "<lj comm=\""+szLJComm+"\">";
            jEntryText.insert(szText,jEntryText.getCaretPosition());
        }
    }//GEN-LAST:event_jCommLnkItemActionPerformed
    
    private void jUsrLnkItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jUsrLnkItemActionPerformed
        // Add your handling code here:
        String szLJUname;
        String szText;
        szLJUname = javax.swing.JOptionPane.showInputDialog(this,InstallInfo.getString("label.insert.friend.link"));
        if ((szLJUname != null) && (szLJUname.length() > 0)) {
            szText = "<lj user=\""+szLJUname+"\">";
            jEntryText.insert(szText,jEntryText.getCaretPosition());
        }
    }//GEN-LAST:event_jUsrLnkItemActionPerformed
    
    private void jPasteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasteActionPerformed
        // Add your handling code here:
        jEntryText.paste();
    }//GEN-LAST:event_jPasteActionPerformed
    
    private void jCopyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCopyActionPerformed
        // Add your handling code here:
        jEntryText.copy();
    }//GEN-LAST:event_jCopyActionPerformed
    
    private void jCutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCutActionPerformed
        // Add your handling code here:
        jEntryText.cut();
    }//GEN-LAST:event_jCutActionPerformed
    
    private void jClearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jClearBtnActionPerformed
        // Add your handling code here:
        if (m_iMode == POST_MODE) {
            jEntryText.setText("");
            jMusicField.setText("");
            jSubjectField.setText("");
            if (jPicList.isEnabled())
                jPicList.setSelectedIndex(0);
            if (jMoodList.isEnabled())
                jMoodList.setSelectedIndex(0);
            jPrivacyList.setSelectedIndex(0);
            if (jJournalList.isEnabled())
                jJournalList.setSelectedIndex(0);
            jBackDateItem.setState(false);
            jNoMailNotifyItem.setState(false);
            jNoCommentItem.setState(false);
        }
    }//GEN-LAST:event_jClearBtnActionPerformed
    
    private void postNewEntry() {
        PostEventInfo eventInfo = getEventInfo();
        if (eventInfo != null)
        {
            XMLpostEvent event = m_Protocol.postEvent(eventInfo);
            if (!event.m_bSentOK) {
                java.awt.Container comp = this;
                while ((comp = comp.getParent()) != null) {
                    if (comp instanceof EntryFrame) {
                        ((EntryFrame)comp).setStatus(InstallInfo.getString("string.error.post"));
                    }
                }
            }
            else {   // Clear everything if the post went well!
                jClearBtnActionPerformed(new java.awt.event.ActionEvent(this,0x0,"Post"));
                java.awt.Container comp = this;
                while ((comp = comp.getParent()) != null) {
                    if (comp instanceof EntryFrame) {
                        ((EntryFrame)comp).setStatus(InstallInfo.getString("string.ok.post"));
                        if (m_iMode == POST_MODE)
                            ((EntryFrame)comp).addNewPost();
                    }
                }

            }
        }

    }

    private void setEventInfo(PostEventInfo eventInfo)
    {
        jEntryText.setText(eventInfo.m_szEvent);
        jSubjectField.setText(eventInfo.m_szSubject);
        jMusicField.setText(eventInfo.m_szMusic);
        if (eventInfo.m_iMoodID != -1)
        {
            int iSize = jMoodList.getItemCount();
            for (int i = 0; i < iSize; i++)
            {
                MoodInfo mood = (MoodInfo)jMoodList.getItemAt(i);
                if (mood.m_iMoodID == eventInfo.m_iMoodID)
                {
                    jMoodList.setSelectedIndex(i);
                    break;
                }
            }
        }
        else
            jMoodList.setSelectedItem(eventInfo.m_szMood);
        
        if (eventInfo.m_szPickKW != null)
        {
            for (int i = 0; i < m_szPicKWText.length; i++)
            {
                if (m_szPicKWText[i].compareToIgnoreCase(eventInfo.m_szPickKW) == 0)
                {
                    jPicList.setSelectedIndex(i);
                    break;
                }
            }
        }

        if (eventInfo.m_szUseJournal != null)
            jJournalList.setSelectedItem(eventInfo.m_szUseJournal);

        if ((eventInfo.m_iSecurity == PostEventInfo.SEC_MASK) && (eventInfo.m_iSec_Mask == 1))
            jPrivacyList.setSelectedIndex(2);
        else if (eventInfo.m_iSecurity < 2)
            jPrivacyList.setSelectedIndex(eventInfo.m_iSecurity);
        else
        {
            jPrivacyList.setSelectedIndex(3);
            intBitSet mask = new intBitSet(eventInfo.m_iSec_Mask);
            java.util.Vector list = new java.util.Vector();
            int iBit = mask.nextSetBit(0);
            while (iBit != -1)
            {
                list.add(new java.lang.Integer(iBit));
                iBit = mask.nextSetBit(iBit + 1);
            }
            m_PrivDlg.setSelectedValues(list);
        }
    
        jBackDateItem.setState(eventInfo.m_bBackdate);
        jNoMailNotifyItem.setState(eventInfo.m_bNoEmail);
        jNoCommentItem.setState(eventInfo.m_bNoComment);
    }
    
    private PostEventInfo getEventInfo()
    {
        // Add your handling code here:
        PostEventInfo eventInfo = new PostEventInfo();
        
        try {
            eventInfo.m_szEvent = jEntryText.getText();
            if (eventInfo.m_szEvent.length() < 1) return null;
        }
        catch (java.lang.NullPointerException e) {
            // At the very least, we need some text in this component to post something to LJ
            return null;
        }
        try {
            eventInfo.m_szSubject = jSubjectField.getText();
        }
        catch (java.lang.NullPointerException e) {}
        try {
            eventInfo.m_szMusic = jMusicField.getText();
        }
        catch (java.lang.NullPointerException e) {}
        java.lang.Object moodObj = jMoodList.getSelectedItem();
        if (moodObj instanceof MoodInfo)
            eventInfo.m_iMoodID = ((MoodInfo)moodObj).m_iMoodID;
        else if (moodObj instanceof String)
            eventInfo.m_szMood = ((String)moodObj);
        if (jPicList.getSelectedIndex() > 0) {
            java.lang.Object picObj = jPicList.getSelectedItem();
            if (picObj instanceof Integer)
                eventInfo.m_szPickKW = m_szPicKWText[((Integer)picObj).intValue()];
        }
        if (jJournalList.getSelectedIndex() > 0) {
            java.lang.Object journalObj = jJournalList.getSelectedItem();
            if (journalObj instanceof String)
                eventInfo.m_szUseJournal = ((String)journalObj);
        }
        int iPrivIdx = jPrivacyList.getSelectedIndex();
        if (iPrivIdx == 2) {
            eventInfo.m_iSecurity = PostEventInfo.SEC_MASK;
            eventInfo.m_iSec_Mask = 1;
        }
        else if (iPrivIdx < 2) {
            eventInfo.m_iSecurity = iPrivIdx;
        }
        else {
            Object objs[] = m_PrivDlg.getSelectedValues();
            int iMax = objs.length;
            eventInfo.m_iSecurity = PostEventInfo.SEC_MASK;
            eventInfo.m_iSec_Mask = 0;
            intBitSet mask = new intBitSet();
            for (int i = 0; i < iMax; i++) {
                Object obj = objs[i];
                if (obj instanceof LJGroups.LJGroup)
                    mask.set(((LJGroups.LJGroup)obj).m_iBit);
                eventInfo.m_iSec_Mask = mask.getIntValue();
            }
        }
        eventInfo.m_bBackdate = jBackDateItem.getState();
        eventInfo.m_bNoEmail = jNoMailNotifyItem.getState();
        eventInfo.m_bNoComment = jNoCommentItem.getState();
        
        return eventInfo;
    }
    
    private void postOldEntry() {
        // Add your handling code here:
        OldEventInfo eventInfo = new OldEventInfo();
        try {
            eventInfo.m_szEvent = jEntryText.getText();
        }
        catch (java.lang.NullPointerException e) {
            // At the very least, we need some text in this component to post something to LJ
            return;
        }
        try {
            eventInfo.m_szSubject = jSubjectField.getText();
        }
        catch (java.lang.NullPointerException e) {}
        try {
            eventInfo.m_szMusic = jMusicField.getText();
        }
        catch (java.lang.NullPointerException e) {}
        java.lang.Object moodObj = jMoodList.getSelectedItem();
        if (moodObj instanceof MoodInfo)
            eventInfo.m_iMoodID = ((MoodInfo)moodObj).m_iMoodID;
        else if (moodObj instanceof String)
            eventInfo.m_szMood = ((String)moodObj);
        if (jPicList.getSelectedIndex() > 0) {
            java.lang.Object picObj = jPicList.getSelectedItem();
            if (picObj instanceof Integer)
                eventInfo.m_szPickKW = m_szPicKWText[((Integer)picObj).intValue()];
        }
        int iPrivIdx = jPrivacyList.getSelectedIndex();
        if (iPrivIdx == 2) {
            eventInfo.m_iSecurity = PostEventInfo.SEC_MASK;
            eventInfo.m_iSec_Mask = 1;
        }
        else if (iPrivIdx < 2) {
            eventInfo.m_iSecurity = iPrivIdx;
        }
        else {
            Object objs[] = m_PrivDlg.getSelectedValues();
            int iMax = objs.length;
            eventInfo.m_iSecurity = PostEventInfo.SEC_MASK;
            eventInfo.m_iSec_Mask = 0;
            intBitSet mask = new intBitSet();
            for (int i = 0; i < iMax; i++) {
                Object obj = objs[i];
                if (obj instanceof LJGroups.LJGroup)
                    mask.set(((LJGroups.LJGroup)obj).m_iBit);
                eventInfo.m_iSec_Mask = mask.getIntValue();
            }
        }
        eventInfo.m_bNoEmail = jNoMailNotifyItem.getState();
        eventInfo.m_bNoComment = jNoCommentItem.getState();
        Object obj = m_EntryDate.getValue();
        if (obj instanceof java.util.Date)
            eventInfo.m_Date = (java.util.Date)m_EntryDate.getValue();
        eventInfo.m_iItemID = m_iEntryID;
        
        XMLpostEvent event = m_Protocol.editEvent(eventInfo);
        if (!event.m_bSentOK) {
            java.awt.Container comp = this;
            while ((comp = comp.getParent()) != null) {
                if (comp instanceof EntryFrame) {
                    ((EntryFrame)comp).setStatus(InstallInfo.getString("string.error.post"));
                }
            }
        }
        else {   // Clear everything if the post went well!
            jClearBtnActionPerformed(new java.awt.event.ActionEvent(this,0x0,"Post"));
            java.awt.Container comp = this;
            while ((comp = comp.getParent()) != null) {
                if (comp instanceof EntryFrame) {
                    ((EntryFrame)comp).setStatus(InstallInfo.getString("string.ok.post"));
                    if (m_iMode == POST_MODE)
                        ((EntryFrame)comp).addNewPost();
                }
            }
        }
        
        java.awt.Container cont = getParent();
        while (cont != null) {
            if (cont instanceof HistPanel)
                break;
            cont = cont.getParent();
        }
        if (cont != null) {
            java.util.Calendar calen = java.util.Calendar.getInstance();
            calen.setTime(m_OldDate);
            ((HistPanel)cont).delPost(calen.get(calen.DAY_OF_MONTH),calen.get(calen.MONTH)-calen.JANUARY+1,calen.get(calen.YEAR));
        }
        if ((cont != null) && (eventInfo.m_szEvent.length() > 0) && (eventInfo.m_szSubject.length() > 0)) {
            java.util.Calendar calen = java.util.Calendar.getInstance();
            calen.setTime((java.util.Date)obj);
            ((HistPanel)cont).addPost(calen.get(calen.DAY_OF_MONTH),calen.get(calen.MONTH)-calen.JANUARY+1,calen.get(calen.YEAR),eventInfo);
        }
    }
    
    private void jPostBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPostBtnActionPerformed
        if (!EntryFrame.m_bOnline)
        {
            long lDate = java.util.Calendar.getInstance().getTime().getTime();
            PostEventInfo eventInfo = getEventInfo();
            if (jUploadTime.isSelected()) 
                eventInfo.m_Date = null;
            
            String szPath = System.getProperty("user.home");
            szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+m_Protocol.getUserName()+System.getProperty("file.separator")+"Outbox";
            File groupDir = new File(szPath);
            groupDir.mkdirs();
            File groupxml = new File(groupDir,System.getProperty("file.separator")+lDate+".xml");
            try
            {
                if (!groupxml.exists()) groupxml.createNewFile();
                java.beans.XMLEncoder encode = new java.beans.XMLEncoder(new java.io.FileOutputStream(groupxml));
                 encode.writeObject(eventInfo);
                encode.close();
            } catch (java.io.FileNotFoundException e) { System.err.println(e); }
              catch (java.io.IOException e) { System.err.println(e); }
            
            jClearBtnActionPerformed(new java.awt.event.ActionEvent(this,0x0,"Post"));
            java.awt.Container comp = this;
            while ((comp = comp.getParent()) != null) 
            {
                if (comp instanceof EntryFrame)
                    ((EntryFrame)comp).setStatus("Your entry will be uploaded when next you connect.");
            }
            
        }
        else if (m_iMode == POST_MODE)
            postNewEntry();
        else if (m_iMode == EDIT_MODE)
            postOldEntry();
    }//GEN-LAST:event_jPostBtnActionPerformed
    
    public void populateMoods(LJMoods moods) {
        jMoodList.removeAllItems();
        if (moods == null) {
            jMoodList.setEnabled(false);
            return;
        }
        jMoodList.setModel(new javax.swing.DefaultComboBoxModel(moods.getMoodList()));
        m_Moods = moods;
        
    }
    
    public void populatePubLJ(Object[] szPubLJ) {
        jJournalList.removeAllItems();
        if (szPubLJ == null) {
            jJournalList.setEnabled(false);
            jLabel6.setEnabled(false);
            return;
        }
        if (szPubLJ.length < 2)
        {
            jJournalList.setEnabled(false);
            jLabel6.setEnabled(false);
        }
         else {
            javax.swing.JComboBox jtemp = new javax.swing.JComboBox(szPubLJ);
            jJournalList.setModel(jtemp.getModel());
        }
    }
    
    public void populatePrivacy(LJGroups PrivList) {
        if ((m_PrivDlg != null) && (PrivList != null))
            m_PrivDlg.setModel(PrivList);
        
        m_PrivList = PrivList;
    }
    
    public void populatePicKW(Object[] szPickKW) {
        jPicList.removeAllItems();
        m_szPicKWText = null;
        if (szPickKW == null) {
            jLabel5.setEnabled(false);
            jPicList.setEnabled(false);
            return;
        }
        else {
            jLabel5.setEnabled(true);
            jPicList.setEnabled(true);
        }
        
        if (szPickKW.length < 1) {
            jLabel5.setEnabled(false);
            jPicList.setEnabled(false);
        }
        else {
            m_szPicKWText = new String[szPickKW.length];
            for (int i = 0; i < szPickKW.length; i++)
                m_szPicKWText[i] = (String)szPickKW[i];

            for (int i = 0; i < szPickKW.length; i++)
                jPicList.addItem(new Integer(i));
        }
    }
    
    public javax.swing.JMenu[] getMenu() {
        javax.swing.JMenu[] menus = new javax.swing.JMenu[2];
        menus[0] = jEditMenu;
        menus[1] = jViewMenu;
        return menus;
    }
    
    public void updateComponenetTreeUI() {
        javax.swing.SwingUtilities.updateComponentTreeUI(m_PrivDlg);
        javax.swing.SwingUtilities.updateComponentTreeUI(jEditMenu);
    }
    
    public void setOldInfo(OldEventInfo info) {
        if (m_iMode == POST_MODE) return;
        
        if (info.m_szEvent != null)
            jEntryText.setText(info.m_szEvent);
        else
            jEntryText.setText("");
        if (info.m_szSubject != null)
            jSubjectField.setText(info.m_szSubject);
        else
            jSubjectField.setText("");
        
        if (info.m_iSecurity < PostEventInfo.SEC_MASK)
            jPrivacyList.setSelectedIndex(info.m_iSecurity - PostEventInfo.SEC_PUBLIC);
        else if (info.m_iSec_Mask == 1)
            jPrivacyList.setSelectedIndex(2);
        else {
            jPrivacyList.setSelectedIndex(3);
            int iSize = m_PrivList.getSize();
            java.util.Vector posList = new java.util.Vector();
            for (int i = 0; i < iSize; i++) {
                LJGroups.LJGroup data = (LJGroups.LJGroup)m_PrivList.get(i);
                if (((int)(java.lang.Math.pow(2,data.m_iBit)) & info.m_iSec_Mask) > 0)
                    posList.add(new java.lang.Integer(i));
            }
            m_PrivDlg.setSelectedValues(posList);
        }
        m_OldDate = info.m_Date;
        m_EntryDate.setValue(m_OldDate);
        
        if (info.m_szMood != null)
            jMoodList.setSelectedItem(info.m_szMood);
        else if (info.m_iMoodID != -1)
            jMoodList.setSelectedItem(m_Moods.getMoodID(info.m_iMoodID));
        else
            jMoodList.setSelectedItem("");
        
        if (info.m_szMusic != null)
            jMusicField.setText(info.m_szMusic);
        else
            jMusicField.setText("");
        
        if (info.m_szPickKW != null)
        {
            int iSize = m_szPicKWText.length;
            for (int i = 0; i < iSize; i++)
            {
                if (m_szPicKWText[i].compareToIgnoreCase(info.m_szPickKW) == 0)
                {
                    jPicList.setSelectedIndex(i);
                    break;
                }
            }
        }
        else if (jPicList.getItemCount() > 0)
            jPicList.setSelectedIndex(0);
        
        jNoCommentItem.setState(info.m_bNoComment);
        jNoMailNotifyItem.setState(info.m_bNoEmail);
        m_iEntryID = info.m_iItemID;
    }
    
    public void addActionListener(java.awt.event.ActionListener listen) {
        jClearBtn.addActionListener(listen);
    }
    
    public void setFriends(java.util.Vector friends) {
        m_FriendList = friends;
    }
    
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        JLabel cell = new JLabel();
        
        cell.setOpaque(true);
        cell.setHorizontalAlignment(cell.CENTER);
        cell.setVerticalAlignment(cell.CENTER);
        
        //Get the selected index. (The index param isn't
        //always valid, so just use the value.)
        if (value == null) return cell;
        int selectedIndex = ((Integer)value).intValue();
        
        if (isSelected) {
            cell.setBackground(list.getSelectionBackground());
            cell.setForeground(list.getSelectionForeground());
        } else {
            cell.setBackground(list.getBackground());
            cell.setForeground(list.getForeground());
        }
        
        EntryFrame frame = (EntryFrame)javax.swing.SwingUtilities.getAncestorOfClass(EntryFrame.class,this);
        
        if (frame != null) {
            if ((frame.m_PicKWIcon != null) && (frame.m_PicKWIcon[selectedIndex] != null)) {
                cell.setIcon(frame.m_PicKWIcon[selectedIndex]);
                frame.m_PicKWIcon[selectedIndex].setImageObserver(cell);
            }
        }
        cell.setText(m_szPicKWText[selectedIndex]);
        cell.setFont(list.getFont());
        
        return cell;
    }
    
    public javax.swing.JMenuItem[] getFileMenuItems() {
        javax.swing.JMenuItem[] item = new javax.swing.JMenuItem[2];
        item[0] = jSaveItem;
        item[1] = jLoadItem;
        
        return item;
    }
    
    public javax.swing.Icon getTabIcon() {
        return new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/entry.gif"));
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    protected javax.swing.JCheckBoxMenuItem jBackDateItem;
    private javax.swing.JButton jBoldBtn;
    protected javax.swing.JButton jClearBtn;
    private javax.swing.JButton jColourBtn;
    protected javax.swing.JMenuItem jCommLnkItem;
    private javax.swing.JButton jCopyBtn;
    protected javax.swing.JMenuItem jCopyItem;
    private javax.swing.JButton jCustBtn;
    private javax.swing.JButton jCutBtn;
    protected javax.swing.JMenuItem jCutItem;
    protected javax.swing.JMenuItem jCutLnkItem;
    private javax.swing.JButton jDelBtn;
    protected javax.swing.JButton jDetectBtn;
    private javax.swing.JCheckBoxMenuItem jEditBarOn;
    protected javax.swing.JMenu jEditMenu;
    private javax.swing.JPanel jEditPane;
    private javax.swing.JToolBar jEditToolBar;
    protected javax.swing.JTextArea jEntryText;
    private javax.swing.JToolBar jFileToolBar;
    private javax.swing.JToolBar jFmtToolBar;
    private javax.swing.JButton jImgSrcBtn;
    private javax.swing.JButton jItalBtn;
    protected javax.swing.JComboBox jJournalList;
    private javax.swing.JCheckBoxMenuItem jLJBarOn;
    private javax.swing.JButton jLJCommBtn;
    private javax.swing.JToolBar jLJToolBar;
    private javax.swing.JButton jLJUsrBtn;
    protected javax.swing.JLabel jLabel1;
    protected javax.swing.JLabel jLabel2;
    protected javax.swing.JLabel jLabel3;
    protected javax.swing.JLabel jLabel4;
    protected javax.swing.JLabel jLabel5;
    protected javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JButton jLnkBtn;
    private javax.swing.JMenuItem jLoadItem;
    protected javax.swing.JMenu jMenu1;
    protected javax.swing.JMenu jMenu2;
    private javax.swing.JCheckBoxMenuItem jMiscBarOn;
    private javax.swing.JToolBar jMiscToolBar;
    protected javax.swing.JComboBox jMoodList;
    protected javax.swing.JTextField jMusicField;
    protected javax.swing.JCheckBoxMenuItem jNoCommentItem;
    protected javax.swing.JCheckBoxMenuItem jNoMailNotifyItem;
    private javax.swing.JButton jOpenBtn;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton jPasteBtn;
    protected javax.swing.JMenuItem jPasteItem;
    protected javax.swing.JComboBox jPicList;
    protected javax.swing.JButton jPostBtn;
    private javax.swing.JTextPane jPreviewPane;
    protected javax.swing.JComboBox jPrivacyList;
    private javax.swing.JButton jSaveBtn;
    private javax.swing.JMenuItem jSaveItem;
    protected javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    protected javax.swing.JSeparator jSeparator1;
    private javax.swing.JButton jSpellBtn;
    protected javax.swing.JTextField jSubjectField;
    private javax.swing.JTabbedPane jTabbedPane;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JButton jUnderBth;
    private javax.swing.JCheckBox jUploadTime;
    protected javax.swing.JMenuItem jUsrLnkItem;
    private javax.swing.JMenu jViewMenu;
    private javax.swing.JCheckBoxMenuItem jWebBarOn;
    private javax.swing.JFormattedTextField m_EntryDate;
    // End of variables declaration//GEN-END:variables
    
}
