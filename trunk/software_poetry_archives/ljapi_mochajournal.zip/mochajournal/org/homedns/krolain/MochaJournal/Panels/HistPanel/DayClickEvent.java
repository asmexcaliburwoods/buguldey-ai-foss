/*
 * DayClickEvent.java
 *
 * Created on July 20, 2002, 8:08 PM
 */

package org.homedns.krolain.MochaJournal.Panels.HistPanel;

/**
 *
 * @author  krolain
 */
class DayClickEvent extends java.awt.AWTEvent {
    
    int m_iDay = -1;
    int m_iEntryIndex = -1;
    boolean m_bDouble = false;
    /** Creates a new instance of DayClickEvent */
    public DayClickEvent(Object source, int iDay, int iEntryIndex, boolean bDoubleClick) 
    {
        super(source,0x0821);
        m_iDay = iDay;
        m_iEntryIndex = iEntryIndex;
        m_bDouble = bDoubleClick;
    }
    
    public boolean isDoubleClick()
    {
        return m_bDouble;
    }
    
    public int getDay()
    {
        return m_iDay;
    }
    
    public int getEntryIndex()
    {
        return m_iEntryIndex;
    }
}
