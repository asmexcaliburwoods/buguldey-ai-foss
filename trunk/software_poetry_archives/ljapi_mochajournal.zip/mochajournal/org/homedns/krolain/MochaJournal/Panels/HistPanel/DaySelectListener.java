/*
 * DaySelectListener.java
 *
 * Created on July 20, 2002, 8:02 PM
 */

package org.homedns.krolain.MochaJournal.Panels.HistPanel;

/**
 *
 * @author  krolain
 */
interface DaySelectListener extends java.util.EventListener {
    public void dayClicked(DayClickEvent evt);
    public void entryClicked(DayClickEvent evt);
}
