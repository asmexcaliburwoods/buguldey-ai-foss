/*
 * HistPanel.java
 *
 * Created on July 20, 2002, 2:27 PM
 */

package org.homedns.krolain.MochaJournal.Panels.HistPanel;

import org.homedns.krolain.MochaJournal.Protocol.*;
import org.homedns.krolain.MochaJournal.LJData.*;
import org.homedns.krolain.MochaJournal.Panels.LJPanel;
import org.homedns.krolain.MochaJournal.Panels.EntryPanel;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.KeyEvent;
import org.homedns.krolain.util.InstallInfo;
import java.util.Vector;

/**
 *
 * @author  krolain
 */
public class HistPanel extends javax.swing.JComponent implements DaySelectListener, LJPanel {
    
    class HistLayout extends java.awt.CardLayout
    {
        java.awt.Container m_Container = null;
        public HistLayout(java.awt.Container cont)
        {
            m_Container = cont;
        }
        
        public void show(String name)
        {
            show(m_Container, name);
        }
    }
    
    /** Creates a new instance of HistPanel */
    JLJCalendar m_Calendar = null;
    java.util.Calendar m_DateSelect = java.util.Calendar.getInstance();
    XMLProtocol m_Prot;
    LJPostList m_PostList = null;
    public EntryPanel m_Edit = null;
    LJgetdaycount m_HistInfo = null;
    JPanel m_RefreshPanel = null;
    OldEventInfo m_SelInfo = null;
    HistLayout m_Layout = null;
    Vector m_DayList = null;
    
    boolean m_bDataFetched = false;
    
    private static final String CALEN_CARD = "Calendar";
    private static final String PSTLST_CARD ="PostList";
    private static final String EDIT_CARD = "Edit";
    
    protected void finalize() throws java.lang.Throwable
    {
        m_Calendar = null;
        m_DateSelect = null;
        m_Prot = null;
        m_PostList = null;
        m_Edit = null;
        m_HistInfo = null;
        m_RefreshPanel = null;
        super.finalize();
    }
    
    public HistPanel(XMLProtocol prot,java.awt.Frame parent) {
        m_Prot=prot;

        m_Calendar = new JLJCalendar();

        m_RefreshPanel = new JPanel();
        JButton button = new JButton();
        button.setText(InstallInfo.getString("button.update"));
        button.addActionListener( new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                fetchCounts();
            }
        });
        button.setMnemonic(KeyEvent.VK_U);
        m_RefreshPanel.add(button);
        
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });        
        setLayout(m_Layout = new HistLayout(this));
        
        JPanel panel = new JPanel();
        m_Calendar.addDaySelectListener(this);
        panel.setLayout(new java.awt.BorderLayout());
        panel.add("Center",m_Calendar);
        panel.add("South",m_RefreshPanel);
       
        add(CALEN_CARD,panel);
        
        m_PostList = new LJPostList();
        m_PostList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                m_Layout.show(CALEN_CARD);
                repaint(0,0,0,getSize().width,getSize().height);
            }
        });
        add(PSTLST_CARD,m_PostList);
        
        m_Edit = new EntryPanel(m_Prot,parent,EntryPanel.EDIT_MODE);
        m_Edit.addActionListener( new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                m_Layout.show(PSTLST_CARD);
                repaint(0,0,0,getSize().width,getSize().height);
            }
        });
        add(EDIT_CARD,m_Edit);
        m_PostList.addDaySelectListener(this);
        m_HistInfo = new LJgetdaycount();
        m_Calendar.setHistory(m_HistInfo);
        m_DayList = new Vector();
    }    

    private void fetchCounts()
    {
        XMLgetdaycounts daycounts = m_Prot.getDayCounts(null);
        if (daycounts.m_bSentOK)
        {
            m_bDataFetched = true;            
            XMLgetdaycounts.XMLdaycount[] days = new XMLgetdaycounts.XMLdaycount[daycounts.m_daycounts.size()];
            daycounts.m_daycounts.toArray(days);
            m_HistInfo.setList(days);
            m_Calendar.calenChanged();
        }
    }
    
    private void formComponentShown(java.awt.event.ComponentEvent evt) {
        if (!m_bDataFetched && (evt.getID() == evt.COMPONENT_SHOWN) && (evt.getSource() == this))
        {
            if (this.getParent() != null)
                fetchCounts();
        }
    }
    
    public void addPost(int iDay, int iMonth, int iYear,OldEventInfo info)
    {
        if ((iDay == m_DateSelect.get(m_DateSelect.DAY_OF_MONTH)) && 
            (iMonth == m_DateSelect.get(m_DateSelect.MONTH) - m_DateSelect.JANUARY + 1) &&
            (iYear == m_DateSelect.get(m_DateSelect.YEAR)))
        {
            m_DayList.add(info);
            m_PostList.loadData(m_DayList.toArray());
        }
        m_HistInfo.incDay(iDay,iMonth,iYear);
        m_Calendar.calenChanged();
        
    }

    public void delPost(int iDay, int iMonth, int iYear)
    {
        m_HistInfo.decDay(iDay,iMonth,iYear);
        m_Calendar.calenChanged();
        if (m_SelInfo != null)
        {
            int iSize = m_DayList.size();
            for (int i = 0; i < iSize; i++)
            {
                OldEventInfo info = (OldEventInfo)m_DayList.get(i);
                if (info.m_iItemID == m_SelInfo.m_iItemID)
                {
                    m_DayList.remove(i);
                    break;
                }
            }
            m_PostList.loadData(m_DayList.toArray());
            m_SelInfo = null;
        }
    }
    
    public void addNewPost()
    {
        java.util.Calendar calen = java.util.Calendar.getInstance();
        m_HistInfo.incDay(calen.get(calen.DAY_OF_MONTH),calen.get(calen.MONTH)-calen.JANUARY+1,calen.get(calen.YEAR));
        m_Calendar.calenChanged();
    }
    
    public void dayClicked(DayClickEvent evt)
    {
        if (evt.isDoubleClick())
        {
            m_DateSelect.set(java.util.Calendar.DAY_OF_MONTH,evt.getDay());
            m_DateSelect.set(java.util.Calendar.MONTH,m_Calendar.getMonth());
            m_DateSelect.set(java.util.Calendar.YEAR,m_Calendar.getYear());
            XMLgetEvents events = m_Prot.getDayPosts(evt.getDay(),m_Calendar.getMonth()+1,m_Calendar.getYear(),null);
            if (events.m_bSentOK)
            {
                m_PostList.setDate(m_DateSelect);
                m_DayList.removeAllElements();
                m_DayList.addAll(java.util.Arrays.asList(events.getList()));
                m_PostList.loadData(m_DayList.toArray());
                m_Layout.show(PSTLST_CARD);
                repaint(0,0,0,getSize().width,getSize().height);
            }
        }
    }

    public void entryClicked(DayClickEvent evt) {
        Object data = m_DayList.get(evt.getEntryIndex());
        if (data instanceof OldEventInfo)
        {
            m_SelInfo = (OldEventInfo)data;
            m_Edit.setOldInfo(m_SelInfo);
            m_Layout.show(EDIT_CARD);
            repaint(0,0,0,getSize().width,getSize().height);
        }
    }
    
    public javax.swing.JMenu[] getMenu() {
        return m_Edit.getMenu();
    }

   public javax.swing.JMenuItem[] getFileMenuItems()
   {
       return null;
   }
    
    public void updateComponenetTreeUI() {
        
        m_Edit.updateComponenetTreeUI();
        javax.swing.SwingUtilities.updateComponentTreeUI(this);
        javax.swing.SwingUtilities.updateComponentTreeUI(m_Calendar);
        javax.swing.SwingUtilities.updateComponentTreeUI(m_Edit);
        javax.swing.SwingUtilities.updateComponentTreeUI(m_PostList);
    }
    
    public javax.swing.Icon getTabIcon() {
        return new javax.swing.ImageIcon(getClass().getResource("/org/homedns/krolain/MochaJournal/Images/history.gif"));
    }
    
}
