/*
 * JLJCalendar.java
 *
 * Created on June 20, 2002, 12:07 AM
 */

package org.homedns.krolain.MochaJournal.Panels.HistPanel;

import org.homedns.krolain.swing.JCalendar;
import java.util.Calendar;
import java.util.ArrayList;
import org.homedns.krolain.MochaJournal.LJData.*;
import org.homedns.krolain.MochaJournal.JLJSettings;
/**
 *
 * @author  krolain
 */
class JLJCalendar extends JCalendar {
    
    /** Creates a new instance of JLJCalendar */
    LJgetdaycount m_evtHistInfo = null;
    DaySelectListener m_Listen = null;
    
    public JLJCalendar()
    {
        super(JLJSettings.GetSettings().m_ProgLocale);
        setHighlight(false);
    }
    
    public JLJCalendar(LJgetdaycount info) {
        super(JLJSettings.GetSettings().m_ProgLocale);
        m_evtHistInfo = info;
        setHighlight(false);
        calenChanged();
    }
    
    public void calenChanged()
    {
        if (m_evtHistInfo == null) return;
        ArrayList dayList = new ArrayList();
        ArrayList stringList = new ArrayList();
        int iYear = getYear();
        int iMonth = getMonth();
        Calendar calen = Calendar.getInstance();
        calen.set(Calendar.YEAR,iYear);
        calen.set(Calendar.MONTH,iMonth);
        int iMaxDay = calen.getMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= iMaxDay; i++)
        {
            String szString = m_evtHistInfo.getDateString(i,iMonth+1,iYear);
            if (szString != null)
            {
                dayList.add(new java.lang.Integer(i));
                stringList.add(szString);
            }
        }
        if (dayList.size() > 0)
            setText(dayList.toArray(),stringList.toArray());
    }
    
    public void dayClicked(int iDay, int iButton, boolean bDouble)
    {
        if (m_Listen != null)
        {
            DayClickEvent evt = new DayClickEvent(this,iDay,-1,bDouble);
            m_Listen.dayClicked(evt);
        }
    }
    
    public void addDaySelectListener(DaySelectListener listen)
    {
        m_Listen = listen;
    }
    
    public void setHistory(LJgetdaycount info)
    {
        m_evtHistInfo = info;
        calenChanged();
    }
}
