/*
 * LJPanel.java
 *
 * Created on July 17, 2002, 9:12 PM
 */

package org.homedns.krolain.MochaJournal.Panels;

/**
 *
 * @author  krolain
 */
public interface LJPanel {
   public javax.swing.JMenuItem[] getFileMenuItems();
   public javax.swing.JMenu[] getMenu();
   public void updateComponenetTreeUI();
   public javax.swing.Icon getTabIcon();
}
