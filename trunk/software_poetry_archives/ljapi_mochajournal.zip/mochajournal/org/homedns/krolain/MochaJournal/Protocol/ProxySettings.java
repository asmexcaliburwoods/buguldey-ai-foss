/*
 * ProxySettings.java
 *
 * Created on August 9, 2002, 11:31 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;

/**
 *
 * @author  krolain
 */
public class ProxySettings extends java.lang.Object implements java.io.Serializable {
    
    public String m_szProxyAddress = "";
    
    public int m_iPort = 80;
    
    public boolean m_bEnabled = false;
    
    /** Creates a new instance of ProxySettings */
    public ProxySettings() {
    }
 
    public String getAddr() { return m_szProxyAddress; }
    public int getPort() { return m_iPort; }
    public boolean getEnabled() { return m_bEnabled; }
    
    public void setAddr(String var) { m_szProxyAddress = var; }
    public void setPort(int var) { m_iPort = var; }
    public void setEnabled(boolean var) { m_bEnabled = var; }
}
