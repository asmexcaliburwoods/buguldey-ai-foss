/*
 * XMLcheckfriends.java
 *
 * Created on May 23, 2004, 10:16 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
/**
 *
 * @author  Krolain
 */
public class XMLcheckfriends extends XMLRPCObject {
    
    public static class Request extends XMLRPCLJ
    {
        private static final String[] m_ObjMem = {"lastupdate","mask"};
        public Object m_lastupdate = null;
        public Integer m_mask = null;
        
        public Request()
        {
            super(m_ObjMem);
        }
    }
    
    public Integer m_new = null;
    public Integer m_interval = null;
    public Integer m_count = null;
    public Integer m_total = null;
    public Object m_lastupdate = null;
    
    /** Creates a new instance of XMLcheckfriends */
    public XMLcheckfriends() {
        super(null);
    }
    
}
