/*
 * XMLcommentHandler.java
 *
 * Created on May 26, 2004, 12:34 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.MochaJournal.LJData.LJuserMap;
/**
 *
 * @author  jsmith
 */
public class XMLcommentHandler extends org.xml.sax.helpers.DefaultHandler {
    XMLcomments m_Comments = null;
    XMLcomments.comment comment = null;
    String m_szChars = "";
    
    /** Creates a new instance of XMLcommentHandler */
    public XMLcommentHandler(XMLcomments comment) {
        m_Comments = comment;
    }
    
    public void startElement(String uri, String localName, String qName, org.xml.sax.Attributes attributes) {
        m_szChars = "";
        if (qName.compareToIgnoreCase("comment") == 0)
        {
            comment = new XMLcomments.comment();
            int iSize = attributes.getLength();
            for (int i = 0; i < iSize; i++)
            {
                String name = attributes.getQName(i);
                String val = attributes.getValue(name);
                if (name.compareToIgnoreCase("id") == 0)
                    comment.m_iID = Integer.parseInt(val);
                else if (name.compareToIgnoreCase("posterid") == 0)
                    comment.m_iPoster = Integer.parseInt(val);
                else if (name.compareToIgnoreCase("state") == 0)
                    comment.m_szState = val;
                else if (name.compareToIgnoreCase("jitemid") == 0)
                    comment.m_iJournalID = Integer.parseInt(val);
                else if (name.compareToIgnoreCase("parentid") == 0)
                    comment.m_iParentID = Integer.parseInt(val);
            }
            m_Comments.m_Comment.add(comment);
            if (m_Comments.m_iMaxMetaIDSent < comment.m_iID)
                m_Comments.m_iMaxMetaIDSent = comment.m_iID;
        } 
        else if (qName.compareToIgnoreCase("usermap") == 0)
        {
            LJuserMap user = new LJuserMap();
            int iSize = attributes.getLength();
            for (int i = 0; i < iSize; i++)
            {
                String name = attributes.getQName(i);
                String val = attributes.getValue(name);
                if (name.compareToIgnoreCase("id") == 0)
                    user.m_iID = Integer.parseInt(val);
                else if (name.compareToIgnoreCase("user") == 0)
                    user.m_szUserName = val;
            }
            m_Comments.m_userMap.add(user);
        }
    }
    
    public void endElement(String uri, String localName, String qName) {
        m_szChars.trim();
        if (qName.compareToIgnoreCase("maxid") == 0)
        {
            m_Comments.m_iMaxMetaID = Integer.parseInt(m_szChars);
        }
        else if (qName.compareToIgnoreCase("body") == 0)
            comment.m_szBody = m_szChars;
        else if (qName.compareToIgnoreCase("subject") == 0)
            comment.m_szSubject = m_szChars;
        else if (qName.compareToIgnoreCase("date") == 0)
        {
            String szFormat;
            String szDate;
            int iZIdx = m_szChars.indexOf('Z');
            if (iZIdx > -1)
            {
                szFormat = "yyyy-MM-dd'T'HH:mm:ss";
                szDate = m_szChars.substring(0,iZIdx);
            }
            else
            {
                szFormat = "YYYY-MM-ddTHH:mm:ssZ";
                szDate = m_szChars;
            }
            java.text.SimpleDateFormat df= new java.text.SimpleDateFormat(szFormat);
            try
            {
                comment.m_Date = df.parse(szDate);
            } catch (java.text.ParseException e)
            {
                System.err.println(e);
                comment.m_Date = java.util.Calendar.getInstance().getTime();
            }
        }
    }
    
    public void characters(char[] ch, int start, int length) {
        m_szChars += new String(ch,start,length);
    }
    
}
