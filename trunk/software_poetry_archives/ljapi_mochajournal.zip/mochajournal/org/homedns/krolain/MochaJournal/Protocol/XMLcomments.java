/*
 * XMLcomments.java
 *
 * Created on May 25, 2004, 10:13 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import java.util.*;
/**
 *
 * @author  Krolain
 */
public class XMLcomments {

    public static class comment
    {
        public int m_iID;
        public int m_iParentID;
        public int m_iJournalID;
        public String m_szState;
        public int m_iPoster;
        public String m_szSubject;
        public String m_szBody;
        public Date m_Date;
        
        public comment()
        {
            m_iID = -1;
            m_iParentID = -1;
            m_iJournalID = -1;
            m_iPoster = -1;
        }
    }
    
    public int m_iMaxMetaID;
    public Vector m_userMap;
    public Vector m_Comment;
    public int m_iMaxMetaIDSent;

    /** Creates a new instance of XMLcomments */
    public XMLcomments() {
        m_iMaxMetaIDSent = 0;
        m_iMaxMetaID = 0;
        m_userMap = new Vector();
        m_Comment = new Vector();
    }
    
}
