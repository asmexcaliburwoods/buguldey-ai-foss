/*
 * XMLeditfriendgroups.java
 *
 * Created on May 17, 2004, 3:21 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.XMLRPCObject;
import java.util.*;
/**
 *
 * @author  jsmith
 */
public class XMLeditfriendgroups extends XMLRPCObject {
    
    public static class Request extends XMLRPCLJ
    {
        public static class XMLSet extends XMLRPCObject
        {
            private static final String[] m_Members = {"name","sort","public"};
            public String m_name = null;
            public Integer m_sort = null;
            public Integer m_public = null;
                
            public XMLSet()
            {
                super(m_Members);
            }
        }
        
        private final static String[] m_Members = {"groupmasks","set","delete"};
        public Hashtable m_groupmasks = null;
        public Hashtable m_set = null;
        public Vector m_delete = null;
        
        public Request()
        {
            super(m_Members);
        }
    }
    
    /** Creates a new instance of XMLeditfriendgroups */
    public XMLeditfriendgroups() {
        super(null);
    }
    
}
