/*
 * XMLeditfriends.java
 *
 * Created on May 14, 2004, 12:17 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;

import org.homedns.krolain.XMLRPC.*;
import java.util.Vector;

/**
 *
 * @author  jsmith
 */
public class XMLeditfriends extends XMLRPCObject {
    
    public static class Request extends XMLRPCLJ
    {
        public static class ReqAdd extends XMLRPCObject
        {
            private static String[] m_Members = {"username","fgcolor","bgcolor","groupmask"};
            
            public String m_username = null;
            public String m_fgcolor = null;
            public String m_bgcolor = null;
            public Integer m_groupmask = null;
            
            public ReqAdd()
            {
                super(m_Members);
            }
        }
        
        private static String[] m_Members = {"delete","add"};
        public Vector m_delete = null;
        public Vector m_add = null;
        
        public Request()
        {
            super (m_Members);
        }
    }
    
    public class XMLAdded extends XMLRPCObject
    {
        public String m_username;
        public Object m_fullname;
        
        public XMLAdded()
        {
            super(null);
        }
    }
    
    public Vector m_added = null;
    
    /** Creates a new instance of XMLeditfriends */
    public XMLeditfriends() {
        super(null);
    }
    
    public Object newStruct(String szMemberName) {
        if (szMemberName.compareTo("added") == 0)
            return new XMLAdded();
        return null;
    }
    
}
