/*
 * XMLfriendgroup.java
 *
 * Created on May 13, 2004, 10:18 AM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
/**
 *
 * @author  jsmith
 */
public class XMLfriendgroup extends XMLRPCObject
{
    public Integer m_id = null;
    public Object m_name = null;
    public Integer m_sortorder = null;
    public Object m_public = null;
        
    public XMLfriendgroup()
    {
        super(null);
    }
}
