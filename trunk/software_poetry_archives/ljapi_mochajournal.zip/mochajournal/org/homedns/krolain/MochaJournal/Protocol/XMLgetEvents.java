/*
 * XMLgetEvents.java
 *
 * Created on May 19, 2004, 7:00 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
import java.util.*;
import org.homedns.krolain.MochaJournal.LJData.*;
/**
 *
 * @author  Krolain
 */
public class XMLgetEvents extends XMLRPCObject {
    
    public static class Request extends XMLRPCLJ
    {
        private static final String[] m_ObjMem = {"truncate","prefersubject","noprops","selecttype",
                                "lastsync","year","month","day","howmany","beforedate","itemid",
                                "lineendings","usejournal"};

        public Integer m_truncate = null;
        public Integer m_prefersubject = null;
        public Integer m_noprops = null;
        public String m_selecttype = null;
        public String m_lastsync = null;
        public Integer m_year = null;
        public Integer m_month = null;
        public Integer m_day = null;
        public Integer m_howmany = null;
        public String m_beforedate = null;
        public Integer m_itemid = null;
        public String m_lineendings = null;
        public String m_usejournal = null;
        
        public Request()
        {
            super(m_ObjMem);
        }
    }
    
    public class XMLevent extends XMLRPCObject
    {
        public Integer m_itemid = null;
        public Integer m_anum = null;
        public String m_eventtime = null;
        public String m_security = "public";
        public Integer m_allowmask = null;
        public Object m_subject = null;
        public Object m_event = null;
        public String m_poster = null;
        public Hashtable m_props = null;
        
        public XMLevent()
        {
            super(null);
        }
        
        public Object newStruct(String szMemberName)
        {
            if (szMemberName.compareTo("props") == 0)
                return new Hashtable();
            else
                return null;
        }
    }
    
    public Vector m_events = null;
    /** Creates a new instance of XMLgetEvents */
    public XMLgetEvents() {
        super(null);
    }
    
    public Object newStruct(String szMemberName)
    {
        if (szMemberName.compareTo("events") == 0)
            return new XMLevent();
        else
            return null;
    }
    
    public OldEventInfo[] getList()
    {
        int iSize = m_events.size();
        
        OldEventInfo[] events = new OldEventInfo[iSize];
        
        for (int i = 0; i < iSize; i++)
            events[i] = new OldEventInfo((XMLevent)m_events.get(i));
        
        return events;
    }
}
