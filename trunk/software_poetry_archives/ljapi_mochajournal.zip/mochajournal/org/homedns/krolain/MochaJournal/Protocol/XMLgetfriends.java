/*
 * XMLgetfriends.java
 *
 * Created on May 11, 2004, 12:47 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
import java.util.Vector;
import org.homedns.krolain.MochaJournal.LJData.LJFriends;

/**
 *
 * @author  jsmith
 */
public class XMLgetfriends extends XMLRPCObject {
    
    public static class Request extends XMLRPCLJ
    {
        private static String[] m_friendMembers = {"includefriendof","includegroups","friendlimit","includebdays"};

        public Integer m_includefriendof = null;
        public Integer m_includegroups = null;
        public Integer m_friendlimit = null;
        public Integer m_includebdays = null;

        public Request()
        {
            super(m_friendMembers);
        }
    }
    
    public class XMLfriend extends XMLRPCObject
    {
        public String m_username = null;
        public Object m_fullname = null;
        public String m_type = null;
        public String m_fgcolor = null;
        public String m_bgcolor = null;
        public Integer m_groupmask = null;
        public String m_status = null;
        public Object m_birthday = null;
        
        public XMLfriend()
        {
            super(null);
        }
    }
    
    public Vector m_friendgroups = null;
    public Vector m_friendofs = null;
    public Vector m_friends = null;
    
    /** Creates a new instance of XMLgetfriends */
    public XMLgetfriends() {
        super(null);
    }
    
    public Object newStruct(String szMemberName) {
        if (szMemberName.compareTo("friendgroups") == 0)
            return new XMLfriendgroup();
        else
            return new XMLfriend();
    }
    
    public LJFriends getFriends()
    {
        int iSize;
        LJFriends friendlist = new LJFriends();
        if (m_friends != null)
        {
            iSize = m_friends.size();
            for (int i = 0; i < iSize; i++)
                friendlist.addFriend((XMLfriend)m_friends.get(i));
        }
        if (m_friendofs != null)
        {
            iSize = m_friendofs.size();
            for (int i = 0; i < iSize; i++)
                friendlist.addFriendOf((XMLfriend)m_friendofs.get(i));
        }
        return friendlist;
    }
}
