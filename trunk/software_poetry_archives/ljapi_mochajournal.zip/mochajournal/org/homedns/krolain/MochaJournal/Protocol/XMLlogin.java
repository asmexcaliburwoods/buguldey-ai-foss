/*
 * XMLlogin.java
 *
 * Created on May 10, 2004, 12:49 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;

import org.homedns.krolain.XMLRPC.*;
import java.util.Vector;
import org.homedns.krolain.MochaJournal.LJData.LJGroups.*;
import org.homedns.krolain.MochaJournal.LJData.LJGroups;
import org.homedns.krolain.MochaJournal.LJData.LJMenus;

/**
 *
 * @author  jsmith
 */
public class XMLlogin extends XMLRPCObject {
    
    /** Creates a new instance of XMLlogin */
    public String m_fullname = null;
    public String m_message = null;
    public Vector m_friendgroups = null;
    public Vector m_usejournals = null;
    public Vector m_moods = null;
    public Vector m_pickws = null;
    public Vector m_pickwurls = null;
    public String m_defaultpicurl = null;
    public Object m_fastserver = null;
    public int m_userid = -1;
    public Vector m_menus = null;
    
    public static class loginRequest extends XMLRPCLJ
    {
        private static String[] m_logMembers = {"clientversion","getmoods","getmenus","getpickws","getpickwurls"};
        public String m_clientversion = null;
        public Integer m_getmoods = null;
        public Integer m_getmenus = null;
        public Integer m_getpickws = null;
        public Integer m_getpickwurls = null;
        
        public loginRequest()
        {
            super(m_logMembers);
        }
    }
    
    public class XMLmenu extends XMLRPCObject
    {
        public String m_text = null;
        public String m_url = null;
        public Vector m_sub = null;
        
        public XMLmenu()
        {
            super(null);
        }

        public Object newStruct(String szMemberName) {
            if (szMemberName.compareTo("sub") == 0)
                return new XMLmenu();
            else
                return null;
        }
        
        public LJMenus toMenu()
        {
            LJMenus menu = new LJMenus(m_text);
            if (m_url != null)
                menu.setUrl(m_url);
            if (m_sub != null)
            {
                int iSize = m_sub.size();
                LJMenus[] submenu = new LJMenus[iSize];
                for (int i = 0; i < iSize; i++)
                    submenu[i] = ((XMLmenu)m_sub.get(i)).toMenu();
                menu.setSubmenu(submenu);
            }
            return menu;
        }
    }
    
    public class XMLmood extends XMLRPCObject
    {
        public Integer m_id = null;
        public String m_name = null;
        public Integer m_parent = null;
        
        public XMLmood()
        {
            super(null);
        }
        
    }
    
    public XMLlogin()
    {
        super(null);
    }
    
    public Object newStruct(String szMemberName) {
        if (szMemberName.compareTo("menus") == 0)
            return new XMLmenu();
        else if (szMemberName.compareTo("moods") == 0)
            return new XMLmood();
        else if (szMemberName.compareTo("friendgroups") == 0)
            return new XMLfriendgroup();
        else
            return null;
    }
    
    public LJGroups getGroups()
    {
        LJGroups groups = new LJGroups();
        if (m_friendgroups != null)
        {
            int iSize = m_friendgroups.size();
            for (int i = 0; i < iSize; i++)
                groups.addGroup((XMLfriendgroup)m_friendgroups.get(i));
        }
        return groups;
    }
    
    public LJMenus getMenu()
    {
        if (m_menus == null) return null;
        LJMenus menu = new LJMenus("Web");
        int iSize = m_menus.size();
        
        LJMenus[] submenu = new LJMenus[iSize];
        for (int i = 0; i < iSize; i++)
            submenu[i] = ((XMLmenu)m_menus.get(i)).toMenu();
        menu.setSubmenu(submenu);
        
        return menu;
    }
}
