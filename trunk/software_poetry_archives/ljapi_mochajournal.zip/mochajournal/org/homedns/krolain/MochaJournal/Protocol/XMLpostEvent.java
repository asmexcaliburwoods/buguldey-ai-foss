/*
 * XMLpostEvent.java
 *
 * Created on May 17, 2004, 11:05 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
import java.util.*;
/**
 *
 * @author  Krolain
 */
public class XMLpostEvent extends XMLRPCObject {
    
    public static class Request extends XMLRPCLJ
    {
        private static final String[] m_ObjMembers = {"event","lineendings","subject","security","allowmask","year","mon","day",
                                          "hour","min","props","usejournal"};
        public String m_event = null;
        public String m_lineendings = null;
        public String m_subject = null;
        public String m_security = null;
        public Integer m_allowmask = null;
        public Integer m_year = null;
        public Integer m_mon = null;
        public Integer m_day = null;
        public Integer m_hour = null;
        public Integer m_min = null;
        public Hashtable m_props = null;
        public String m_usejournal = null;
        
        public Request(String[] members)
        {
            super(m_ObjMembers);
            if (members != null)
                m_Members.addAll(java.util.Arrays.asList(members));
            
        }
    }
    
    public static class editRequest extends Request
    {
        private static final String[] m_ObjMembers = {"itemid"};

        public Integer m_itemid = null;
        
        public editRequest()
        {
            super(m_ObjMembers);
        }
    }
    
    public Integer m_anum = null;
    public Integer m_itemid = null;
    
    /** Creates a new instance of XMLpostEvent */
    public XMLpostEvent() {
        super(null);
    }
    
}
