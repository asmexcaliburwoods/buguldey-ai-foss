/*
 * XMLsessionexp.java
 *
 * Created on May 25, 2004, 11:30 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
/**
 *
 * @author  Krolain
 */
public class XMLsessionexp extends XMLRPCObject {
    public static class Request extends XMLRPCLJ
    {
        private static final String[] m_ObjMem = {"expireall","expire"};
        public Integer m_expireall = null;
        public java.util.Vector m_expire = null;
        
        public Request()
        {
            super(m_ObjMem);
        }
    }
    
    /** Creates a new instance of XMLsessionexp */
    public XMLsessionexp() {
        super(null);
    }
}
