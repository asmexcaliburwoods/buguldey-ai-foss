/*
 * XMLsessiongen.java
 *
 * Created on May 25, 2004, 11:24 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
/**
 *
 * @author  Krolain
 */
public class XMLsessiongen extends XMLRPCObject {
    public static class Request extends XMLRPCLJ
    {
        private static final String[] m_ObjMem = {"expiration","ipfixed"};
        public String m_expiration = null;
        public Integer m_ipfixed = null;
        
        public Request()
        {
            super(m_ObjMem);
        }
    }
    
    public String m_ljsession = null;
    
    /** Creates a new instance of XMLsessiongen */
    public XMLsessiongen() {
        super(null);
    }
    
}
