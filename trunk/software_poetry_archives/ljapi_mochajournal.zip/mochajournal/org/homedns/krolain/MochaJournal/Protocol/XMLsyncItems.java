/*
 * XMLsyncItems.java
 *
 * Created on May 21, 2004, 2:42 PM
 */

package org.homedns.krolain.MochaJournal.Protocol;
import org.homedns.krolain.XMLRPC.*;
import java.util.*;

/**
 *
 * @author  jsmith
 */
public class XMLsyncItems extends XMLRPCObject {
    
    public static class Request extends XMLRPCLJ
    {
        private static final String[] m_ObjMem = {"lastsync"};
        public String m_lastsync = null;
        
        public Request()
        {
            super(m_ObjMem);
        }
        
    }
    
    public class XMLsyncitem extends XMLRPCObject
    {
        public String m_item = null;
        public String m_action = null;
        public String m_time = null;
        
        public XMLsyncitem()
        {
            super(null);
        }
    }
    
    public Vector m_syncitems = null;
    public Integer m_count = null;
    public Integer m_total = null;
    
    /** Creates a new instance of XMLsyncItems */
    public XMLsyncItems() {
        super(null);
    }
    
    public Object newStruct(String szMemberName)
    {
        if (szMemberName.compareTo("syncitems") == 0)
            return new XMLsyncitem();
        else
            return null;
    }
    
}
