/*
 * XMLRPCHandler.java
 *
 * Created on May 8, 2004, 1:22 PM
 */

package org.homedns.krolain.XMLRPC;
import org.xml.sax.*;
import java.lang.reflect.*;
import java.util.*;
import java.nio.ByteBuffer;
import sun.misc.BASE64Decoder;

/**
 * An XML handler used to decode XML-RPC response from a server into appropriate XMLRPCObjects.
 * This class is used in conjunction with SAXParser in order to process the XML stream from the
 * server.
 *
 * @author  Jason Smith
 * @version 1.0
 * @see XMLRPCObject
 * @see org.xml.sax.SAXParser
 * @see org.xml.sax.helpers.DefaultHandler
 */
public class XMLRPCHandler extends org.xml.sax.helpers.DefaultHandler {
    
        public final int INT = 0;
        public final int INT4 = 1;
        public final int STRING = 2;
        public final int BIN64B = 3;
        public final int DOUBLE = 4;
        public final int BOOLEAN = 5;
        public final int DATETIME = 6;
        public final int XMLARRAY = 7;
        public final int STRUCT = 8;
        
        static final String[] Elements = {"methodResponse",""};
        static final String[] Types = {"int","i4","string","base64","double","boolean","dateTime.iso8601","array","struct"};
        int m_iLevel = -1;
        int m_iType = -1;
        Stack m_ObjStack = new Stack();
        
        Object m_Value = null;
        int m_iValType = -1;
        
        String m_szChars = null;
        StringBuffer m_szLog = null;
        int m_iLen = 0;

    /** Creates a new instance of XMLRPCHandler */
    public XMLRPCHandler(XMLRPCObject obj) {
        m_iLevel = -1;
        m_iType = -1;
        if (obj != null)
            m_ObjStack.push(obj);
    }

    public void setLen(int i)
    {
        m_iLen = i;
    }
    
    public void startDocument() throws SAXException
    {
        m_szLog = new StringBuffer(m_iLen);
    }
    
    public void endDocument() throws SAXException
    {
        System.out.print(m_szLog);
    }
    
    public void startElement(String uri,String localName,String qName,Attributes attributes)throws SAXException
    {
        m_szLog.append("<"+qName);
        int iNumAttr = attributes.getLength();
        for (int idx = 0; idx < iNumAttr; idx ++)
        {
            String attrName = attributes.getQName(idx);
            m_szLog.append(" "+attrName+"='"+attributes.getValue(attrName)+"'");
        }
        m_szLog.append(">");
        
        if (Elements[m_iLevel+1].compareToIgnoreCase(qName) == 0)
            m_iLevel++;
        else if (qName.compareToIgnoreCase("struct") == 0)
        {
            int i = 0;
            int iSize = m_ObjStack.size();
            String szMember = null;
            XMLRPCObject obj = null;
            for (i = iSize-1; i > -1; i--)
            {
                if (m_ObjStack.get(i) instanceof String)
                {
                    szMember = (String)m_ObjStack.get(i);
                    break;
                }
            }
            if (szMember == null) return;
            for (--i; i > -1; i--)
            {
                if (m_ObjStack.get(i) instanceof XMLRPCObject)
                {
                    obj = (XMLRPCObject)m_ObjStack.get(i);
                    break;
                }
            }
            if (obj == null) return;
            m_ObjStack.push(obj.newStruct(szMember));
        }
        else if (qName.compareToIgnoreCase("array") == 0)
        {
            m_ObjStack.push(new java.util.Vector());
        }
        else if (qName.compareToIgnoreCase("params") == 0)
        {
            XMLRPCObject obj = (XMLRPCObject)m_ObjStack.get(0);
            obj.m_bSentOK = true;
        }
        else if (qName.compareToIgnoreCase("fault") == 0)
        {
            XMLRPCObject obj = (XMLRPCObject)m_ObjStack.get(0);
            obj.m_bSentOK = false;
        }
        m_szChars = "";
    }
        
    public void endElement(String uri,String localName,String qName) throws SAXException
    {
        m_szLog.append("</"+qName+">");
        
        if (Elements[m_iLevel].compareToIgnoreCase(qName) == 0)
            m_iLevel --;
        else if (qName.compareToIgnoreCase("name") == 0)
        {
            m_ObjStack.push(new String(m_szChars));
            m_szChars = "";
        }
        else if (qName.compareToIgnoreCase("value") == 0)
        {
            Object obj = null;
            Object val = null;
            switch (m_iType)
            {
                case INT:
                case INT4:
                   val = new Integer(m_szChars);
                   break;
                case DOUBLE:
                    val = new Double(m_szChars);
                    break;
                case BOOLEAN:
                    val = new Boolean(m_szChars);
                    break;
                case DATETIME:
                try {
                    java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyyMMddTHH:mm:ss");
                    val = df.parse(m_szChars);
                } catch (java.text.ParseException e) { 
                    System.err.println(e); 
                    val = new String(m_szChars);
                }
                break;
                case BIN64B:
                    try
                    {
                        byte[] bytes = new sun.misc.BASE64Decoder().decodeBuffer(m_szChars);
                        val = ByteBuffer.wrap(bytes);
                    } catch (java.io.IOException e) { 
                        System.err.println(e);
                        byte[] bytes = {};
                        val = ByteBuffer.wrap(bytes);
                    }
                    break;
                case STRING:
                    val = new String(m_szChars);
                    break;
                default:
                    break;
                    
            }
            if (val == null) return;
            m_ObjStack.push(val);
            m_szChars = "";
            m_iType = -1;
        }
        else  if (qName.compareToIgnoreCase("member") == 0)
        {
            Object obj;
            Class cls;
            try
            {
                Field fld;
                String szName;
                Object oValue;
                oValue = m_ObjStack.pop();
                szName = (String)m_ObjStack.pop();
                obj = m_ObjStack.peek();                        
                if (obj instanceof XMLRPCObject)
                {
                    cls = ((XMLRPCObject)obj).getClass();
                    fld = cls.getField("m_"+szName.toLowerCase());
                
                    if (oValue == null) return;
                    fld.set(obj, oValue);
                }
                else if (obj instanceof Hashtable)
                {
                    Hashtable hash = (Hashtable)obj;
                    hash.put(szName,oValue);
                }
                 
            } catch (Exception e) { 
                System.err.println(e);
            }
        }
        else if (qName.compareToIgnoreCase("data") == 0)
        {
            Vector array = null;
            int iSize = m_ObjStack.size();
            int iDx;
            for (iDx = iSize-1; iDx > -1; iDx--)
            {
                Object obj = m_ObjStack.get(iDx);
                if (obj instanceof Vector)
                {
                    array = (Vector)obj;
                    break;
                }
            }
            if (array != null)
            {
                int iElems = iSize-1 - iDx;
                for (int i = 0; i < iElems; i++)
                    array.add(0, m_ObjStack.pop());
            }
        }
        else if (qName.compareToIgnoreCase("param") == 0)
        {
            if (m_iType != -1)
            {
                m_Value = m_ObjStack.pop();
                m_iValType = m_iType;
            }
        }
        else
        {
            for (int i = 0; i < Types.length; i++)
            {
                if (qName.compareToIgnoreCase(Types[i]) == 0)
                {
                    m_iType = i;
                    break;
                }
                m_iType = -1;
            }
        }
                
    }
        
    public Object getValue()
    {
        return m_Value;
    }
        
    public int getValueType()
    {
        return m_iValType;
    }
        
    public void characters(char buf[], int offset, int len) throws SAXException
    {
        String val = new String(buf,offset,len);
        m_szChars += val;
        m_szLog.append(val);
    }

    public boolean allProcessed()
    {
        return (m_iLevel == -1);
    }
}
