/*
 * XMLRPCObject.java
 *
 * Created on May 8, 2004, 1:18 PM
 */

package org.homedns.krolain.XMLRPC;
import java.lang.reflect.*;
import java.util.*;
import java.nio.ByteBuffer;
import sun.misc.BASE64Encoder;

/**
 *
 * @author  Krolain
 */
public class XMLRPCObject {
    
//    private static String[] m_ObjMembers = {"faultcode","faultstring"};
    public Object m_faultcode = null;
    public String m_faultstring = null;
                        
    protected Vector m_Members = null;
    public Object m_Value = null;
    public boolean m_bSentOK;
    
    public XMLRPCObject(String[] members)
    {
        m_Members = new Vector(); //java.util.Arrays.asList(m_ObjMembers));
        m_bSentOK = false;
        if (members != null)
            m_Members.addAll(java.util.Arrays.asList(members));
    }
    
    public Object newStruct(String szMemberName)
    {
        return null;
    }
    
    private String convertPrimitive(Object val,boolean bPublic)
    {
        String szResult = null;
        if (val instanceof ByteBuffer)
        {
            szResult = "<base64>";
            szResult += new sun.misc.BASE64Encoder().encode(((ByteBuffer)val).array());
            szResult += "</base64>";
        }
        else if (val instanceof Boolean)
        {
            szResult ="<boolean>";
            szResult += ((Boolean)val).booleanValue()?1:0;
            szResult += "</boolean>";
        }
        else if (val instanceof Integer)
        {
            szResult = "<int>";
            szResult += ((Integer)val).toString();
            szResult += "</int>";
        }
        else if (val instanceof String)
        {
            szResult = "<string>";
            szResult += (String)val;
            szResult += "</string>";
        }
        else if (val instanceof Vector)
        {
            szResult = "<array><data>";
            Vector list = (Vector)val;
            int iSize = list.size();
            for (int i = 0; i < iSize; i++)
            {
                szResult +="<value>";
                Object obj = list.get(i);
                if (obj instanceof XMLRPCObject)
                    szResult += ((XMLRPCObject)obj).toString(bPublic);
                else
                    szResult += convertPrimitive(obj,bPublic);
                szResult +="</value>";
            }
            szResult += "</data></array>";
        }
        else if (val instanceof java.util.Hashtable)
        {
            Hashtable table = (Hashtable)val;
            szResult = "<struct>";
            String szNames[];
            Set set = table.keySet();
            int iSize = set.size();
            szNames = new String[iSize];
            table.keySet().toArray(szNames);
            for (int i = 0; i < iSize; i++)
            {
                szResult +="<member><name>"+szNames[i]+"</name><value>";
                Object obj = table.get(szNames[i]);
                if (obj instanceof XMLRPCObject)
                    szResult += ((XMLRPCObject)obj).toString();
                else
                    szResult += convertPrimitive(obj,bPublic);
                szResult+="</value></member>";
            }
            szResult += "</struct>";
        }
        return szResult;
    }
    
    public static String toString(Object obj)
    {
        if (obj instanceof String)
            return ((String)obj);
        else if (obj instanceof Integer)
            return ((Integer)obj).toString();
        else if (obj instanceof Boolean)
            return ((Boolean)obj).toString();
        else if (obj instanceof Date)
        {
            java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("yyyyMMddTHH:mm:ss");
            return df.format((Date)obj);
        } else if (obj instanceof ByteBuffer)
        {
            try
            {
                return new String(((ByteBuffer)obj).array(),"UTF-8");
            } catch (java.io.UnsupportedEncodingException e) { System.err.println(e); }
        }
        return "";
    }
    
    public String toString(boolean bPublic)
    {
        String szResult = null;
        if (m_Value != null)
        {
            szResult = convertPrimitive(m_Value,bPublic);
        }
        else if (m_Members != null)
        {
            szResult = "<struct>";
            Class cls = getClass();
            int iSize = m_Members.size();
            for (int i = 0; i < iSize; i++)
            {
                try
                {   // If we are showing this 'publically' we skip the password info.
                    String member = (String)m_Members.get(i);
                    if ((bPublic) && 
                        ((member.compareToIgnoreCase("password") == 0) ||
                         (member.compareToIgnoreCase("hpassword") == 0) ||
                         (member.compareToIgnoreCase("auth_response") == 0)))
                        continue;
                    String szTemp;
                    Field fld = cls.getField("m_"+member);
                    Object obj = fld.get(this);
                    if (obj != null)
                    {
                        szTemp ="<member><name>"+member+"</name><value>";
                        if (obj instanceof XMLRPCObject)
                            szTemp += ((XMLRPCObject)obj).toString(bPublic);
                        else
                            szTemp += convertPrimitive(obj,bPublic);
                        szTemp += "</value></member>";
                        szResult += szTemp;
                    }
                } catch (Exception e) { System.out.println(e); }
            }
            szResult += "</struct>";
        }
        return szResult;
    }
    
}
