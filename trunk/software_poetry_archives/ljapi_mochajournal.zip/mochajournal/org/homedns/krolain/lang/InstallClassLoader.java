/*
 * InstallClassLoader.java
 *
 * Created on September 13, 2002, 12:01 PM
 */

package org.homedns.krolain.lang;

/**
 *
 * @author  jsmith
 */
public class InstallClassLoader extends java.lang.ClassLoader {
    
    private String m_szInstallPath;
    /** Creates a new instance of InstallClassLoader */
    public InstallClassLoader(String szInstallPath) {
        m_szInstallPath = szInstallPath;
    }
    
    /** Returns an input stream for reading the specified resource.
     *
     * The search order is described in the documentation for {@link
     * #getResource(String)}.<p>
     *
     * @param  name the resource name
     * @return an input stream for reading the resource, or <code>null</code>
     *         if the resource could not be found
     * @since  JDK1.1
     */
    public java.io.InputStream getResourceAsStream(String name) {
        try
        {
            java.io.File file = new java.io.File(m_szInstallPath+name);
            if (!file.exists()) return null;
            return new java.io.FileInputStream(file);
        } catch (java.io.FileNotFoundException e)
        {
            System.err.println(e);
            return null;
        }
    }
}
