/*
 * TrayIcon.java
 *
 * Created on March 6, 2004, 12:29 PM
 */

package org.homedns.krolain.plaf;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import org.homedns.krolain.plaf.event.TrayIconEvent;
import java.awt.image.*;
import java.io.*;
/**
 *
 * @author  Krolain
 */
public class TrayIcon implements javax.swing.event.ChangeListener, java.lang.Runnable {
    
    private static final int MENU_ID_START = 0x1216;
    
    private static final short MENU_ITEM = 0;
    private static final short MENU_SEPARATOR = 1;
    private static final short MENU_CHECK = 2;
    private static final short MENU_RADIO = 3;
    
    private static final int STATE_CHECK = 1;
    private static final int STATE_UNCHECK = 2;
    private static final int STATE_ENABLE = 4;
    private static final int STATE_GRAYED = 8;
    
    private java.util.Hashtable m_Menus = null;
    private java.util.Hashtable m_MenuIDs = null;
    private java.util.Vector m_TrayListeners = null;
    private boolean m_bInitialized = false;
    private boolean m_bMenuShowing = false;
    private boolean m_bTrayShowing = false;
    private int m_iCurMenuID;
    private boolean m_bMenuSet = false;
    
    private native void initTrayIcon();
    private native void showTrayIcon(boolean bShow);
    private native void removeTrayIcon();
    
    private native void createNativeMenu();
    private native void showNativeMenu(int x, int y);
    private native void addNativeMenuItem(String szLabel,int iMenuID, int iItemType);
    private native void setNativeMenuState(int iMenuID, int iNewState); 
    private native void startNativeSubMenu(String szLabel);
    private native void endNativeSubMenu();
    
    private native void setTrayIcon(int[] iPixels,int iWidth, int iHeight);
    
    private BufferedReader m_Reader;
    private BufferedWriter m_Writer;
    private Thread m_Thread;
    
    public JMenu menu = null;
    
    /** Creates a new instance of TrayIcon */
    public TrayIcon(String szPath) throws java.lang.UnsatisfiedLinkError {
        m_Menus = new java.util.Hashtable(10);
        m_MenuIDs = new java.util.Hashtable(10);
        m_TrayListeners = new java.util.Vector();
        // We need to create a piped stream between the java process and the 
        // tray icon process.  Reason being is that some function NEED to run
        // off the main java thread and not the tray icon thread.
        PipedWriter out = new PipedWriter();
        m_Writer = new BufferedWriter(out);
        try
        {
            PipedReader in = new PipedReader(out);
            m_Reader = new BufferedReader(in);
            m_Thread = new Thread(this);
            m_Thread.start();
            String szLib = System.mapLibraryName(szPath+System.getProperty("file.separator")+"TrayIcon");
            System.load(szLib);
            initTrayIcon();
            m_bInitialized = true;
            m_iCurMenuID = MENU_ID_START;
        } catch (IOException e) { 
            System.err.println(e); 
        }

    }
    
    // This function simply listens to the piped thread for any bytes passed
    // from the tray icon thread.  Each byte represent the menu index to click.
    public void run()
    {
        try
        {
            int id;
            while ((id = m_Reader.read()) != 1)
            {
                Object obj = m_Menus.get(new Integer(id));
                if (obj != null)
                    ((JMenuItem)obj).doClick();
            }
            m_Reader.close();
        } catch (IOException e) {
            System.err.println(e);
        }
    }
    
    public boolean setIcon(Image image, int iWidth, int iHeight)
    {
        int[] pixels = new int[iWidth*iHeight];
	PixelGrabber pg = new PixelGrabber(image, 0, 0, iWidth, iHeight, pixels, 0, iWidth);
	try
        {
            pg.grabPixels();
            setTrayIcon(pixels,iWidth,iHeight);
        } catch (InterruptedException e) { 
            System.err.println(e);
            return false;
        }
        
        return true;

    }
    
    public boolean addTrayListner(TrayIconListener l)
    {
        if (m_TrayListeners.indexOf(l) == -1)
            return m_TrayListeners.add(l);
        else
            return false;
    }
    
    public boolean removeTrayListner(TrayIconListener l)
    {
        return m_TrayListeners.remove(l);
    }
    
    public void deleteTrayIcon()
    {
        removeTrayIcon();
        try
        {
            m_Writer.close();
        } catch (IOException e) { System.err.println(e); }
        m_bInitialized = false;
    }
    
    public void show(boolean b)
    {
        if (m_bInitialized && (m_bTrayShowing!= b))
        {
            showTrayIcon(b);
            m_bTrayShowing = b;
        }
    }
    
    private void parseMenu(javax.swing.JMenu menu)
    {
        JMenuItem item = null;
        int iSize = menu.getMenuComponentCount();
        for (int i = 0; i < iSize; i++)
        {
            Component comp = menu.getMenuComponent(i);
            if (comp instanceof JMenuItem)
            {
                item = (JMenuItem)comp;
                if (item instanceof JMenu)
                {
                    startNativeSubMenu(item.getText());
                    parseMenu((JMenu)item);
                    endNativeSubMenu();
                }
                else if (comp instanceof JCheckBoxMenuItem)
                {
                    m_Menus.put(new Integer(++m_iCurMenuID),item);
                    m_MenuIDs.put(item, new Integer(m_iCurMenuID));
                    addNativeMenuItem(item.getText(), m_iCurMenuID, MENU_CHECK);
                }
                else if (comp instanceof JRadioButtonMenuItem)
                {
                    m_Menus.put(new Integer(++m_iCurMenuID),item);
                    m_MenuIDs.put(item, new Integer(m_iCurMenuID));
                    addNativeMenuItem(item.getText(), m_iCurMenuID, MENU_RADIO);
                }
                else
                {
                    m_Menus.put(new Integer(++m_iCurMenuID),item);
                    m_MenuIDs.put(item, new Integer(m_iCurMenuID));
                    addNativeMenuItem(item.getText(), m_iCurMenuID,MENU_ITEM);
                }
                int iState = 0;
                iState |= item.isSelected()?STATE_CHECK:STATE_UNCHECK;
                iState |= item.isEnabled()?STATE_ENABLE:STATE_GRAYED;
                setNativeMenuState(m_iCurMenuID,iState);
                item.addChangeListener(this);
            }
            else if (comp instanceof JSeparator)
            {
                addNativeMenuItem("", -1, MENU_SEPARATOR);
            }
        }
    }
    

    public void showMenu(int x, int y)
    {
        if ((m_bMenuSet) && !m_bMenuShowing)
        {
            m_bMenuShowing = true;
            showNativeMenu(x,y);
            m_bMenuShowing = false;
        }
    }
    
    public void setMenu(javax.swing.JMenu menu)
    {
        if (!m_bInitialized) return;
        
        m_bMenuSet = false;
        m_iCurMenuID = MENU_ID_START;

        Object[] items = m_Menus.values().toArray();
        int iSize = items.length;
        for (int i = 0; i < iSize; i++)
            ((JMenuItem)items[i]).removeChangeListener(this);
        
        m_Menus.clear();
        m_MenuIDs.clear();
        createNativeMenu();
        parseMenu(menu);
        m_bMenuSet = true;
    }
    
    public void showMenu(javax.swing.JMenu menu,int x, int y)
    {
        setMenu(menu);
        showMenu(x,y);
    }
    
    private void menuClicked(int iMenuID)
    {
        try
        {
            // Use the piped stream to indicate which menu item was clicked.
            m_Writer.write(iMenuID);
            m_Writer.flush();
        } catch (IOException e) { 
            System.err.println(e); 
        }
    }
    
    private void mouseClicked(int iBtn, int x, int y, int iClicks, boolean bPopup) {
        TrayIconEvent e = new TrayIconEvent(this, TrayIconEvent.TRAY_CLICKED, x, y, iBtn, iClicks);
        int iSize = m_TrayListeners.size();
        for (int i = 0; i < iSize; i++)
            ((TrayIconListener)m_TrayListeners.get(i)).TrayClicked(e);
    }
    
    private void mousePressed(int iBtn, int x, int y, int iClicks, boolean bPopup) {
        TrayIconEvent e = new TrayIconEvent(this, TrayIconEvent.TRAY_PRESSED, x, y, iBtn, iClicks);
        int iSize = m_TrayListeners.size();
        for (int i = 0; i < iSize; i++)
            ((TrayIconListener)m_TrayListeners.get(i)).TrayPressed(e);
    }
    
    private void mouseReleased(int iBtn, int x, int y, int iClicks, boolean bPopup)
    {
        TrayIconEvent e = new TrayIconEvent(this, TrayIconEvent.TRAY_RELEASED, x, y, iBtn, iClicks);
        int iSize = m_TrayListeners.size();
        for (int i = 0; i < iSize; i++)
            ((TrayIconListener)m_TrayListeners.get(i)).TrayReleased(e);
    }
    
    public void stateChanged(javax.swing.event.ChangeEvent e) {
        int iState = 0;
        if (e.getSource() instanceof JMenuItem)
        {
            JMenuItem item = (JMenuItem)e.getSource();
            iState |= item.isSelected()?STATE_CHECK:STATE_UNCHECK;
            iState |= item.isEnabled()?STATE_ENABLE:STATE_GRAYED;
            Object obj = m_MenuIDs.get(item);
            if (obj != null)
            {
                int iMenuID = ((Integer)obj).intValue();
                setNativeMenuState(iMenuID,iState);
            }
        }
    }
    
}
