/*
 * TrayIconListener.java
 *
 * Created on March 10, 2004, 6:53 PM
 */

package org.homedns.krolain.plaf;
import org.homedns.krolain.plaf.event.TrayIconEvent;
/**
 *
 * @author  Krolain
 */
public interface TrayIconListener {
    public void TrayClicked(TrayIconEvent e);
    public void TrayPressed(TrayIconEvent e);
    public void TrayReleased(TrayIconEvent e);
}
