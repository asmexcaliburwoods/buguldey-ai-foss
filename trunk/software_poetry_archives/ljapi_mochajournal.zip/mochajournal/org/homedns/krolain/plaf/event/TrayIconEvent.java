/*
 * TrayIconEvent.java
 *
 * Created on March 10, 2004, 6:58 PM
 */

package org.homedns.krolain.plaf.event;

/**
 *
 * @author  Krolain
 */
public class TrayIconEvent extends java.util.EventObject {
    
    public static final int NOBUTTON = 0;
    public static final int BUTTON1 = 1;
    public static final int BUTTON2 = 2;
    public static final int BUTTON3 = 3;

    public static final int TRAY_FIRST = 0;
    public static final int TRAY_CLICKED = 0;
    public static final int TRAY_PRESSED = 1;
    public static final int TRAY_RELEASED = 2;
    public static final int TRAY_LAST = 2;
    
    private int m_iNumClicks;
    private int m_iButton;
    private int m_iEventID;
    private int m_iX;
    private int m_iY;
    
    /** Creates a new instance of TrayIconEvent */
    public TrayIconEvent(Object source,int event, int x, int y, int button, int clickcount) {
        super(source);
        m_iEventID = event;
        m_iX = x;
        m_iY = y;
        m_iButton = button;
        m_iNumClicks = clickcount;
    }
    
    public int getButton()
    {
        return m_iButton;
    }
    
    public int getX()
    {
        return m_iX;
    }
    
    public int getY()
    {
        return m_iY;
    }
    
    public java.awt.Point getPoint()
    {
        return new java.awt.Point(m_iX, m_iY);
    }
    
    public int getID()
    {
        return m_iEventID;
    }
    
    public int getClickCount()
    {
        return m_iNumClicks;
    }
    
}
