/*
 * ErrorLogPrintStream.java
 *
 * Created on July 26, 2002, 9:45 PM
 */

package org.homedns.krolain.swing;

import java.io.*;
import javax.swing.*;
import java.awt.BorderLayout;
import java.util.Calendar;
import java.text.SimpleDateFormat;

/**
 *
 * @author  krolain
 */
public class ErrorLogPrintStream extends java.io.PrintStream {
    
    static JTextArea m_LogWnd = null;
    static JDialog m_Diag = null;
    String m_szCRLF = null; 
    static int m_iRef = 0;
    static boolean m_bNewLine = true;
    static SimpleDateFormat m_DF = null;
    static OutputStream m_Out = null;
    boolean m_bError = false;
    String m_szError = null;
    
    /** Creates a new instance of ErrorLogPrintStream */
    
    protected ErrorLogPrintStream()
    {
        this(m_Out);
    }
    
    protected ErrorLogPrintStream(OutputStream out) {
        super(out);
        initComponents();
        m_iRef++;
    }
    
    protected ErrorLogPrintStream(OutputStream out, boolean autoFlush)
    {
        super(out, autoFlush);
        initComponents();
        m_iRef++;
    }

    protected ErrorLogPrintStream(OutputStream out, boolean autoFlush, String encoding) throws UnsupportedEncodingException
    {
        super(out, autoFlush, encoding);
        initComponents();
        m_iRef++;
    }
    
    private void initComponents()
    {
        m_szCRLF = System.getProperty("line.separator");
        if (m_LogWnd == null)
        {
            m_LogWnd = new JTextArea();
            m_DF = new SimpleDateFormat("[dd/MM/yy HH:mm:ss]");
            m_Diag = new JDialog(new JFrame());
            m_Diag.getContentPane().setLayout(new BorderLayout());
            JScrollPane pane = new JScrollPane(m_LogWnd);
            m_Diag.getContentPane().add("Center",pane);
            m_Diag.setSize(300,200);
            println("***************Begin Session*******************");
        }
    }

    static public void showWindow(boolean bShow)
    {
        if ((m_Diag != null) && !m_Diag.isVisible())
        {
            m_Diag.show();
        }
    }
    
    static public ErrorLogPrintStream getInstance(String szFileName,boolean bError,String szError) throws FileNotFoundException
    {
        ErrorLogPrintStream result;
        if (szFileName == null) return null;

        if (m_Out == null)
        {
            m_Out = new java.io.FileOutputStream(szFileName);
            result = new ErrorLogPrintStream(m_Out);
            m_Diag.setTitle(szFileName);
            result.m_bError = bError;
            result.m_szError = szError;
        }
        else
        {
            result = new ErrorLogPrintStream(m_Out);
            result.m_bError = bError;
            result.m_szError = szError;
        }
        return result;
    }
    
    synchronized private void writeText(String szText)
    {
        if (m_bNewLine)
        {
            Calendar calen = Calendar.getInstance();
            String ts = m_DF.format(calen.getTime());
            m_LogWnd.append(ts+" ");
            super.print(ts+" ");
            m_bNewLine = false;
        }
        if (m_bError && m_szError != null)
        {
            m_LogWnd.append(m_szError+" ");
            super.print(m_szError+" ");
        }
        m_LogWnd.append(szText);
        super.print(szText);
    }
    
    /** Close the stream.  This is done by flushing the stream and then closing
     * the underlying output stream.
     *
     * @see        java.io.OutputStream#close()
     */
    public void close() {
        m_iRef --;
        if (m_iRef == 0)
        {
            m_bError = false;
            m_szError = null;
            println("***************End Session*******************");
            m_Diag.setVisible(false);
            m_Diag.dispose();
            super.close();
        }
    }
    
    /** Print a boolean value.  The string produced by <code>{@link
     * java.lang.String#valueOf(boolean)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      b   The <code>boolean</code> to be printed
     */
    public void print(boolean b) {
        writeText(String.valueOf(b));
    }
    
    /** Print a character.  The character is translated into one or more bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      c   The <code>char</code> to be printed
     */
    public void print(char c) {
        writeText(String.valueOf(c));
    }
    
    /** Print an array of characters.  The characters are converted into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      s   The array of chars to be printed
     *
     * @throws  NullPointerException  If <code>s</code> is <code>null</code>
     */
    public void print(char[] s) {
        writeText(String.valueOf(s));
    }
    
    /** Print a double-precision floating-point number.  The string produced by
     * <code>{@link java.lang.String#valueOf(double)}</code> is translated into
     * bytes according to the platform's default character encoding, and these
     * bytes are written in exactly the manner of the <code>{@link
     * #write(int)}</code> method.
     *
     * @param      d   The <code>double</code> to be printed
     * @see        java.lang.Double#toString(double)
     */
    public void print(double d) {
        writeText(String.valueOf(d));
    }
    
    /** Print a floating-point number.  The string produced by <code>{@link
     * java.lang.String#valueOf(float)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      f   The <code>float</code> to be printed
     * @see        java.lang.Float#toString(float)
     */
    public void print(float f) {
        writeText(String.valueOf(f));
    }
    
    /** Print an integer.  The string produced by <code>{@link
     * java.lang.String#valueOf(int)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      i   The <code>int</code> to be printed
     * @see        java.lang.Integer#toString(int)
     */
    public void print(int i) {
        writeText(String.valueOf(i));
    }
    
    /** Print an object.  The string produced by the <code>{@link
     * java.lang.String#valueOf(Object)}</code> method is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      obj   The <code>Object</code> to be printed
     * @see        java.lang.Object#toString()
     */
    public void print(Object obj) {
        writeText(String.valueOf(obj));
    }
    
    /** Print a string.  If the argument is <code>null</code> then the string
     * <code>"null"</code> is printed.  Otherwise, the string's characters are
     * converted into bytes according to the platform's default character
     * encoding, and these bytes are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      s   The <code>String</code> to be printed
     */
    public void print(String s) {
        writeText(s);
    }
    
    /** Print a long integer.  The string produced by <code>{@link
     * java.lang.String#valueOf(long)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      l   The <code>long</code> to be printed
     * @see        java.lang.Long#toString(long)
     */
    public void print(long l) {
        writeText(String.valueOf(l));
    }
    
    /** Terminate the current line by writing the line separator string.  The
     * line separator string is defined by the system property
     * <code>line.separator</code>, and is not necessarily a single newline
     * character (<code>'\n'</code>).
     */
    public void println() {
        super.println();
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print a boolean and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(boolean)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>boolean</code> to be printed
     */
    public void println(boolean x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print a character and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(char)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>char</code> to be printed.
     */
    public void println(char x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print an array of characters and then terminate the line.  This method
     * behaves as though it invokes <code>{@link #print(char[])}</code> and
     * then <code>{@link #println()}</code>.
     *
     * @param x  an array of chars to print.
     */
    public void println(char[] x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print a double and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(double)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>double</code> to be printed.
     */
    public void println(double x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print a float and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(float)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>float</code> to be printed.
     */
    public void println(float x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print an integer and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(int)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>int</code> to be printed.
     */
    public void println(int x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print an Object and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(Object)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>Object</code> to be printed.
     */
    public void println(Object x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print a String and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(String)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>String</code> to be printed.
     */
    public void println(String x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
    /** Print a long and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(long)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  a The <code>long</code> to be printed.
     */
    public void println(long x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
        m_bNewLine = true;
    }
    
}
