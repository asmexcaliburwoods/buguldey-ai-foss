/*
 * JCalendar.java
 *
 * Created on July 8, 2002, 12:42 PM
 */

package org.homedns.krolain.swing;

import javax.swing.JPanel;
import java.awt.Component;
import javax.swing.JDialog;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Frame;
import javax.swing.SwingUtilities;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JComboBox;
import java.awt.GridLayout;
import java.util.Calendar;
import javax.swing.JLabel;
import javax.swing.JTextField;
/**
 *
 * @author  jsmith
 */

class JDateLabel extends javax.swing.JPanel
{
    public final static int BUTTON1 = java.awt.event.MouseEvent.BUTTON1;
    public final static int BUTTON2 = java.awt.event.MouseEvent.BUTTON2;
    public final static int BUTTON3 = java.awt.event.MouseEvent.BUTTON3;
    
    java.awt.Color m_OldBG = null;
    java.awt.Color m_OldFG = null;
    
    JLabel m_Date = null;
    String m_szLabel = null;
    JLabel m_szText = null;
    public JDateLabel()
    {
        m_szLabel = "";
        initComponenets();
    }
    
    public JDateLabel(String szLabel)
    {
        m_szLabel = szLabel;
        initComponenets();
        m_OldBG = m_szText.getBackground();
        m_OldFG = m_szText.getForeground();
    }

    private void initComponenets()
    {
        JLabel label;
        if (m_szLabel.length() < 1) return;
        java.awt.Dimension dim = new java.awt.Dimension();
        setLayout(new java.awt.GridBagLayout());
        setBorder(new javax.swing.border.LineBorder(java.awt.Color.black));
        
        java.awt.GridBagConstraints gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 2;
        gridBagConstraints.ipady = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.weightx = 0.2;
        gridBagConstraints.weighty = 0.0;
        m_Date = new JLabel(m_szLabel,JLabel.CENTER);
        dim.height = getSize().height / 2;
        dim.width = getSize().width / 2;
        m_Date.setMaximumSize(dim);
        add(m_Date,gridBagConstraints);
        
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        m_szText = new JLabel(" ",JLabel.CENTER);
        dim.height = getSize().height / 2;
        dim.width = getSize().width;
        m_szText.setMaximumSize(dim);
        add (m_szText,gridBagConstraints);
        
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.gridheight = 1;
        gridBagConstraints.weightx = 0.8;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        label = new JLabel(" ");
        dim.height = getSize().height /2;
        dim.width = getSize().width / 2;
        label.setMinimumSize(dim);
        add (label,gridBagConstraints);
        
    }
    
    public void setText(String szText)
    {
        m_szText.setText(szText);
    }
    
    public int getDay()
    {
        if (m_szLabel.length() == 0) return 0;
        return new java.lang.Integer(m_szLabel).intValue();
    }
    
    public void hightLight(boolean bHighlight)
    {
        if (m_szLabel.length() < 1) return;
        if (bHighlight)
            m_Date.setText("<HTML><BODY BGCOLOR=black COLOR=white><B>"+m_szLabel+"</B></BODY></HTML>");
        else
            m_Date.setText(m_szLabel);
    }
}

public class JCalendar extends javax.swing.JComponent {
    
    JDialog m_Dialog = null;
    JComboBox m_MonthList = null;
    JPanel m_CalenPane = null;
    JTextField m_YearText = null;
    JDateLabel m_SelDate = null;
    boolean m_bHightLight = true;
    java.util.Locale m_Locale = null;
    
    /** Creates a new instance of JCalendar */
/*    public JCalendar() {
        this(null);
    } */

    public JCalendar(java.util.Locale loc) {
        if (loc == null)
            m_Locale = java.util.Locale.getDefault();
        else
            m_Locale = loc;
        
        initComponenets();
    }

    private void initComponenets()
    {
        JPanel topPane = new JPanel();
        topPane.setLayout(new FlowLayout());
        m_MonthList = new JComboBox();
        topPane.add(m_MonthList);
        m_YearText = new JTextField(4);
        topPane.add(m_YearText);
        setLayout(new BorderLayout());
        add(topPane,"North");
        m_CalenPane = new JPanel();
        m_CalenPane.setLayout(new GridLayout(7,7,1,1));
        Calendar calen = Calendar.getInstance();
        PopulateCalendar(calen.get(Calendar.MONTH),calen.get(Calendar.YEAR));
        PopulateMonths();
        m_MonthList.setSelectedIndex(calen.get(Calendar.MONTH)-Calendar.JANUARY);
        m_MonthList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                String szYear = m_YearText.getText();
                if (szYear.length() == 4)
                {
                    PopulateCalendar(m_MonthList.getSelectedIndex(),new java.lang.Integer(szYear).intValue());
                    calenChanged();
                }
            }
        });
        m_YearText.setText(java.lang.Integer.toString(calen.get(Calendar.YEAR)));
        m_YearText.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent evt) {
                String szYear = m_YearText.getText();
                if (szYear.length() == 4)
                {
                    PopulateCalendar(m_MonthList.getSelectedIndex(),new java.lang.Integer(szYear).intValue());
                    calenChanged();
                }
            }
            public void removeUpdate(javax.swing.event.DocumentEvent evt) {
                String szYear = m_YearText.getText();
                if (szYear.length() == 4)
                {
                    PopulateCalendar(m_MonthList.getSelectedIndex(),new java.lang.Integer(szYear).intValue());
                    calenChanged();
                }
            }
            public void changedUpdate(javax.swing.event.DocumentEvent evt) {}
        });
        add(m_CalenPane,"Center");
    }
    
    public void calenChanged()
    {
    }
    
    public void dayClicked(int iDay, int iButton, boolean bDouble)
    {
    }
    
    private void PopulateMonths()
    {
        String[] months = new java.text.DateFormatSymbols(m_Locale).getMonths();
        m_MonthList.addItem(months[Calendar.JANUARY]);
        m_MonthList.addItem(months[Calendar.FEBRUARY]);
        m_MonthList.addItem(months[Calendar.MARCH]);
        m_MonthList.addItem(months[Calendar.APRIL]);
        m_MonthList.addItem(months[Calendar.MAY]);
        m_MonthList.addItem(months[Calendar.JUNE]);
        m_MonthList.addItem(months[Calendar.JULY]);
        m_MonthList.addItem(months[Calendar.AUGUST]);
        m_MonthList.addItem(months[Calendar.SEPTEMBER]);
        m_MonthList.addItem(months[Calendar.OCTOBER]);
        m_MonthList.addItem(months[Calendar.NOVEMBER]);
        m_MonthList.addItem(months[Calendar.DECEMBER]);
    }
    
    private void PopulateCalendar(int iMonth,int iYear)
    {
        m_CalenPane.removeAll();
        
        String[] days = new java.text.DateFormatSymbols(m_Locale).getShortWeekdays();
        m_CalenPane.add(new JLabel(days[Calendar.SUNDAY],JLabel.CENTER));
        m_CalenPane.add(new JLabel(days[Calendar.MONDAY],JLabel.CENTER));
        m_CalenPane.add(new JLabel(days[Calendar.TUESDAY],JLabel.CENTER));
        m_CalenPane.add(new JLabel(days[Calendar.WEDNESDAY],JLabel.CENTER));
        m_CalenPane.add(new JLabel(days[Calendar.THURSDAY],JLabel.CENTER));
        m_CalenPane.add(new JLabel(days[Calendar.FRIDAY],JLabel.CENTER));
        m_CalenPane.add(new JLabel(days[Calendar.SATURDAY],JLabel.CENTER));
        
        Calendar calen = Calendar.getInstance();
        calen.set(Calendar.YEAR,iYear);
        calen.set(Calendar.MONTH,iMonth+Calendar.JANUARY);
        int iMaxDay = calen.getActualMaximum(Calendar.DAY_OF_MONTH);
        calen.set(Calendar.DAY_OF_MONTH,1);
        int iFirstDay = calen.get(Calendar.DAY_OF_WEEK);
        for (int i = Calendar.SUNDAY; i < iFirstDay; i++)
            m_CalenPane.add (new JDateLabel());
        for (int i = 1; i <=iMaxDay; i++)
        {
            JDateLabel dateLabel = new JDateLabel(java.lang.Integer.toString(i));
            dateLabel.addMouseListener(new java.awt.event.MouseListener() {
                public void mouseClicked(java.awt.event.MouseEvent e) 
                {
                    Object obj = e.getSource();
                    if (obj instanceof JDateLabel)
                    {
                        if (m_bHightLight)
                        {
                            if (m_SelDate != null)
                                m_SelDate.hightLight(false);
                             m_SelDate = (JDateLabel)obj;
                             m_SelDate.hightLight(true);
                        }
                        dayClicked(((JDateLabel)obj).getDay(),e.getButton(),(e.getClickCount() == 2));
                    }
                }
                public void mouseEntered(java.awt.event.MouseEvent e) {}
                public void mouseExited(java.awt.event.MouseEvent e) {}
                public void mousePressed(java.awt.event.MouseEvent e) {}
                public void mouseReleased(java.awt.event.MouseEvent e) {}
            });
            m_CalenPane.add (dateLabel);
        }
        for (int i = iMaxDay+iFirstDay; i <= 42; i++)
            m_CalenPane.add (new JDateLabel());
            
    }
    
    public void showDialog(Component parent)
    {
	m_Dialog = createDialog(parent);
	m_Dialog.addWindowListener(new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
	    }
	});

	m_Dialog.show();
	m_Dialog.dispose();
	m_Dialog = null;
    }

    protected JDialog createDialog(Component parent) {
        Frame frame = parent instanceof Frame ? (Frame) parent
              : (Frame)SwingUtilities.getAncestorOfClass(Frame.class, parent);

        JDialog dialog = new JDialog(frame, "Calendar", true);

        Container contentPane = dialog.getContentPane();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(this, BorderLayout.CENTER);
 
        dialog.pack();
        dialog.setLocationRelativeTo(parent);

	return dialog;
    }
    
    public void setText (int iDay, String szText)
    {
       for (int i = 7; i <= 42; i++)
       {
           java.awt.Component comp = m_CalenPane.getComponent(i);
           if (comp instanceof JDateLabel)
           {
               if (((JDateLabel)comp).getDay() == iDay)
                   ((JDateLabel)comp).setText(szText);
           }
       }
    }
    
    public void setText(Object[] iDay, Object[] szText)
    {
        int iNumDay = java.util.Arrays.asList(iDay).size();
        int iNumText = java.util.Arrays.asList(szText).size();
        if (iNumDay != iNumText) return;
        
        for (int i = 0; i < iNumDay; i++)
        {
            Object obj1 = iDay[i];
            Object obj2 = szText[i];
            if ((obj1 instanceof java.lang.Integer) && (obj2 instanceof String))
                setText(((java.lang.Integer)obj1).intValue(),(String)obj2);
        }
    }
    
    public int getMonth()
    {
        return Calendar.JANUARY + m_MonthList.getSelectedIndex();
    }
    
    public int getYear()
    {
        String szYear = m_YearText.getText();
        if (szYear.length() == 4)
        {
            return new java.lang.Integer(szYear).intValue();
        }
        else
            return -1;
        
    }
    
    public void addActionListener(java.awt.event.ActionListener listen)
    {
        m_MonthList.addActionListener(listen);
    }

    public void  addDocumentListener(javax.swing.event.DocumentListener listen)
    {
        m_YearText.getDocument().addDocumentListener(listen);
    }

    public void setHighlight(boolean bHightLight)
    {
        m_bHightLight = bHightLight;
    }
    
    public boolean getHightlight()
    {
        return m_bHightLight;
    }
}
