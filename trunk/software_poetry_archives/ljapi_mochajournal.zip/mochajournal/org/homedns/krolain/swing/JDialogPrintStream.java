/*
 * JDialogPrintStream.java
 *
 * Created on July 26, 2002, 12:20 PM
 */

package org.homedns.krolain.swing;

import javax.swing.*;
import java.awt.BorderLayout;
import java.io.*;

/**
 *
 * @author  jsmith
 */
public class JDialogPrintStream extends java.io.PrintStream implements java.lang.Runnable {

    
    JTextArea m_LogWnd = null;
    JDialog m_Diag = null;
    String m_szCRLF = null; 
    Thread m_TD = null;

    /** Creates a new instance of JDialogPrintStream */
    public JDialogPrintStream(OutputStream out) {
        super(out);
        initComponents();
        
    }
    public JDialogPrintStream(OutputStream out, boolean autoFlush)
    {
        super(out, autoFlush);
        initComponents();
    }

    public JDialogPrintStream(OutputStream out, boolean autoFlush, String encoding) throws UnsupportedEncodingException
    {
        super(out, autoFlush, encoding);
        initComponents();
    }

    private void initComponents()
    {
        m_szCRLF = System.getProperty("line.separator");
        m_LogWnd = new JTextArea();
        
        m_Diag = new JDialog(new JFrame());
        m_Diag.getContentPane().setLayout(new BorderLayout());
        JScrollPane pane = new JScrollPane(m_LogWnd);
        m_Diag.getContentPane().add("Center",pane);
        m_Diag.setSize(300,200);
        m_TD = new Thread(this);
        m_TD.start();
    }
    
    /** Close the stream.  This is done by flushing the stream and then closing
     * the underlying output stream.
     *
     * @see        java.io.OutputStream#close()
     */
    public void close() {
        super.close();
        m_Diag.setVisible(false);
        m_Diag.dispose();
    }
    
    /** Flush the stream.  This is done by writing any buffered output bytes to
     * the underlying output stream and then flushing that stream.
     *
     * @see        java.io.OutputStream#flush()
     */
    public void flush() {
        super.flush();
    }
    
    /** Print a boolean value.  The string produced by <code>{@link
     * java.lang.String#valueOf(boolean)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      b   The <code>boolean</code> to be printed
     */
    public void print(boolean b) {
        super.print(b);
        m_LogWnd.append(java.lang.String.valueOf(b));
    }
    
    /** Print a character.  The character is translated into one or more bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      c   The <code>char</code> to be printed
     */
    public void print(char c) {
        super.print(c);
        m_LogWnd.append(String.valueOf(c));
    }
    
    /** Print an array of characters.  The characters are converted into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      s   The array of chars to be printed
     *
     * @throws  NullPointerException  If <code>s</code> is <code>null</code>
     */
    public void print(char[] s) {
        super.print(s);
        m_LogWnd.append(String.valueOf(s));
    }
    
    /** Print a double-precision floating-point number.  The string produced by
     * <code>{@link java.lang.String#valueOf(double)}</code> is translated into
     * bytes according to the platform's default character encoding, and these
     * bytes are written in exactly the manner of the <code>{@link
     * #write(int)}</code> method.
     *
     * @param      d   The <code>double</code> to be printed
     * @see        java.lang.Double#toString(double)
     */
    public void print(double d) {
        super.print(d);
        m_LogWnd.append(String.valueOf(d));
    }
    
    /** Print a floating-point number.  The string produced by <code>{@link
     * java.lang.String#valueOf(float)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      f   The <code>float</code> to be printed
     * @see        java.lang.Float#toString(float)
     */
    public void print(float f) {
        super.print(f);
        m_LogWnd.append(String.valueOf(f));
    }
    
    /** Print an integer.  The string produced by <code>{@link
     * java.lang.String#valueOf(int)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      i   The <code>int</code> to be printed
     * @see        java.lang.Integer#toString(int)
     */
    public void print(int i) {
        super.print(i);
        m_LogWnd.append(String.valueOf(i));
    }
    
    /** Print an object.  The string produced by the <code>{@link
     * java.lang.String#valueOf(Object)}</code> method is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      obj   The <code>Object</code> to be printed
     * @see        java.lang.Object#toString()
     */
    public void print(Object obj) {
        super.print(obj);
        m_LogWnd.append(String.valueOf(obj));
    }
    
    /** Print a string.  If the argument is <code>null</code> then the string
     * <code>"null"</code> is printed.  Otherwise, the string's characters are
     * converted into bytes according to the platform's default character
     * encoding, and these bytes are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      s   The <code>String</code> to be printed
     */
    public void print(String s) {
        super.print(s);
        if (s == null)
            m_LogWnd.append("null");
        else
            m_LogWnd.append(s);
            
    }
    
    /** Print a long integer.  The string produced by <code>{@link
     * java.lang.String#valueOf(long)}</code> is translated into bytes
     * according to the platform's default character encoding, and these bytes
     * are written in exactly the manner of the
     * <code>{@link #write(int)}</code> method.
     *
     * @param      l   The <code>long</code> to be printed
     * @see        java.lang.Long#toString(long)
     */
    public void print(long l) {
        super.print(l);
        m_LogWnd.append(String.valueOf(l));
    }
    
    /** Terminate the current line by writing the line separator string.  The
     * line separator string is defined by the system property
     * <code>line.separator</code>, and is not necessarily a single newline
     * character (<code>'\n'</code>).
     */
    public void println() {
        super.println();
        m_LogWnd.append(m_szCRLF);

    }
    
    /** Print a boolean and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(boolean)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>boolean</code> to be printed
     */
    public void println(boolean x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print a character and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(char)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>char</code> to be printed.
     */
    public void println(char x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print an array of characters and then terminate the line.  This method
     * behaves as though it invokes <code>{@link #print(char[])}</code> and
     * then <code>{@link #println()}</code>.
     *
     * @param x  an array of chars to print.
     */
    public void println(char[] x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print a double and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(double)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>double</code> to be printed.
     */
    public void println(double x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print a float and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(float)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>float</code> to be printed.
     */
    public void println(float x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print an integer and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(int)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>int</code> to be printed.
     */
    public void println(int x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print an Object and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(Object)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>Object</code> to be printed.
     */
    public void println(Object x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print a String and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(String)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  The <code>String</code> to be printed.
     */
    public void println(String x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    /** Print a long and then terminate the line.  This method behaves as
     * though it invokes <code>{@link #print(long)}</code> and then
     * <code>{@link #println()}</code>.
     *
     * @param x  a The <code>long</code> to be printed.
     */
    public void println(long x) {
        super.println(x);
        m_LogWnd.append(m_szCRLF);
    }
    
    public void run() {
        m_Diag.show();
    }
    
}
