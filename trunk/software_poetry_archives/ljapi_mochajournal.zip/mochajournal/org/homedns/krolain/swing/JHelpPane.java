/*
 * JHelpPane.java
 *
 * Created on March 5, 2004, 9:54 PM
 */

package org.homedns.krolain.swing;

import javax.swing.*;
import java.awt.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.util.ResourceBundle;
import org.homedns.krolain.util.NativeSystem;
import javax.print.*;
import javax.print.attribute.*;
import org.homedns.krolain.swing.text.DocumentRenderer;
import javax.swing.text.*;

/**
 *
 * @author  Krolain
 */
public class JHelpPane extends javax.swing.JPanel implements TreeSelectionListener {

    /** Creates new form HTMLDlg */
    private String m_szBasePath = null;
    private java.util.Vector m_HistList;
    private int m_iHistIdx = -1;
    private String m_szBrowser = null;

    public JHelpPane(boolean bShowToolbar,String szBrowser) {
        this(bShowToolbar, szBrowser, null);
    }
    /** Creates a new instance of JHelpPane */
    public JHelpPane(boolean bShowToolbar,String szBrowser,Icon[] icons) {
        m_HistList = new java.util.Vector();
        m_szBrowser = szBrowser;
        initComponents(bShowToolbar);
        if (icons != null)
            jContentList.setCellRenderer(new HelpTreeCellRenderer(icons));
        else
        {
            java.net.URL url;
            Icon[] defIcon = new javax.swing.Icon[4];
            defIcon[0] = new ImageIcon(getClass().getResource("/org/homedns/krolain/swing/Images/document.gif"));
            defIcon[1] = new ImageIcon(getClass().getResource("/org/homedns/krolain/swing/Images/external.gif"));
            defIcon[2] = new ImageIcon(getClass().getResource("/org/homedns/krolain/swing/Images/expand.gif"));
            defIcon[3] = new ImageIcon(getClass().getResource("/org/homedns/krolain/swing/Images/collapse.gif"));
            jContentList.setCellRenderer(new HelpTreeCellRenderer(defIcon));
        }
    }

    private void initComponents(boolean bShowToolbar) {
        jSplitPane1 = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPageDisplay = new javax.swing.JEditorPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jContentList = new javax.swing.JTree();
        jToolBar1 = new javax.swing.JToolBar();
        jBackBtn = new javax.swing.JButton();
        jForwBtn = new javax.swing.JButton();
        jPrintBtn = new javax.swing.JButton();
        
        setLayout(new BorderLayout());
        
        jSplitPane1.setOneTouchExpandable(true);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(400, 300));
        jPageDisplay.setEditable(false);
        jPageDisplay.setEditorKit(new javax.swing.text.html.HTMLEditorKit());
        jPageDisplay.addHyperlinkListener(new javax.swing.event.HyperlinkListener() {
            public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) {
                jPageDisplayHyperlinkUpdate(evt);
            }
        });

        jScrollPane1.setViewportView(jPageDisplay);

        jSplitPane1.setRightComponent(jScrollPane1);

        jScrollPane2.setPreferredSize(new java.awt.Dimension(200, 300));
        jScrollPane2.setViewportView(jContentList);
        jContentList.setScrollsOnExpand(true);
        jContentList.putClientProperty("JTree.lineStyle", "Angled");
        
        jSplitPane1.setLeftComponent(jScrollPane2);

        add(jSplitPane1, java.awt.BorderLayout.CENTER);

        jToolBar1.setFloatable(false);
        jBackBtn.setIcon(new ImageIcon(getClass().getResource("/org/homedns/krolain/swing/Images/back.gif")));
        jBackBtn.setToolTipText(ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("tooltip.back"));
        jBackBtn.setEnabled(false);
        jBackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBackBtnActionPerformed(evt);
            }
        });

        jToolBar1.add(jBackBtn);

        jForwBtn.setIcon(new ImageIcon(getClass().getResource("/org/homedns/krolain/swing/Images/forward.gif")));
        jForwBtn.setToolTipText(ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("tooltip.forward"));
        jForwBtn.setEnabled(false);
        jForwBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jForwBtnActionPerformed(evt);
            }
        });

        jToolBar1.add(jForwBtn);

        jPrintBtn.setIcon(new ImageIcon(getClass().getResource("/org/homedns/krolain/swing/Images/print.gif")));
        jPrintBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPrintBtnActionPerformed(evt);
            }
        });
        jPrintBtn.setToolTipText(ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("tooltip.print"));
        jToolBar1.add(jPrintBtn);

        if (bShowToolbar)
            add(jToolBar1, java.awt.BorderLayout.NORTH);
        
        validate();
    }    

    private void jPrintBtnActionPerformed(java.awt.event.ActionEvent evt)
    {
        DocumentRenderer dr = new DocumentRenderer();
        Document doc = jPageDisplay.getDocument();
        if (doc instanceof javax.swing.text.html.HTMLDocument)
            dr.print((javax.swing.text.html.HTMLDocument)jPageDisplay.getDocument());
    }

    private void jForwBtnActionPerformed(java.awt.event.ActionEvent evt) {
        m_iHistIdx ++;
        if (m_iHistIdx == m_HistList.size() -1)
            jForwBtn.setEnabled(false);
        jBackBtn.setEnabled(true);
        setURL((String)m_HistList.get(m_iHistIdx));
    }

    private void jBackBtnActionPerformed(java.awt.event.ActionEvent evt) {
        m_iHistIdx --;
        if (m_iHistIdx < 1)
            jBackBtn.setEnabled(false);
        jForwBtn.setEnabled(true);
        setURL((String)m_HistList.get(m_iHistIdx));
    }

    private void jPageDisplayHyperlinkUpdate(javax.swing.event.HyperlinkEvent evt) throws java.lang.NullPointerException {
        if (evt.getEventType() == evt.getEventType().ACTIVATED)
        {
            java.net.URL url = evt.getURL();
            String szTemp = url.toString();
            String szProt = url.getProtocol();
            if (szProt.compareToIgnoreCase("file") == 0)
                setURL(szTemp);
            else if (m_szBrowser != null)
                NativeSystem.launchBrowser(m_szBrowser,szTemp);
            else
                throw new java.lang.NullPointerException("Encountered external link; but, browser member variable not set.");
        }
    }
    
    public void setURL(String szUrl)
    {
        try
        {
            jPageDisplay.setPage(szUrl);
            if (m_szBasePath == null)
            {
                int iIndex = szUrl.lastIndexOf('/');
                m_szBasePath = szUrl.substring(0,iIndex+1);
            }
        }
        catch (java.io.IOException e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("string.error.no.help.content"),ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("title.help"),javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void populateNode(java.io.BufferedReader bf, DefaultMutableTreeNode tn)
    {
        String szLine;
        DefaultMutableTreeNode newTn = null;
        try
        {
            while ((szLine = bf.readLine()) != null)
            {
                if (szLine.length() == 0) continue;
                if (szLine.charAt(0) == '{')
                {
                    newTn = new DefaultMutableTreeNode(szLine.substring(2));
                    populateNode(bf,newTn);
                    tn.add(newTn);
                }
                else if (szLine.charAt(0) == '}')
                {
                    break;
                }
                else
                {
                    java.util.StringTokenizer st = new java.util.StringTokenizer(szLine, "=");
                    String[] inputs = new String[3];
                    inputs[2] = "0";
                    int i = 0;
                    while (st.hasMoreTokens())
                    {
                        inputs[i] = st.nextToken();
                        i++;
                    }
                    if (i >= 2)
                    {
                        int iMode = 0;
                        java.lang.Integer mode = new java.lang.Integer(inputs[2]);
                        iMode = mode.intValue();
                        LinkNode node = new LinkNode(inputs[0],inputs[1],iMode);
                        newTn = new DefaultMutableTreeNode(node,false);
                        tn.add(newTn);
                    }
                }
            }
        } catch (java.io.IOException e) { System.err.println(e);}
    }
    
    public void setContent(String szUrl)
    {
       DefaultTreeModel tm = null;
       int iIndex = szUrl.lastIndexOf('/');
       m_szBasePath = szUrl.substring(0,iIndex+1);
        try
        {
            java.net.URL file = new java.net.URL(szUrl);
            java.io.BufferedReader bf = new java.io.BufferedReader(new java.io.InputStreamReader(file.openStream()));
            String szInitPage = bf.readLine();
            String szLine;
            if ((szLine = bf.readLine()) != null)
            {
                if (szLine.charAt(0) == '{')
                {
                    DefaultMutableTreeNode newTn = new DefaultMutableTreeNode(szLine.substring(2));
                    populateNode(bf,newTn);
                    tm = new DefaultTreeModel(newTn);
                }
                setURL(m_szBasePath+szInitPage);
                m_HistList.add(m_szBasePath+szInitPage);
                m_iHistIdx = 0;
            }
            else
            {
                // Show an error about the content file
            }
        }
        catch (java.io.IOException e)
        {
            System.err.println(e);
        }
        if (tm != null)
        {
            jContentList.setModel(tm);
            jContentList.addTreeSelectionListener(this);
        }
    }
    
    /**
     * Called whenever the value of the selection changes.
     * @param e the event that characterizes the change.
     */
    public void valueChanged(TreeSelectionEvent e) throws java.lang.NullPointerException {
        javax.swing.tree.TreePath path = e.getNewLeadSelectionPath();
        if (path == null) return;
        Object obj = path.getLastPathComponent();
        if (obj == null) return;
        if (obj instanceof DefaultMutableTreeNode)
        {
            Object obj2 = ((DefaultMutableTreeNode)obj).getUserObject();
            if (obj2 instanceof LinkNode)
            {
                LinkNode node = (LinkNode)obj2;
                if (node.isExternal())
                {
                    if (m_szBrowser != null)
                        NativeSystem.launchBrowser(m_szBrowser,node.getLink());
                    else
                        throw new java.lang.NullPointerException("Encountered external link; but, browser member variable not set.");
                }
                else
                {
                    if ((m_iHistIdx > -1) && (m_iHistIdx < m_HistList.size()))
                    {
                        for (int i = m_iHistIdx+1; i <  m_HistList.size(); i++)
                            m_HistList.remove(i);
                        jForwBtn.setEnabled(false);
                    }
                    m_HistList.add(m_szBasePath+node.getLink());
                    m_iHistIdx++;
                    jBackBtn.setEnabled(true);
                    setURL(m_szBasePath+node.getLink());
                }
            }
        }
    }
    
    /**
     * Returns the specified component's toplevel <code>Frame</code> or
     * <code>Dialog</code>.
     * 
     * @param parentComponent the <code>Component</code> to check for a 
     *		<code>Frame</code> or <code>Dialog</code>
     * @return the <code>Frame</code> or <code>Dialog</code> that
     *		contains the component, or the default
     *         	frame if the component is <code>null</code>,
     *		or does not have a valid 
     *         	<code>Frame</code> or <code>Dialog</code> parent
     * @exception HeadlessException if
     *   <code>GraphicsEnvironment.isHeadless</code> returns
     *   <code>true</code>
     * @see java.awt.GraphicsEnvironment#isHeadless
     */
    static Window getWindowForComponent(Component parentComponent)
        throws HeadlessException {
        if (parentComponent instanceof Frame || parentComponent instanceof Dialog)
            return (Window)parentComponent;
        return JHelpPane.getWindowForComponent(parentComponent.getParent());
    }

    public JDialog createDialog(Component parentComponent, String szTitle)
    {
        jMenuBar1 = new javax.swing.JMenuBar();
        jFileMenu = new javax.swing.JMenu();
        jExitItem = new javax.swing.JMenuItem();
        
        final JDialog dlg;
        Window window;
        if ((parentComponent == null) || ((window = JHelpPane.getWindowForComponent(parentComponent)) == null))
        {
            dlg = new JDialog();
            dlg.setTitle(szTitle);
        }
        else
        {
            if (window instanceof Frame) {
                dlg = new JDialog((Frame)window,szTitle,false);
            } else {
                dlg = new JDialog((Dialog)window,szTitle,false);
            }
        }

        dlg.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                dlg.setVisible(false);
            }
        });
        
        Container content = dlg.getContentPane();
        content.setLayout(new java.awt.BorderLayout());
        content.add(this,java.awt.BorderLayout.CENTER);

        jFileMenu.setText(ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("menu.file"));
        jExitItem.setText(ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("menu.exit"));
        jExitItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dlg.setVisible(false);
                dlg.dispose();
            }
        });
        jFileMenu.add(jExitItem);
        jMenuBar1.add(jFileMenu);
        dlg.setJMenuBar(jMenuBar1);
        
        dlg.pack();
        dlg.setLocationRelativeTo(parentComponent);

        return dlg;
    }
    
    static public void showHelpDialog(Component parentComponent, String szContentFile, String szBrowser)
    {
        showHelpDialog(parentComponent,ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("title.help"),szContentFile,szBrowser,null);
    }

    static public void showHelpDialog(Component parentComponent, String szContentFile, String szBrowser, Icon[] icons)
    {
        showHelpDialog(parentComponent,ResourceBundle.getBundle("org/homedns/krolain/swing/KCT").getString("title.help"),szContentFile,szBrowser,icons);
    }
    
    static public void showHelpDialog(Component parentComponent, String szTitle, String szContentFile, String szBrowser, Icon[] icons)
    {
        JHelpPane pane = new JHelpPane(true,szBrowser,icons);
        JDialog dlg = pane.createDialog(parentComponent , szTitle);
        pane.setContent(szContentFile);
        dlg.show();
    }
    
    // Variables declaration - do not modify
    private javax.swing.JButton jBackBtn;
    private javax.swing.JTree jContentList;
    private javax.swing.JButton jForwBtn;
    private javax.swing.JEditorPane jPageDisplay;
    private javax.swing.JButton jPrintBtn;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jFileMenu;
    private javax.swing.JMenuItem jExitItem;
    
    // End of variables declaration
}

class LinkNode extends Object
{
    private String m_szName = null;
    private String m_szLink = null;
    private static final int INTERNAL = 0;
    private static final int EXTERNAL = 1;
    private int m_iMode = INTERNAL;
    
    public LinkNode(String szname,String szLink,int iData)
    {
        m_szName = szname;
        m_szLink = szLink;
        m_iMode = iData;
    }
    
    public String toString()
    {
        return m_szName;
    }
    
    public String getLink()
    {
        return m_szLink;
    }
    
    public boolean isExternal()
    {
        return ((m_iMode & EXTERNAL) == EXTERNAL);
    }
}

class HelpTreeCellRenderer extends DefaultTreeCellRenderer 
{
    Icon m_FileIcon = null;        // Internal file icon
    Icon m_ExternalIcon = null;    // External file icon
    Icon m_Expanded = null;        // Expanded group icon
    Icon m_Collapsed =  null;       // Collapsed group icon
    
    public HelpTreeCellRenderer (Icon[] icons)
    {
        if (icons != null)
        {
            if (icons.length > 0)
                m_FileIcon = icons[0];;
            if (icons.length > 1)
                m_ExternalIcon = icons[1];
            if (icons.length > 2)
                m_Expanded = icons[2];
            if (icons.length > 3)
                m_Collapsed = icons[3];
        }
    }
    
    public Component getTreeCellRendererComponent( JTree tree,
                        Object value,
                        boolean sel,
                        boolean expanded,
                        boolean leaf,
                        int row,
                        boolean hasFocus) {


        super.getTreeCellRendererComponent(tree, value, sel,expanded, leaf, row,hasFocus);
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;
        if ((node.getUserObject() instanceof LinkNode) && leaf)
        {
            LinkNode nodeInfo = (LinkNode)(node.getUserObject());
            if ((nodeInfo.isExternal()) && (m_ExternalIcon != null)) setIcon(m_ExternalIcon);
            else if (m_FileIcon != null) setIcon(m_FileIcon);
        }
        else
        {
            if ((leaf) && m_FileIcon != null) setIcon (m_FileIcon);
            else if ((expanded) && (m_Expanded != null)) setIcon(m_Expanded);
            else if (m_Collapsed != null) setIcon(m_Collapsed);
        }
        
        return this;
    }
    
}