/*
 * ProgressBarInputStream.java
 *
 * Created on July 23, 2002, 3:43 PM
 */

package org.homedns.krolain.swing;

import java.io.*;
import javax.swing.JProgressBar;
/**
 *
 * @author  jsmith
 */
public class ProgressBarInputStream extends FilterInputStream {

    private JProgressBar monitor;
    private int             nread = 0;
    private int             size = 0;
    
    /** Creates a new instance of ProgressBarInputStream */
    public ProgressBarInputStream(InputStream in) {
        super(in);
        try {
            size = in.available();
        }
        catch(IOException ioe) {
            size = 0;
        }
        monitor = new JProgressBar(0, size);
    }
    
    public JProgressBar getProgressBar() {
        return monitor;
    }
    /**
     * Overrides <code>FilterInputStream.read</code> 
     * to update the progress monitor after the read.
     */
    public int read() throws IOException {
        int c = in.read();
        if (c >= 0) monitor.setValue(++nread);
        return c;
    }


    /**
     * Overrides <code>FilterInputStream.read</code> 
     * to update the progress monitor after the read.
     */
    public int read(byte b[]) throws IOException {
        int nr = in.read(b);
        if (nr > 0) monitor.setValue(nread += nr);
        return nr;
    }


    /**
     * Overrides <code>FilterInputStream.read</code> 
     * to update the progress monitor after the read.
     */
    public int read(byte b[],
                    int off,
                    int len) throws IOException {
        int nr = in.read(b, off, len);
        if (nr > 0) monitor.setValue(nread += nr);
        return nr;
    }


    /**
     * Overrides <code>FilterInputStream.skip</code> 
     * to update the progress monitor after the skip.
     */
    public long skip(long n) throws IOException {
        long nr = in.skip(n);
        if (nr > 0) monitor.setValue(nread += nr);
        return nr;
    }


    /**
     * Overrides <code>FilterInputStream.close</code> 
     * to close the progress monitor as well as the stream.
     */
    public void close() throws IOException {
        in.close();
    }


    /**
     * Overrides <code>FilterInputStream.reset</code> 
     * to reset the progress monitor as well as the stream.
     */
    public synchronized void reset() throws IOException {
        in.reset();
        nread = size - in.available();
        monitor.setValue(nread);
    }
    
    public void setMaxValue(int iMax)
    {
        monitor.setMaximum(iMax);
        monitor.setValue(nread);
    }
}
