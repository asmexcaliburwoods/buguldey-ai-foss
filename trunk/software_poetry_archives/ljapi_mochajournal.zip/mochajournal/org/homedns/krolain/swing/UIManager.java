/*
 * UIManager.java
 *
 * Created on September 8, 2002, 12:10 PM
 */

package org.homedns.krolain.swing;

import javax.swing.LookAndFeel;

/**
 *
 * @author  krolain
 */
public class UIManager extends javax.swing.UIManager {
    
    /** Creates a new instance of UIManager */
    public UIManager() {
    }
 
    public static javax.swing.LookAndFeel[] getSupportedLookAndFeels()
    {
        java.util.Vector vect = new java.util.Vector();
        LookAndFeelInfo[] LFList = getInstalledLookAndFeels();
        int iSize = LFList.length;
        for (int i = 0; i < iSize; i++)
        {
            try
            {
                Class cls = Class.forName(LFList[i].getClassName());
                Object obj = cls.newInstance();
                if (obj instanceof LookAndFeel)
                {
                    javax.swing.LookAndFeel lf = (LookAndFeel)obj;
                    if (lf.isSupportedLookAndFeel())
                        vect.add(lf);
                }
                
            } catch (java.lang.Exception e) {System.err.println(e);}
        }
        LookAndFeel[] LFList2 = getAuxiliaryLookAndFeels();
        if (LFList2 != null)
        {
            iSize = LFList2.length;
            for (int i = 0; i < iSize; i++)
            {
                if (LFList2[i].isSupportedLookAndFeel())
                    vect.add(LFList2[i]);
            }
        }
        
        
        javax.swing.LookAndFeel[] lf = new javax.swing.LookAndFeel[vect.size()];
        iSize = vect.size();
        for (int i = 0; i < iSize; i++)
        {
            lf[i] = (javax.swing.LookAndFeel)vect.get(i);
        }
        
        return lf;
    }
}
