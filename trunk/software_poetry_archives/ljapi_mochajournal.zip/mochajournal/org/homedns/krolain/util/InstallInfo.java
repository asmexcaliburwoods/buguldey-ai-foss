/*
 * InstallInfo.java
 *
 * Created on September 12, 2002, 12:41 PM
 */

package org.homedns.krolain.util;
import java.util.ResourceBundle;
import org.homedns.krolain.lang.InstallClassLoader;
import java.io.*;
import java.util.Locale;
/**
 *
 * @author  jsmith
 */
public class InstallInfo extends java.lang.Object {
    
    private static String m_szInstallPath = "C:\\Program Files\\MochaJournal\\";
    private static java.util.ResourceBundle m_Bundle = null;
    private static InstallClassLoader m_Load = null;
    
    /** Creates a new instance of InstallInfo */
    public InstallInfo()
    {
    }
    
    public static boolean setInstallPath(String szJarFile) throws java.lang.NullPointerException {
        if (szJarFile == null)
            throw new java.lang.NullPointerException("Parameter cannot be null.  You must pass in the name of a Jar File.");
        
        String szPath = System.getProperty("java.class.path");
        java.util.StringTokenizer st = new java.util.StringTokenizer(szPath,java.io.File.pathSeparator);
        int iIndex = -1;
        while (st.hasMoreElements())
        {
             szPath = st.nextToken();
             if ((iIndex = szPath.indexOf(szJarFile)) > -1)
                 break;
        }
        if (iIndex == -1)
        {
            System.err.println("Cannot locate the path for Jar file: "+szJarFile+".  Install path will be set to null.");
            return false;
        }

        m_szInstallPath = szPath.substring(0,iIndex);
        return true;
    }
    
    public static boolean loadInstallPath()
    {
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal"+System.getProperty("file.separator")+"Installnfo.xml";
        File backup = new File(szPath);
        if (backup.exists())
        {
            try
            {
                java.beans.XMLDecoder decode = new java.beans.XMLDecoder(new java.io.FileInputStream(backup));
                m_szInstallPath = (String) decode.readObject();
                decode.close();
            } catch (java.io.FileNotFoundException e) { 
                System.err.println(e);
                return false;
            }
            catch (java.io.IOException e) { 
                System.err.println(e); 
                return false;
            }
        }
        else
            return false;

        return true;
    }
    
    public static boolean saveInstallPath()
    {
        String szPath = System.getProperty("user.home");
        szPath +=System.getProperty("file.separator")+"MochaJournal";
        File file = new File(szPath);
        file.mkdirs();
        java.io.File backup = new File(file,"Installnfo.xml");

        try
        {
            if (!backup.exists()) backup.createNewFile();
            java.beans.XMLEncoder encode = new java.beans.XMLEncoder(new java.io.FileOutputStream(backup));
            encode.writeObject(m_szInstallPath);
            encode.flush();
            encode.close();
        } catch (java.io.FileNotFoundException e) { System.err.println(e); }
          catch (java.io.IOException e) { System.err.println(e); }
        return true;
    }
    
    public static String getInstallPath()
    {
        return m_szInstallPath;
    }
    
    public static ResourceInfo[] getInstalledLangs(Locale inLocale)
    {
        if (m_szInstallPath == null) return null;
        
        if (inLocale == null)
            inLocale = Locale.getDefault();
        
        ResourceInfo[] szDictList = null;

        File file = new java.io.File(m_szInstallPath+"lang");
        java.io.File[] fileList = file.listFiles(new java.io.FilenameFilter()
        {
            public boolean accept(java.io.File file, String szName)
            {
                if (szName.endsWith(".properties")) return true;
                return false;
            }
        });
        
        int iSize = 0;
        if (fileList != null)
        {
            iSize = fileList.length;
            szDictList = new ResourceInfo[iSize];
            
            for (int i = 0; i < iSize; i++)
            {
                java.util.Locale loc = null;
                String szFile = fileList[i].getName();
                szDictList[i] = new ResourceInfo();
                String szLang = szFile.substring(4,6);

                int Idx = szFile.indexOf('.');
                if ((Idx-4) > 2) // The -4 is to remove the JLJ_ length from the filename.
                {
                    String szCountry = null;
                    szCountry = szFile.substring(7,9);
                    loc = new java.util.Locale(szLang,szCountry);
                }
                else
                    loc = new java.util.Locale(szLang);
                
                szDictList[i].m_Locale = loc;
                
                szDictList[i].m_Name = loc.getDisplayName(inLocale);
            }
            
            java.util.Arrays.sort(szDictList);
        }
        
        return szDictList;
    }
    
    public static ResourceInfo[] getInstalledDicts(Locale inLocale)
    {
        if (m_szInstallPath == null) return null;

        if (inLocale == null)
            inLocale = Locale.getDefault();
        
        ResourceInfo[] szDictList = null;
        
        File file = new java.io.File(m_szInstallPath+"lang");
        java.io.File[] fileList = file.listFiles(new java.io.FilenameFilter()
        {
            public boolean accept(java.io.File file, String szName)
            {
                if (szName.endsWith(".dict")) return true;
                return false;
            }
        });        
        
        int iSize = 0;
        if (fileList != null)
        {
            iSize = fileList.length;
            szDictList = new ResourceInfo[iSize];
            
            for (int i = 0; i < iSize; i++)
            {
                java.util.Locale loc = null;
                String szFile = fileList[i].getName();
                szDictList[i] = new ResourceInfo();
                szDictList[i].m_FileName = szFile;
                String szLang = szFile.substring(0,2);

                int Idx = szFile.indexOf('.');
                if (Idx > 2)
                {
                    String szCountry = null;
                    szCountry = szFile.substring(3,5);
                    loc = new java.util.Locale(szLang,szCountry);
                }
                else
                    loc = new java.util.Locale(szLang);
                
                szDictList[i].m_Name = loc.getDisplayName(inLocale);
            }
            
            java.util.Arrays.sort(szDictList);
        }
        
        return szDictList;
    }
    
    public static boolean setBundle(String baseName,String defName)
    {
        return setBundle(baseName,defName, java.util.Locale.getDefault());
    }

    public static boolean setBundle(String baseName,String defName,java.util.Locale loc)
    {
        
        java.util.MissingResourceException e2 = null;
        ResourceBundle result = null;
        if (m_szInstallPath == null) return false;
        if (m_Load == null) m_Load = new InstallClassLoader(m_szInstallPath);
        try
        {
            result =  ResourceBundle.getBundle(baseName,loc,m_Load);
        } catch (java.util.MissingResourceException e) {e2 = e;}
        if ((result == null) && (defName == null))
        {
            System.err.println(e2);
            throw e2;
        }
        else if ((result == null) && (defName != null))
            result = ResourceBundle.getBundle(defName);

        m_Bundle = result;
        return true;
    }
    
    public static String getString(String key)
    {
        if (m_Bundle == null) return null;
        return m_Bundle.getString(key);
    }
}
