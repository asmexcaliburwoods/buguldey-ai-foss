/*
 * System.java
 *
 * Created on September 5, 2002, 12:31 PM
 */

package org.homedns.krolain.util;

/**
 *
 * @author  jsmith
 */
public class NativeSystem extends java.lang.Object {
    static native String[] OSDetectBrowser();
    static boolean m_bBrowserLibLoaded = false;
    
    /** Creates a new instance of System */
    public NativeSystem() {
    }


    public static void launchBrowser(String browser,String url)
    {
        try 
        {
            int iIndex;
            if ((iIndex = browser.indexOf("%1")) == -1)
                java.lang.Runtime.getRuntime().exec(browser+' '+url);
            else
            {
                String szExec;
                szExec = browser.substring(0,iIndex);
                szExec += url;
                szExec += browser.substring(iIndex+2);
                java.lang.Runtime.getRuntime().exec(szExec);
            }
        }
        catch (java.io.IOException e) 
        {
            System.err.println(e.toString());
        }
    }
    
    public static boolean canDetectBrowser()
    {
        String szIntallPath = InstallInfo.getInstallPath();
        String fs = System.getProperty("file.separator");
        String szLibPath = szIntallPath+fs+"Library";
        if (szLibPath != null)
        {
            try
            {
                String szLib = System.mapLibraryName(szLibPath+fs+"DetBrowser");
                System.load(szLib);
                m_bBrowserLibLoaded = true;
            } catch (java.lang.UnsatisfiedLinkError e)
            {
                System.out.println(e);
            }
        }
        
        return m_bBrowserLibLoaded;
    }
    
    public static String[] DetectBrowser()
    {
        if (m_bBrowserLibLoaded)
                return OSDetectBrowser();
        else
            return null;
    }
}
