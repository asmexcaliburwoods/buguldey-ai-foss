/*
 * TimeInfo.java
 *
 * Created on March 16, 2004, 3:41 PM
 */

package org.homedns.krolain.util;
import java.util.Calendar;
/**
 *
 * @author  jsmith
 */
public class TimeInfo {
    
    /** Creates a new instance of TimeInfo */
    public TimeInfo() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Calendar cal = Calendar.getInstance();
        System.out.println("Current Time: "+cal.getTimeInMillis());
    }
    
}
