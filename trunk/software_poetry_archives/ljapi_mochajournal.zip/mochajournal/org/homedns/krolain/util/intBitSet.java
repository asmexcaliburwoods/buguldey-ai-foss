/*
 * intBitSet.java
 *
 * Created on August 11, 2002, 12:02 PM
 */

package org.homedns.krolain.util;

import java.lang.IndexOutOfBoundsException;
/**
 *
 * @author  krolain
 */
public class intBitSet extends java.util.BitSet {
    
    private static final int BITS_PER_INT = 32;
    private static final int UPPER_BIT_INDEX = 31;
    private static final int LOWER_BIT_INDEX = 0;
    /** Creates a new instance of intBitSet */

    public intBitSet(int iValue)
    {
        super(BITS_PER_INT);
        setIntValue(iValue);
    }
    
    public intBitSet() {
        super(BITS_PER_INT);
    }
    
    /**
     * Sets the appropriate bits to represents the <coce>int</code> parameter.
     *
     * @param     iValue   the value to be represented as a <code>intBitSet</code>.
     */
    public void setIntValue(int iValue)
    {
        clear(LOWER_BIT_INDEX,UPPER_BIT_INDEX);
        for (int i = 0; i < BITS_PER_INT; i++)
            set(i,(((iValue >> i) & 1) == 1));
    }
    
    /**
     * Returns the value of this <code>intBitSet</code> as an <code>int</code>.
     *
     * @since     JDK1.0
     */
    public int getIntValue()
    {
        int iResult = 0;
        for (int i = 0; i < BITS_PER_INT; i++)
            iResult += ((get(i)?1:0) << i);
        return iResult;
    }
    
    /**
     * Sets the bit at the specified index to <code>true</code>.
     *
     * @param     bitIndex   a bit index.
     * @exception IndexOutOfBoundsException if the specified index is negative, or if index > 31.
     */
    public void set(int bitIndex) throws IndexOutOfBoundsException 
    {
        if (bitIndex > UPPER_BIT_INDEX)
	    throw new IndexOutOfBoundsException("bitIndex > 31: " + bitIndex);
        super.set(bitIndex);
    }

    /**
     * Sets the bit at the specified index to the specified value.
     *
     * @param     bitIndex   a bit index.
     * @param     value a boolean value to set.
     * @exception IndexOutOfBoundsException if the specified index is negative, or if index > 31.
     * @since     1.4
     */
    public void set(int bitIndex, boolean value) throws IndexOutOfBoundsException 
    {
        if (bitIndex > UPPER_BIT_INDEX)
	    throw new IndexOutOfBoundsException("bitIndex > 31: " + bitIndex);
        super.set(bitIndex,value);
    }

    /**
     * Sets the bits from the specified fromIndex(inclusive) to the
     * specified toIndex(exclusive) to <code>true</code>.
     *
     * @param     fromIndex   index of the first bit to be set.
     * @param     toIndex index after the last bit to be set.
     * @exception IndexOutOfBoundsException if <tt>fromIndex</tt> is negative,
     *            or <tt>toIndex</tt> is negative, or <tt>fromIndex</tt> is
     *            larger than <tt>toIndex</tt>, or if <tt>fromIndex</tt> > 31.
     */
    public void set(int fromIndex, int toIndex) {
        if (toIndex > UPPER_BIT_INDEX)
	    throw new IndexOutOfBoundsException("bitIndex > 31: " + toIndex);
        super.set(fromIndex,toIndex);
    }
    
    /**
     * Sets the bits from the specified fromIndex(inclusive) to the
     * specified toIndex(exclusive) to the specified value.
     *
     * @param     fromIndex   index of the first bit to be set.
     * @param     toIndex index after the last bit to be set
     * @param     value value to set the selected bits to
     * @exception IndexOutOfBoundsException if <tt>fromIndex</tt> is negative,
     *            or <tt>toIndex</tt> is negative, or <tt>fromIndex</tt> is
     *            larger than <tt>toIndex</tt>, or if <tt>fromIndex</tt> > 31.
     */
    public void set(int fromIndex, int toIndex, boolean value) {
        if (toIndex > UPPER_BIT_INDEX)
	    throw new IndexOutOfBoundsException("bitIndex > 31: " + toIndex);
        super.set(fromIndex,toIndex,value);
    }
}
