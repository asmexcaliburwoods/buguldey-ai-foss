package WS;

// Files needed to open the Research Cyc Knowledge Base
import  java.io.*;
import  java.net.*;
import  java.util.*;
import  org.opencyc.cycobject.*;
import  org.opencyc.api.*;
import  org.opencyc.util.*;


public class OpenTheCycKB {
    
	/**
	* Manages the api connection.
	*/
	protected static CycAccess cycAccess;

    /**
     * The constructor.
     */  
     public void Open_TheCycKB() throws Exception 
     {
                
    	System.out.println("Conecting to the Cyc ...\n");
              	
		try 
		{	
    		// It prints the parameters used by the connection (I do it to know that the parameters are the correct)
    		System.out.println("\t" + CycConnection.DEFAULT_HOSTNAME + " - " + CycConnection.DEFAULT_BASE_PORT + " - " + CycConnection.DEFAULT_COMMUNICATION_MODE + " - " + CycAccess.DEFAULT_CONNECTION +"\n");
			// It opens a connexion with the ontology and returns its handler
			cycAccess = new CycAccess(CycConnection.DEFAULT_HOSTNAME,
										CycConnection.DEFAULT_BASE_PORT ,
				                        CycConnection.DEFAULT_COMMUNICATION_MODE,
				                        CycAccess.DEFAULT_CONNECTION);
	                              				
			System.out.println("Conected to the Cyc ...\n");
			
			// The class oRCyc contains the exmple program that writes the Cyc to the screen
			GetRCycConcepts oRCyc = new GetRCycConcepts(cycAccess);
			
			// We obtain all the constants defined in the Cyc
			CycList lTerms=oRCyc.init();
			
			// The obtained constains are processed to identify their type and write their information on the screen
			oRCyc.export(lTerms);
				
		} catch (Exception ex) {
			ex.printStackTrace();
			System.exit(1);
		}
    }
    
    
}
