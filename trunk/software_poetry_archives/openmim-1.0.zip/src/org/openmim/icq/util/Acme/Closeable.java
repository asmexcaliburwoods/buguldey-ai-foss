package org.openmim.icq.util.Acme;

import org.openmim.*;

public interface Closeable
{
  boolean isClosed();  
}