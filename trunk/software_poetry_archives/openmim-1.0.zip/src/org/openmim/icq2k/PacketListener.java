package org.openmim.icq2k;

import org.openmim.*;

public interface PacketListener
{
  void packetSent();
  void packetCanceled(MessagingNetworkException ex);
}