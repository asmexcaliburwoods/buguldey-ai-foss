package org.openmim.msn;

import org.openmim.*;
import org.openmim.icq.util.*;
import org.openmim.icq.util.joe.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class AccountPropertiesUtil
{
  static boolean isKnownPhoneProperty(String propName)
  {
    return
      "PHH".equals(propName) ||
      "PHW".equals(propName) ||
      "PHM".equals(propName);
  }
}
