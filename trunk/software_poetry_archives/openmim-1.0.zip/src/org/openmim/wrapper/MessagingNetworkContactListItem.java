package org.openmim.wrapper;

import java.util.*;
import java.io.*;
import java.net.*;
import org.openmim.*;
import org.openmim.icq.util.joe.*;

//
public interface MessagingNetworkContactListItem
{
  /**
    The time of the last time when MessagingNetwork impl 
    has fired the listeners.statusChanged (...) event.

    @see org.openmim.MessagingNetworkListener
  */
  public long getContactStatusLastChangeTimeMillis();

  /**
    @see #getContactStatusLastChangeTimeMillis()
  */
  public void setContactStatusLastChangeTimeMillis(long time);

  public void setScheduledStatusChangeSendTimeMillis(long time);
  public long getScheduledStatusChangeSendTimeMillis();
}