package org.openmim.wrapper;

import java.util.*;
import java.io.*;
import java.net.*;
import org.openmim.*;
import org.openmim.icq.util.joe.*;
import org.openmim.wrapper.MessagingNetworkSession;

//
public interface MessagingNetworkWrappable
extends MessagingNetwork
{
  /** can return null, srcLoginId should never be null. */
  MessagingNetworkSession getSession(String srcLoginId);
}
